/**
 * HopeLink - Food Donation Submission & Donor Management (donor.js)
 * 
 * Manages:
 * - Multi-donor type donation form
 * - Live real-time card preview
 * - Quick deadline preset buttons (+2h, +4h, +6h, +12h)
 * - Food category image mapping
 * - Input validation & safety confirmation
 * - Phone privacy masking
 * - "My Active Donations" dashboard with Edit & Cancel actions
 */

const DonorModule = {
  init() {
    this.bindFormEvents();
    this.bindLivePreviewEvents();
    this.bindDeadlinePresets();
    this.renderMyDonations();
    this.updateLivePreview();
  },

  bindFormEvents() {
    const form = document.getElementById("donationForm");
    if (!form) return;

    // Set default prep time and deadline
    const prepTimeInput = document.getElementById("prepTime");
    const deadlineInput = document.getElementById("deadline");
    const catSelect = document.getElementById("foodCategory");

    const formatLocalIso = (d) => {
      const pad = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };

    if (prepTimeInput && !prepTimeInput.value) {
      prepTimeInput.value = formatLocalIso(new Date());
    }
    if (deadlineInput && !deadlineInput.value) {
      // Default 4 hours
      deadlineInput.value = formatLocalIso(new Date(Date.now() + 4 * 60 * 60 * 1000));
    }

    if (prepTimeInput && deadlineInput) {
      prepTimeInput.addEventListener("change", () => {
        const prepDate = new Date(prepTimeInput.value);
        if (!isNaN(prepDate.getTime())) {
          const hours = catSelect && catSelect.value === "produce" ? 12 : 4;
          const suggested = new Date(prepDate.getTime() + hours * 60 * 60 * 1000);
          deadlineInput.value = formatLocalIso(suggested);
          this.updateLivePreview();
        }
      });
    }

    // Voice dictation trigger
    const voiceFoodDescBtn = document.getElementById("voiceFoodDescBtn");
    if (voiceFoodDescBtn && window.i18n) {
      voiceFoodDescBtn.addEventListener("click", () => {
        window.i18n.startVoiceInput("foodDescription", (status, msg) => {
          if (status === "listening") {
            voiceFoodDescBtn.textContent = "🎙️ " + window.i18n.t("btn_listening");
            voiceFoodDescBtn.classList.add("recording");
          } else if (status === "idle") {
            voiceFoodDescBtn.textContent = "🎙️ " + window.i18n.t("btn_voice_input");
            voiceFoodDescBtn.classList.remove("recording");
          } else if (status === "error") {
            window.App && window.App.showToast(msg, "warning");
          }
        });
      });
    }

    // Form submission
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.handleFormSubmit();
    });
  },

  // 1-Click Deadline Presets
  bindDeadlinePresets() {
    const presetBtns = document.querySelectorAll(".btn-deadline-preset");
    const deadlineInput = document.getElementById("deadline");
    const prepInput = document.getElementById("prepTime");

    const formatLocalIso = (d) => {
      const pad = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };

    presetBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        const hours = parseFloat(btn.getAttribute("data-hours"));
        const baseTime = prepInput && prepInput.value ? new Date(prepInput.value).getTime() : Date.now();
        const target = new Date(baseTime + hours * 60 * 60 * 1000);

        if (deadlineInput) {
          deadlineInput.value = formatLocalIso(target);
          this.updateLivePreview();
          window.App && window.App.showToast(`Deadline preset: +${hours} hours selected.`, "info", 2000);
        }

        presetBtns.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
      });
    });
  },

  // Live Real-Time Card Preview
  bindLivePreviewEvents() {
    const inputs = [
      "donorName",
      "donorType",
      "foodName",
      "foodDescription",
      "foodCategory",
      "foodQuantity",
      "foodUnit",
      "pickupAddress",
      "deadline"
    ];

    inputs.forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", () => this.updateLivePreview());
        el.addEventListener("change", () => this.updateLivePreview());
      }
    });

    document.querySelectorAll('input[name="dietary"]').forEach((r) => {
      r.addEventListener("change", () => this.updateLivePreview());
    });
  },

  updateLivePreview() {
    const foodName = document.getElementById("foodName")?.value.trim() || "Delicious Surplus Food";
    const donorName = document.getElementById("donorName")?.value.trim() || "Your Organization Name";
    const donorType = document.getElementById("donorType")?.value || "restaurant";
    const category = document.getElementById("foodCategory")?.value || "cooked";
    const quantity = document.getElementById("foodQuantity")?.value || "30";
    const unit = document.getElementById("foodUnit")?.value || "portions";
    const dietary = document.querySelector('input[name="dietary"]:checked')?.value || "veg";
    const location = document.getElementById("pickupAddress")?.value.trim() || "Local Neighborhood";
    const deadline = document.getElementById("deadline")?.value;

    const previewTitle = document.getElementById("livePreviewFoodTitle");
    const previewDonor = document.getElementById("livePreviewDonor");
    const previewQty = document.getElementById("livePreviewQty");
    const previewDiet = document.getElementById("livePreviewDietary");
    const previewDeadline = document.getElementById("livePreviewDeadline");
    const previewLocation = document.getElementById("livePreviewLocation");
    const previewImg = document.getElementById("livePreviewImg");

    if (previewTitle) previewTitle.textContent = foodName;
    if (previewDonor) previewDonor.textContent = `By: ${donorName} (${donorType})`;
    if (previewQty) previewQty.textContent = `${quantity} ${unit}`;
    if (previewDiet) {
      previewDiet.textContent = dietary === "veg" ? "🟢 Pure Veg" : "🔴 Non-Veg";
      previewDiet.className = `tag-dietary ${dietary === 'veg' ? 'diet-veg' : 'diet-nonveg'}`;
    }
    if (previewLocation) previewLocation.textContent = `📍 ${location}`;

    if (previewDeadline && deadline) {
      const d = new Date(deadline);
      const hoursLeft = ((d.getTime() - Date.now()) / (1000 * 60 * 60)).toFixed(1);
      previewDeadline.textContent = `⏰ Expiry: ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (${hoursLeft}h left)`;
    }

    if (previewImg && window.HopeStore) {
      previewImg.src = window.HopeStore.FOOD_IMAGES[category] || window.HopeStore.FOOD_IMAGES.cooked;
    }
  },

  handleFormSubmit() {
    const donorName = document.getElementById("donorName")?.value.trim();
    const donorType = document.getElementById("donorType")?.value;
    const foodName = document.getElementById("foodName")?.value.trim();
    const foodDescription = document.getElementById("foodDescription")?.value.trim();
    const category = document.getElementById("foodCategory")?.value;
    const dietary = document.querySelector('input[name="dietary"]:checked')?.value || "veg";
    const quantity = parseInt(document.getElementById("foodQuantity")?.value, 10);
    const unit = document.getElementById("foodUnit")?.value || "portions";
    const prepTime = document.getElementById("prepTime")?.value;
    const deadline = document.getElementById("deadline")?.value;
    const storageCondition = document.getElementById("storageCondition")?.value;
    const location = document.getElementById("pickupAddress")?.value.trim();
    const pickupInstructions = document.getElementById("pickupInstructions")?.value.trim();
    const contactPhone = document.getElementById("contactPhone")?.value.trim();
    const hidePhone = document.getElementById("hidePhone")?.checked || false;
    const safetyChecked = document.getElementById("safetyAcknowledge")?.checked || false;

    // Validation
    if (!donorName || !foodName || !quantity || !location || !contactPhone) {
      window.App && window.App.showToast("Please fill in all required fields (*)", "warning");
      return;
    }

    if (!safetyChecked) {
      window.App && window.App.showToast("Please confirm the Food Safety Checklist before submitting.", "warning");
      return;
    }

    const deadlineTime = new Date(deadline).getTime();
    if (deadlineTime <= Date.now()) {
      window.App && window.App.showToast("Safe collection deadline must be in the future.", "warning");
      return;
    }

    let estimatedKg = quantity;
    if (unit === "portions") {
      estimatedKg = Math.round(quantity * 0.35);
    } else if (unit === "boxes" || unit === "trays") {
      estimatedKg = Math.round(quantity * 3.5);
    }

    const allergenCheckboxes = document.querySelectorAll('input[name="allergens"]:checked');
    const allergens = Array.from(allergenCheckboxes).map((cb) => cb.value);

    // Get food image
    const imageUrl = window.HopeStore && window.HopeStore.FOOD_IMAGES
      ? window.HopeStore.FOOD_IMAGES[category] || window.HopeStore.FOOD_IMAGES.cooked
      : "";

    const donationData = {
      donorName,
      donorType,
      foodName,
      foodDescription: foodDescription || "Surplus food packaged in hygienic containers.",
      category,
      imageUrl,
      dietary,
      quantity,
      unit,
      estimatedKg,
      prepTime: new Date(prepTime).toISOString(),
      deadline: new Date(deadline).toISOString(),
      storageCondition,
      allergens,
      location,
      pickupInstructions: pickupInstructions || "Please call upon arrival.",
      contactPhone,
      hidePhone,
      status: "available",
      assignedNgoId: null,
      assignedNgoName: null,
      driverName: null,
      driverPhone: null,
      claimedAt: null,
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true
    };

    const saved = window.HopeStore.saveDonation(donationData);

    // Reset form & update UI
    document.getElementById("donationForm").reset();
    this.updateLivePreview();
    this.showConfirmationModal(saved);
    this.renderMyDonations();

    if (window.App) window.App.renderHomeFeatured();
    if (window.NgoModule) window.NgoModule.renderFeed();
    if (window.ImpactModule) window.ImpactModule.updateMetrics();
  },

  showConfirmationModal(donation) {
    const modal = document.getElementById("donationConfirmModal");
    if (!modal) return;

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    const unitLabel = window.i18n ? (window.i18n.t("unit_" + donation.unit) || donation.unit) : donation.unit;
    const donorTypeLabel = window.i18n ? (window.i18n.t("donor_" + donation.donorType) || donation.donorType) : donation.donorType;

    document.getElementById("confirmDonationId").textContent = donation.id;
    document.getElementById("confirmFoodTitle").textContent = isTa
      ? `${donation.quantity} ${unitLabel} - ${donation.foodName}`
      : `${donation.quantity} ${unitLabel} of ${donation.foodName}`;
    document.getElementById("confirmDonor").textContent = `${donation.donorName} (${donorTypeLabel})`;
    document.getElementById("confirmLocation").textContent = donation.location;

    // Calculate top matching NGO
    const ngos = window.HopeStore.getNGOs();
    const ranked = window.MatchingEngine.rankNgosForDonation(donation, ngos);
    const topMatch = ranked[0];

    const matchInfoEl = document.getElementById("confirmTopMatch");
    if (matchInfoEl && topMatch) {
      const topNgoName = isTa && topMatch.ngo.name_ta ? topMatch.ngo.name_ta : topMatch.ngo.name;
      const topMatchLabel = isTa ? "சிறந்த மாதிரிப் பொருத்தம்:" : "Top Algorithmic Match:";
      const matchPill = isTa ? `${topMatch.totalScore}% பொருத்தம்` : `${topMatch.totalScore}% Match`;
      const explText = isTa
        ? `மதிப்பெண்: ${topMatch.totalScore}/100 [தூரம்: +${topMatch.breakdown.distancePts}, அவசரம்: +${topMatch.breakdown.urgencyPts}, பொருத்தம்: +${topMatch.breakdown.suitabilityPts}, கொள்ளளவு: +${topMatch.breakdown.capacityPts}]. வெளிப்படையான கணக்கீடு.`
        : topMatch.explanation;

      matchInfoEl.innerHTML = `
        <strong>${topMatchLabel}</strong> ${topNgoName} 
        <span class="match-score-pill">${matchPill}</span>
        <p class="text-muted small">${explText}</p>
      `;
    }

    modal.removeAttribute("hidden");
    setTimeout(() => modal.classList.add("active"), 10);
  },

  renderMyDonations() {
    const container = document.getElementById("myDonationsContainer");
    if (!container) return;

    const donations = window.HopeStore.getDonations();
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (donations.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">🍲</span>
          <h4>${isTa ? "இன்னும் பதிவுகள் இல்லை" : "No Donations Yet"}</h4>
          <p>${isTa ? "உபரி உணவுப் பதிவைச் சமர்ப்பித்து அருகிலுள்ள காப்பகத்திற்கு உதவவும்." : "Submit your first surplus food listing above to help local shelters."}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = donations
      .map((d) => {
        const isVeg = d.dietary === "veg";
        const dietLabel = isVeg
          ? (isTa ? "🟢 சைவம்" : "🟢 Pure Veg")
          : (isTa ? "🔴 அசைவம்" : "🔴 Non-Veg");
        const dietBadge = `<span class="tag-dietary ${isVeg ? 'diet-veg' : 'diet-nonveg'}">${dietLabel}</span>`;

        const phoneDisplay = d.hidePhone
          ? d.contactPhone.replace(/(\d{3})\d{4}(\d{3})/, "$1****$2")
          : d.contactPhone;

        const isOverdue = new Date(d.deadline).getTime() < Date.now() && d.status === "available";
        const statusClass = isOverdue ? "status-overdue" : `status-${d.status}`;
        const statusLabel = isOverdue
          ? (isTa ? "⚠️ நேரம் கடந்தது" : "⚠️ Overdue")
          : (window.i18n ? window.i18n.t("badge_" + d.status) : d.status.toUpperCase());

        const byLabel = isTa ? "வழங்குபவர்:" : "By:";
        const donorTypeLabel = window.i18n ? (window.i18n.t("donor_" + d.donorType) || d.donorType) : d.donorType;
        const unitLabel = window.i18n ? (window.i18n.t("unit_" + d.unit) || d.unit) : d.unit;
        const catLabel = window.i18n ? (window.i18n.t("cat_" + d.category) || d.category) : d.category;

        const qtyLabel = isTa ? "அளவு" : "Quantity";
        const dietHead = isTa ? "உணவு முறை" : "Dietary";
        const catHead = isTa ? "வகை" : "Category";
        const deadlineHead = isTa ? "காலக்கெடு" : "Deadline";
        const pickupHead = isTa ? "எடுக்கும் இடம்:" : "Pickup:";
        const contactHead = isTa ? "தொடர்பு எண்:" : "Contact:";
        const maskLabel = isTa ? "மறைக்கப்பட்டது" : "Privacy Masked";
        const claimedByLabel = isTa ? "🤝 ஏற்றுக்கொண்ட அமைப்பு:" : "🤝 Claimed by:";

        const cancelText = isTa ? "பதிவை ரத்து செய்" : "Cancel Listing";
        const editText = isTa ? "விவரங்களைத் திருத்து" : "Edit Details";
        const trackerText = isTa ? "நேரடி ஜி.பி.எஸ் கண்காணிப்பில் காண்க ↗" : "View in Live GPS Tracker ↗";

        return `
          <div class="card donation-card modern-aligned-card" id="card-${d.id}">
            <div class="donation-card-img-wrapper">
              <img src="${d.imageUrl || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80'}" alt="${d.foodName}" class="donation-card-img" loading="lazy">
              <div class="card-img-header-overlay">
                <span class="card-id-pill">#${d.id}</span>
                <span class="card-status-badge badge ${statusClass}">${statusLabel}</span>
              </div>
            </div>

            <div class="card-body">
              <h4 class="food-title">${d.foodName}</h4>
              <p class="donor-subtitle">${byLabel} <strong>${d.donorName}</strong> <span class="donor-tag-pill">(${donorTypeLabel})</span></p>
              
              <!-- Clean 2x2 Structured Spec Tiles -->
              <div class="food-specs-grid">
                <div class="spec-tile">
                  <span class="spec-tile-icon">🍲</span>
                  <div class="spec-tile-data">
                    <span class="spec-label">${qtyLabel}</span>
                    <strong>${d.quantity} ${unitLabel}</strong>
                    <small class="spec-sub">(~${d.estimatedKg} kg)</small>
                  </div>
                </div>

                <div class="spec-tile">
                  <span class="spec-tile-icon">${isVeg ? '🥗' : '🍗'}</span>
                  <div class="spec-tile-data">
                    <span class="spec-label">${dietHead}</span>
                    ${dietBadge}
                  </div>
                </div>

                <div class="spec-tile">
                  <span class="spec-tile-icon">🏷️</span>
                  <div class="spec-tile-data">
                    <span class="spec-label">${catHead}</span>
                    <strong>${catLabel}</strong>
                  </div>
                </div>

                <div class="spec-tile">
                  <span class="spec-tile-icon">⏰</span>
                  <div class="spec-tile-data">
                    <span class="spec-label">${deadlineHead}</span>
                    <strong class="deadline-time-text">${new Date(d.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong>
                  </div>
                </div>
              </div>

              <div class="card-contact-box">
                <div class="contact-info-row">
                  <span class="row-icon">📍</span>
                  <div class="row-content">
                    <strong>${pickupHead}</strong> <span>${d.location}</span>
                  </div>
                </div>
                <div class="contact-info-row">
                  <span class="row-icon">📞</span>
                  <div class="row-content">
                    <strong>${contactHead}</strong> <a href="tel:${d.contactPhone}" class="tel-link">${phoneDisplay}</a>
                    ${d.hidePhone ? `<span class="privacy-tag">${maskLabel}</span>` : ''}
                  </div>
                </div>
              </div>

              ${d.assignedNgoName ? `
                <div class="assigned-ngo-box">
                  <div class="ngo-box-info">
                    <span class="ngo-box-icon">🤝</span>
                    <div>
                      <span class="ngo-box-sub">${claimedByLabel}</span>
                      <strong class="ngo-box-name">${d.assignedNgoName}</strong>
                    </div>
                  </div>
                  <span class="ngo-active-badge">● IN DISPATCH</span>
                </div>
              ` : ''}
            </div>

            <div class="card-actions">
              ${d.status === "available" ? `
                <button class="btn btn-outline-danger btn-sm" onclick="DonorModule.cancelDonation('${d.id}')">${cancelText}</button>
                <button class="btn btn-outline btn-sm" onclick="DonorModule.editDonation('${d.id}')">${editText}</button>
              ` : `
                <button class="btn btn-primary full-width btn-live-track-cta" onclick="App.navigateTo('tracker'); TrackingModule.selectDonation('${d.id}');">
                  <span class="live-pulse-dot"></span>
                  <span class="btn-text">${trackerText}</span>
                </button>
              `}
            </div>
          </div>
        `;
      })
      .join("");
  },

  cancelDonation(id) {
    if (confirm(`Are you sure you want to cancel donation #${id}? This will remove it from the NGO feed.`)) {
      window.HopeStore.deleteDonation(id);
      window.App && window.App.showToast(`Donation #${id} has been cancelled.`, "info");
      this.renderMyDonations();
      if (window.App) window.App.renderHomeFeatured();
      if (window.NgoModule) window.NgoModule.renderFeed();
      if (window.ImpactModule) window.ImpactModule.updateMetrics();
    }
  },

  editDonation(id) {
    const d = window.HopeStore.getDonationById(id);
    if (!d) return;

    document.getElementById("donorName").value = d.donorName;
    document.getElementById("donorType").value = d.donorType;
    document.getElementById("foodName").value = d.foodName;
    document.getElementById("foodDescription").value = d.foodDescription;
    document.getElementById("foodCategory").value = d.category;
    document.getElementById("foodQuantity").value = d.quantity;
    document.getElementById("foodUnit").value = d.unit;
    document.getElementById("pickupAddress").value = d.location;
    document.getElementById("pickupInstructions").value = d.pickupInstructions;
    document.getElementById("contactPhone").value = d.contactPhone;

    window.HopeStore.deleteDonation(id);
    this.renderMyDonations();
    this.updateLivePreview();
    window.App && window.App.showToast(`Loaded #${id} for editing. Make changes and click Submit.`, "info");
    
    document.getElementById("donationForm").scrollIntoView({ behavior: "smooth" });
  }
};

window.DonorModule = DonorModule;
