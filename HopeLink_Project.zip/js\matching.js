/**
 * HopeLink - Transparent Rule-Based Matching Engine (matching.js)
 * 
 * Computes a deterministic heuristic score (0 - 100) between a surplus food
 * donation and a candidate partner NGO.
 * 
 * IMPORTANT: This is a transparent mathematical rule-based algorithm.
 * It explicitly does NOT use machine learning or opaque black-box AI.
 */

const MatchingEngine = {
  /**
   * Calculate score between a donation and an NGO profile
   * @param {Object} donation 
   * @param {Object} ngo 
   * @returns {Object} score breakdown and textual explanation
   */
  calculateMatch(donation, ngo) {
    if (!donation || !ngo) {
      return { totalScore: 0, breakdown: {}, explanation: "Invalid data" };
    }

    let distancePts = 0;
    let urgencyPts = 0;
    let suitabilityPts = 0;
    let capacityPts = 0;
    let isHardMismatch = false;
    let mismatchReason = "";

    // -------------------------------------------------------------
    // 1. Food Suitability & Dietary Policy Check (Max 20 pts)
    // -------------------------------------------------------------
    if (donation.dietary === "nonveg" && !ngo.acceptsNonVeg) {
      // Hard mismatch: Pure veg shelter cannot accept non-veg meals
      isHardMismatch = true;
      suitabilityPts = 0;
      mismatchReason = "NGO is strictly Pure Vegetarian and cannot accept non-vegetarian donations.";
    } else {
      suitabilityPts += 8; // Dietary compatible
      if (donation.category === "cooked" && ngo.acceptsCooked) {
        suitabilityPts += 12; // Cooked meal handling facility
      } else {
        suitabilityPts += 10;
      }
    }

    // -------------------------------------------------------------
    // 2. Distance Proximity Heuristic (Max 35 pts)
    // -------------------------------------------------------------
    const dist = ngo.distanceKm || 5.0;
    if (dist <= 3.0) {
      distancePts = 35;
    } else if (dist <= 6.0) {
      distancePts = 28;
    } else if (dist <= 10.0) {
      distancePts = 20;
    } else if (dist <= 15.0) {
      distancePts = 12;
    } else {
      distancePts = 5;
    }

    // -------------------------------------------------------------
    // 3. Expiry Urgency Heuristic (Max 25 pts)
    // -------------------------------------------------------------
    const now = Date.now();
    const deadlineTime = new Date(donation.deadline).getTime();
    const hoursLeft = (deadlineTime - now) / (1000 * 60 * 60);

    if (hoursLeft <= 0) {
      urgencyPts = 2; // Expired / overdue
    } else if (hoursLeft <= 2.0) {
      urgencyPts = 25; // Critical emergency rescue
    } else if (hoursLeft <= 4.0) {
      urgencyPts = 20; // High urgency
    } else if (hoursLeft <= 8.0) {
      urgencyPts = 14; // Moderate window
    } else {
      urgencyPts = 8; // Ample shelf-life
    }

    // -------------------------------------------------------------
    // 4. Quantity vs Shelter Capacity Heuristic (Max 20 pts)
    // -------------------------------------------------------------
    const portions = donation.quantity || 30;
    const capacity = ngo.capacityPortions || 100;
    const ratio = portions / capacity;

    if (ratio <= 0.4) {
      capacityPts = 16; // Easily absorbed
    } else if (ratio <= 0.85) {
      capacityPts = 20; // Ideal batch fit
    } else if (ratio <= 1.0) {
      capacityPts = 15; // Near maximum capacity
    } else {
      capacityPts = 6; // Exceeds single batch capacity; needs split
    }

    // Total Score
    let totalScore = distancePts + urgencyPts + suitabilityPts + capacityPts;
    if (isHardMismatch) {
      totalScore = Math.min(totalScore, 20); // Severely capped on dietary mismatch
    }

    totalScore = Math.max(0, Math.min(100, Math.round(totalScore)));

    const explanation = isHardMismatch
      ? mismatchReason
      : `Score: ${totalScore}/100 [Distance: +${distancePts}, Urgency: +${urgencyPts}, Suitability: +${suitabilityPts}, Capacity: +${capacityPts}]. Calculated via transparent rule-based algorithm.`;

    return {
      totalScore,
      isHardMismatch,
      mismatchReason,
      breakdown: {
        distancePts,
        urgencyPts,
        suitabilityPts,
        capacityPts
      },
      explanation
    };
  },

  /**
   * Rank all NGOs for a given donation
   */
  rankNgosForDonation(donation, ngosList) {
    if (!ngosList || !Array.isArray(ngosList)) return [];
    return ngosList
      .map((ngo) => {
        const result = this.calculateMatch(donation, ngo);
        return {
          ngo,
          ...result
        };
      })
      .sort((a, b) => b.totalScore - a.totalScore);
  }
};

window.MatchingEngine = MatchingEngine;
