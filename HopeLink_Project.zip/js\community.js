/**
 * HopeLink - Community Guidelines, Privacy & Issue Reporting (community.js)
 * 
 * Manages:
 * - Problem reporting form (spoiled food, no-show, hygiene issues)
 * - Privacy protection documentation & safeguards
 * - Community safety code of conduct
 */

const CommunityModule = {
  init() {
    this.bindReportForm();
    this.renderReportsList();
  },

  bindReportForm() {
    const form = document.getElementById("reportIssueForm");
    if (!form) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.handleReportSubmit();
    });
  },

  handleReportSubmit() {
    const category = document.getElementById("reportCategory")?.value;
    const donationId = document.getElementById("reportDonationId")?.value.trim();
    const reporterRole = document.getElementById("reporterRole")?.value;
    const description = document.getElementById("reportDescription")?.value.trim();
    const contactInfo = document.getElementById("reportContact")?.value.trim();

    if (!category || !description) {
      window.App && window.App.showToast("Please provide category and description.", "warning");
      return;
    }

    const reportData = {
      category,
      donationId: donationId || "General Feedback",
      reporterRole,
      description,
      contactInfo: contactInfo || "Anonymous Community Member"
    };

    const saved = window.HopeStore.saveReport(reportData);
    document.getElementById("reportIssueForm").reset();

    window.App && window.App.showToast(`Issue #${saved.id} logged. HopeLink coordinators have been notified.`, "info");
    this.renderReportsList();
  },

  renderReportsList() {
    const container = document.getElementById("recentReportsContainer");
    if (!container) return;

    const reports = window.HopeStore.getReports();
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (reports.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p class="text-muted">${isTa ? "இந்த அமர்வில் எந்தவொரு புகாரும் இல்லை. அனைத்தும் பாதுகாப்பாக உள்ளது." : "No safety or community issues logged in this demo session. All operations normal."}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = reports
      .map(
        (r) => {
          const badgeText = isTa ? `புகார் #${r.id}` : `REPORT #${r.id}`;
          const reportedByText = isTa ? "பதிவு செய்தவர்:" : "Reported by:";
          const statusText = isTa ? "நிலை: ஒருங்கிணைப்பாளர் ஆய்வில் உள்ளது" : "Status: Under Coordinator Review";
          const catLabel = window.i18n ? (window.i18n.t("report_cat_" + r.category) || r.category) : r.category;
          const roleLabel = window.i18n ? (window.i18n.t("report_role_" + r.reporterRole) || r.reporterRole) : r.reporterRole;

          return `
            <div class="card report-card">
              <div class="card-header">
                <span class="badge badge-warning">${badgeText}</span>
                <small class="text-muted">${new Date(r.createdAt).toLocaleDateString()}</small>
              </div>
              <div class="card-body">
                <strong>${catLabel.toUpperCase()}</strong> ${r.donationId !== 'General Feedback' ? `(Ref: #${r.donationId})` : ''}
                <p class="report-desc">${r.description}</p>
                <small class="text-muted">${reportedByText} ${roleLabel} • ${statusText}</small>
              </div>
            </div>
          `;
        }
      )
      .join("");
  }
};

window.CommunityModule = CommunityModule;
