# HopeLink 🍲🌱

> **Connecting Food Donors with Local Verified NGOs to End Hunger and Food Waste.**

HopeLink is a single-page web application (SPA) designed to bridge the gap between food donors (individuals, families, restaurants, hotels, marriage halls, event caterers, cafeterias) and local verified charities, shelters, and food banks.

---

## 📱 Single App with Phone Model & Full Screen View
HopeLink includes an interactive top toolbar allowing you to toggle the interface between:
1. **📱 Phone Mockup Model**: A realistic smartphone shell with a dynamic island camera punch hole, top status bar (live clock, 5G, battery), touch-friendly bottom navigation bar, and scrollable phone viewport.
2. **🖥️ Full Screen Responsive View**: Unfolds into a standard modern desktop / tablet / mobile layout.

---

## 🎨 Theme & Palette
- **Forest Green (`#2E7D32` / `#1B5E20`)**: Sustainability, hygiene, trust, and community welfare.
- **Warm Cream (`#FAF7F2` / `#FFFFFF`)**: Inviting, warm, and clean card surfaces.
- **Vibrant Orange (`#E65100` / `#F57C00`)**: Urgency, warm nutritious food, and call-to-actions.

---

## 📂 Project Structure
```text
HopeLink/
├── index.html         # Unified single-page application with phone frame & all views
├── styles.css         # Complete styling (Green/Cream/Orange, phone frame, responsive grids)
├── server.js          # Zero-dependency local Node.js static server
├── package.json       # Project manifest (npm start)
├── README.md          # Project documentation & beginner guide
└── js/
    ├── app.js         # Master single-page app router, phone model toggle & notifications
    ├── store.js       # Central localStorage persistence, seed data & reset handler
    ├── i18n.js        # English and Tamil (தமிழ்) localization + Web Speech helpers
    ├── donor.js       # Multi-donor donation form, validation, and My Listings management
    ├── ngo.js         # Verified NGO portal, live search, multi-filters, and claim lock
    ├── matching.js    # Transparent rule-based matching engine (0-100 pts)
    ├── tracking.js    # 5-stage pickup lifecycle tracker & backup NGO suggestions
    ├── schedules.js   # Recurring donation schedule manager (Daily, Weekly, Weekdays)
    ├── impact.js      # Dynamic impact calculations computed live from local records
    └── community.js   # Community code of conduct, privacy safeguards & issue reporting
```

---

## 🌟 Comprehensive Features

### 1. Unified Single App with Phone Model
- Switch effortlessly between **Phone Mockup** and **Full Screen** mode with the top toolbar button.
- Bottom touch navigation bar (`Home`, `Donate`, `NGO Portal`, `Track`, `Impact`).

### 2. Multi-Donor Types & Donation Submission
- Supports 7 donor profiles: **Individual, Family, Restaurant, Hotel, Marriage/Banquet Hall, Event Caterer, Cafeteria**.
- Detailed fields: Food name, description with **🎙️ Voice Dictation**, category (Cooked, Bakery, Produce, Dairy, Packaged), dietary preference (Pure Veg 🟢 vs Non-Veg 🔴), quantity & unit, prep timestamp, safe collection deadline, storage temperature condition, allergen declarations, pickup location, and instructions.
- **Privacy-Conscious Contact:** Option to mask phone number on public listings (e.g. `+91 98*** **210`).
- **My Listings:** Active listings can be **Edited** or **Cancelled** with confirmation.

### 3. Verified NGO Feed & Claiming Portal
- Switch between 4 fictional verified partner NGOs:
  1. *Akshaya Community Food Bank* (Central Zone, 250 meal capacity)
  2. *Karuna Shelter & Children's Home* (North Zone, 90 meal capacity, Pure Veg only)
  3. *Seva Open Kitchen Trust* (East Zone, 180 meal capacity)
  4. *Annam Hunger Relief Foundation* (South Zone, 400 meal capacity, Bulk events)
- Search & filter by Category, Dietary, Urgency, and Distance.
- **Claim & Release:** Accepting locks a donation to the NGO, preventing duplicate claims in the same browser. Releasing returns it to the community pool.
- **Driver Assignment:** Assign volunteer drivers with vehicle and phone details.

### 4. Transparent Rule-Based Matching Heuristic
- **Not AI:** Explicitly labeled and explained as an open mathematical algorithm (up to 100 points):
  - **Distance Proximity (0 - 35 pts)**: Closer radius = higher score.
  - **Expiry Urgency (0 - 25 pts)**: Expiring sooner = higher urgency to rescue.
  - **Food Policy Suitability (0 - 20 pts)**: Strict pure-veg shelters reject non-veg; cooked meals matched to hot-storage shelters.
  - **Quantity vs Shelter Capacity (0 - 20 pts)**: Optimal batch size fit.
- Click any score badge to view the full mathematical breakdown.

### 5. Live Pickup Lifecycle Tracker
- 5-stage visual stepper:
  `Available` &rarr; `Accepted` &rarr; `Driver Assigned` &rarr; `Collected` &rarr; `Distributed`
- Interactive lifecycle demo buttons: *"Confirm Driver Picked Up Food"* &rarr; *"Confirm Distributed to Beneficiaries"*.
- **Overdue Detection:** Flags warning banners if a donation exceeds its collection deadline.
- **Backup NGO Suggestions:** Recommends the next highest-matching shelter if the primary NGO is delayed.
- **🔊 Audio Readout:** Text-to-speech reads out order details and pickup instructions.

### 6. Bilingual Support (English & Tamil - தமிழ்)
- Instant toggle between **EN** and **தமிழ்**.
- All key labels, badges, forms, and status tags translated into natural Tamil.
- Browser Speech Recognition (Voice Typing) and Speech Synthesis (TTS).

### 7. Recurring Donation Schedules
- Register recurring surplus from marriage halls, corporate canteens, and weekend buffets.
- Manage active schedules: Pause, Resume, or Delete.
- **⚡ "Post Today's Listing":** One-click button to instantly turn a recurring schedule into an active listing in the NGO feed.

### 8. Live Impact Dashboard
- Metrics calculated live from `localStorage`:
  - Portions rescued
  - Kilograms of food waste diverted
  - Carbon emissions avoided (kg CO₂e)
  - Rescue success rate %
  - Category breakdown bars

### 9. Food Safety & Compliance Guidelines
- Temperature danger zone rules (> 60°C hot, < 5°C cold, max 4h ambient).
- Allergen warning guidelines.
- **Compliance Disclaimer:** Clearly states that web coordination does not guarantee food safety; sensory inspection (smell/appearance) and municipal food health regulation adherence are mandatory before consumption.

### 10. Community Support, Privacy & Reporting
- Privacy safeguards: phone number masking, protected apartment locations, and dignity for recipients.
- Problem reporting form (Spoiled food, Driver no-show, Inaccurate quantity, Safety concern) with a demo audit log.

### 11. Role Switcher & In-App Notification Center
- Quickly switch perspectives between **Donor View**, **NGO Manager View**, **Volunteer Driver View**, and **Demo Admin**.
- Bell icon with unread badge counter opening a simulated notification drawer.
- **Reset Demo Data:** Top button to reload fresh sample scenarios at any time.

---

## ⚠️ Important Limitations & Public Deployment Roadmap
- **Browser-Scoped Storage:** In this demo, all data is stored inside the current browser's `localStorage`. Changes persist across refreshes on this computer, but do **not** synchronize across multiple devices or real users.
- **Production Backend Requirements:**
  1. Shared backend server (Node.js/Express, Python/FastAPI, or Go).
  2. Persistent database (PostgreSQL, MongoDB, or Supabase).
  3. Real Authentication (JWT, OAuth, secure password hashing).
  4. Real Messaging Gateway (Twilio / Gupshup for actual SMS and WhatsApp alerts).
  5. Geocoding API (Google Maps / OpenStreetMap for exact driving distances).
  6. Verified regulatory compliance for food hygiene inspection.

---

## 🚀 How to Run HopeLink

### Method 1: Using the Running Local Server
The server is already running! Open your browser and go to:
```
http://localhost:3000
```

### Method 2: Direct in File Explorer
1. Open File Explorer to `D:\USER DATA\Documents\HopeLink`.
2. Double-click **`index.html`** to open it directly in any modern browser.

### Method 3: Starting the Server in Terminal
```bash
node server.js
```
*(or run `npm start`)*
