// Simple, zero-dependency static server for HopeLink (Local + Network + Tunnel ready)
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".zip": "application/zip",
};

const server = http.createServer((req, res) => {
  // Enable CORS so external devices/tunnel can fetch assets seamlessly
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  // Normalize URL path to prevent directory traversal
  let reqPath = req.url.split("?")[0];
  if (reqPath === "/") reqPath = "/index.html";

  const safeSuffix = path.normalize(reqPath).replace(/^(\.\.[\/\\])+/, "");
  const filePath = path.join(PUBLIC_DIR, safeSuffix);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
      res.end("<h1>404 Not Found</h1><p>The requested file was not found.</p>");
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || "application/octet-stream";

    res.writeHead(200, { "Content-Type": contentType });
    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

// Bind to 0.0.0.0 so all devices on Wi-Fi/Ethernet/Hotspot can access it
server.listen(PORT, "0.0.0.0", () => {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === "IPv4" && !net.internal) {
        ips.push({ name, ip: net.address });
      }
    }
  }

  console.log(`\n============================================================`);
  console.log(`🌱 HopeLink Server is Live & Accessible to Everyone!`);
  console.log(`============================================================`);
  console.log(`> Local PC (Only this computer):  http://localhost:${PORT}`);
  ips.forEach((item) => {
    console.log(`> Network (${item.name} / Wi-Fi):       http://${item.ip}:${PORT}`);
  });
  console.log(`\n📱 Any mobile phone, tablet, or laptop connected to`);
  console.log(`   the same Wi-Fi / Hotspot can open:`);
  ips.forEach((item) => {
    console.log(`   👉 http://${item.ip}:${PORT}`);
  });
  console.log(`============================================================\n`);
});
