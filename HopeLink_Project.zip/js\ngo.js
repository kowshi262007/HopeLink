/**
 * HopeLink - Verified NGO Portal & Claim System (ngo.js)
 * 
 * Manages:
 * - NGO Profile Switcher (Akshaya, Karuna, Seva, Annam)
 * - Feed of available surplus food listings with high quality food imagery
 * - Search & multi-filter criteria + quick filter chips
 * - Transparent match score breakdown modal
 * - Claiming, releasing, and driver assignment
 * - Prevention of duplicate acceptance in same-browser demo
 */

const NgoModule = {
  activeNgoId: "ngo-grace",
  activeChip: "all",
  declinedIds: new Set(),

  init() {
    const state = window.HopeStore.getState();
    this.activeNgoId = state.selectedNgoId || "ngo-grace";
    this.renderNgoSelector();
    this.bindFilterEvents();
    this.bindQuickChips();
    this.renderFeed();
  },

  setActiveNgo(ngoId) {
    this.activeNgoId = ngoId;
    window.HopeStore.updateState({ selectedNgoId: ngoId });
    this.renderNgoSelector();
    this.renderFeed();
    window.App && window.App.showToast(`Active organization set to ${this.getCurrentNgo().name}`, "info");
  },

  getCurrentNgo() {
    return window.HopeStore.getNgoById(this.activeNgoId) || window.HopeStore.getNGOs()[0];
  },

  renderNgoSelector() {
    const select = document.getElementById("ngoProfileSelect");
    if (!select) return;

    const ngos = window.HopeStore.getNGOs();
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    select.innerHTML = ngos
      .map((n) => {
        const ngoName = isTa && n.name_ta ? n.name_ta : n.name;
        const capLabel = isTa ? `${n.capacityPortions} உணவுகள்` : `${n.capacityPortions} meals`;
        return `
          <option value="${n.id}" ${n.id === this.activeNgoId ? "selected" : ""}>
            ${ngoName} [${n.zone} • ${capLabel}]
          </option>
        `;
      })
      .join("");

    select.onchange = (e) => this.setActiveNgo(e.target.value);

    // Update active NGO info header
    const current = this.getCurrentNgo();
    const infoCard = document.getElementById("activeNgoInfoCard");
    if (infoCard && current) {
      const ngoName = isTa && current.name_ta ? current.name_ta : current.name;
      const verifiedTag = isTa ? "✓ சரிபார்க்கப்பட்ட NGO" : "✓ Verified NGO Partner";
      const maxBatchLabel = isTa ? `கொள்ளளவு: ${current.capacityPortions} உணவுகள்` : `Capacity: ${current.capacityPortions} meals`;
      const vegTag = isTa
        ? (current.acceptsNonVeg ? "சைவம் & அசைவம்" : "சைவ உணவு மட்டுமே")
        : (current.acceptsNonVeg ? "Veg & Non-Veg" : "Pure Veg Only");
      const assignedLabel = isTa ? `🚗 வாகனம்: ${current.activeDriver}` : `🚗 Vehicle: ${current.activeDriver}`;

      infoCard.innerHTML = `
        <div class="ngo-meta-banner">
          <div class="ngo-meta-top-row">
            <div class="ngo-avatar-large">🏢</div>
            <div class="ngo-meta-header-text">
              <div class="ngo-title-pill-wrap">
                <h3 class="ngo-title-name">${ngoName}</h3>
                <span class="tag-pill tag-pill-verified">${verifiedTag}</span>
              </div>
              <p class="ngo-meta-info-line">📍 ${current.zone} • ⏱️ ${current.operatingHours}</p>
              <p class="ngo-meta-phone-line">📞 <a href="tel:${current.phone}" style="color:inherit;text-decoration:none;">${current.phone}</a></p>
            </div>
          </div>
          <div class="ngo-tags-row">
            <span class="tag-pill">📦 ${maxBatchLabel}</span>
            <span class="tag-pill ${current.acceptsNonVeg ? '' : 'tag-pill-green'}">🥗 ${vegTag}</span>
            <span class="tag-pill tag-pill-vehicle">${assignedLabel}</span>
          </div>
        </div>
      `;
    }
  },

  bindQuickChips() {
    document.querySelectorAll(".quick-filter-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        document.querySelectorAll(".quick-filter-chip").forEach((c) => c.classList.remove("active"));
        chip.classList.add("active");
        this.activeChip = chip.getAttribute("data-chip");
        this.renderFeed();
      });
    });
  },

  bindFilterEvents() {
    const searchInput = document.getElementById("ngoSearchInput");
    const catFilter = document.getElementById("ngoCategoryFilter");
    const dietFilter = document.getElementById("ngoDietaryFilter");
    const urgencyFilter = document.getElementById("ngoUrgencyFilter");

    const triggerRender = () => this.renderFeed();

    if (searchInput) searchInput.addEventListener("input", triggerRender);
    if (catFilter) catFilter.addEventListener("change", triggerRender);
    if (dietFilter) dietFilter.addEventListener("change", triggerRender);
    if (urgencyFilter) urgencyFilter.addEventListener("change", triggerRender);
  },

  updateStatCounters(allDonations) {
    const pendingEl = document.getElementById("statPendingCount");
    const acceptedEl = document.getElementById("statAcceptedCount");
    const declinedEl = document.getElementById("statDeclinedCount");
    const pickedEl = document.getElementById("statPickedCount");

    if (!pendingEl) return;

    const currentNgo = this.getCurrentNgo();
    const pending = allDonations.filter(
      (d) => d.status === "available" && !this.declinedIds.has(d.id)
    ).length;
    const accepted = allDonations.filter(
      (d) => d.assignedNgoId === currentNgo.id && d.status === "accepted"
    ).length;
    const picked = allDonations.filter(
      (d) =>
        d.status === "assigned" ||
        d.status === "collected" ||
        d.status === "distributed"
    ).length;
    const declined = this.declinedIds.size;

    pendingEl.textContent = pending;
    acceptedEl.textContent = accepted;
    declinedEl.textContent = declined;
    pickedEl.textContent = picked;
  },

  declineDonation(donationId) {
    this.declinedIds.add(donationId);
    this.renderFeed();
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    const msg = isTa
      ? "உணவு சேகரிப்பு கோரிக்கை நிராகரிக்கப்பட்டு பிற தொண்டு அமைப்புகளுக்கு மாற்றப்பட்டது."
      : "Donation declined. Request released back to other nearby charities.";
    window.App && window.App.showToast(msg, "info");
  },

  renderFeed() {
    const container = document.getElementById("ngoDonationsFeed");
    if (!container) return;

    const currentNgo = this.getCurrentNgo();
    const allDonations = window.HopeStore.getDonations();

    this.updateStatCounters(allDonations);

    const query = (document.getElementById("ngoSearchInput")?.value || "").toLowerCase();
    const cat = document.getElementById("ngoCategoryFilter")?.value || "all";
    const diet = document.getElementById("ngoDietaryFilter")?.value || "all";
    const urgency = document.getElementById("ngoUrgencyFilter")?.value || "all";

    const filtered = allDonations.filter((d) => {
      if (this.declinedIds.has(d.id)) return false;
      const matchesQuery =
        !query ||
        d.foodName.toLowerCase().includes(query) ||
        d.donorName.toLowerCase().includes(query) ||
        d.location.toLowerCase().includes(query);

      let matchesCat = cat === "all" || d.category === cat;
      let matchesDiet = diet === "all" || d.dietary === diet;

      const hoursLeft = (new Date(d.deadline).getTime() - Date.now()) / (1000 * 60 * 60);
      let matchesUrgency = true;
      if (urgency === "urgent_2h") matchesUrgency = hoursLeft <= 2;
      else if (urgency === "urgent_4h") matchesUrgency = hoursLeft <= 4;

      // Quick Chips overrides
      if (this.activeChip === "cooked") matchesCat = d.category === "cooked";
      else if (this.activeChip === "bakery") matchesCat = d.category === "bakery";
      else if (this.activeChip === "produce") matchesCat = d.category === "produce";
      else if (this.activeChip === "veg") matchesDiet = d.dietary === "veg";
      else if (this.activeChip === "urgent") matchesUrgency = hoursLeft <= 2.5;

      return matchesQuery && matchesCat && matchesDiet && matchesUrgency;
    });

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">🔍</span>
          <h4>${isTa ? "வடிகட்டிகளுக்குப் பொருத்தமான உணவுகள் இல்லை" : "No Donations Matching Filters"}</h4>
          <p class="text-muted">${isTa ? "வடிகட்டிகளை மாற்றிப் பார்க்கவும் அல்லது மாதிரி உணவு காட்சியை கிளிக் செய்யவும்." : "Try resetting search filters or injecting a live demo scenario."}</p>
          <button class="btn btn-outline btn-sm mt-3" onclick="NgoModule.resetFilters()">${isTa ? "வடிகட்டிகளை மீட்டமைக்க" : "Reset Filters"}</button>
        </div>
      `;
      return;
    }

    const currentNgoDisplayName = isTa && currentNgo.name_ta ? currentNgo.name_ta : currentNgo.name;

    container.innerHTML = filtered
      .map((d) => {
        const matchData = window.MatchingEngine.calculateMatch(d, currentNgo);
        const hoursLeft = (new Date(d.deadline).getTime() - Date.now()) / (1000 * 60 * 60);
        const isExpiringSoon = hoursLeft > 0 && hoursLeft <= 2;
        const isOverdue = hoursLeft <= 0;

        const isClaimedByMe = d.assignedNgoId === currentNgo.id;
        const isClaimedByOther = d.assignedNgoId && d.assignedNgoId !== currentNgo.id;

        const isVeg = d.dietary === "veg";
        const dietLabel = isVeg
          ? (isTa ? "🟢 சைவம்" : "🟢 Pure Veg")
          : (isTa ? "🔴 அசைவம்" : "🔴 Non-Veg");
        const dietBadge = `<span class="tag-dietary ${isVeg ? 'diet-veg' : 'diet-nonveg'}">${dietLabel}</span>`;
        const statusLabel = window.i18n ? window.i18n.t("badge_" + d.status) : d.status.toUpperCase();

        const fromLabel = isTa ? "வழங்குபவர்:" : "From:";
        const donorTypeLabel = window.i18n ? (window.i18n.t("donor_" + d.donorType) || d.donorType) : d.donorType;
        const unitLabel = window.i18n ? (window.i18n.t("unit_" + d.unit) || d.unit) : d.unit;
        const scoreLabel = isTa ? "பொருத்தப் புள்ளி" : "Match Score";
        const transparentLabel = isTa ? "விதிமுறை ⓘ" : "Transparent ⓘ";
        const deadlineLabel = isTa ? "காலக்கெடு:" : "Deadline:";
        const pickupLabel = isTa ? "முகவரி:" : "Pickup:";

        const claimBtnText = isTa ? `ஏற்றுக்கொண்டு ${currentNgoDisplayName}க்கு ஒதுக்குக` : `Accept & Claim for ${currentNgo.name}`;
        const assignBtnText = isTa ? "🛵 ஓட்டுநரை நியமிக்க" : "🛵 Assign Driver";
        const releaseBtnText = isTa ? "பொதுப் பட்டியலுக்கு மாற்றுக" : "Release to Pool";
        const trackPickupBtnText = isTa ? "சேகரிப்பைக் காண்க ↗" : "Track Pickup ↗";
        const viewInTrackerBtnText = isTa ? "கண்காணிப்பில் காண்க ↗" : "View in Tracker ↗";

        const expiringPulseText = isTa ? `⚡ ${hoursLeft.toFixed(1)} மணி நேரத்தில் முடியும்` : `⚡ Expiring in ${hoursLeft.toFixed(1)}h`;
        const overdueTagText = isTa ? "⚠️ நேரம் கடந்தது" : "⚠️ Overdue Window";

        return `
          <div class="card ngo-listing-card ${isClaimedByMe ? 'card-claimed-active' : ''}">
            <div class="ngo-card-image-header">
              <img src="${d.imageUrl || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80'}" alt="${d.foodName}" class="ngo-card-img" loading="lazy">
              
              <div class="card-img-overlay-tags">
                ${dietBadge}
                <span class="badge status-${d.status}">${statusLabel}</span>
              </div>

              ${isExpiringSoon ? `<span class="badge-urgent-pulse">${expiringPulseText}</span>` : ''}
              ${isOverdue ? `<span class="badge-overdue-tag">${overdueTagText}</span>` : ''}
            </div>

            <div class="listing-body">
              <div class="listing-top-bar">
                <div>
                  <span class="badge status-available" style="font-size: 0.68rem; margin-bottom: 0.25rem; display: inline-block;">
                    ${isTa ? "உபரி உணவு சேகரிப்பு கோரிக்கை" : "Surplus food pickup request"}
                  </span>
                  <h3 class="listing-title">${d.foodName}</h3>
                  <p class="listing-donor">${fromLabel} <strong>${d.donorName}</strong> (${donorTypeLabel})</p>
                </div>

                <!-- Match Score Badge -->
                <div class="score-badge-wrapper" onclick="NgoModule.showScoreModal('${d.id}')" title="Click for transparent algorithm score breakdown">
                  <span class="score-circle ${matchData.totalScore >= 70 ? 'score-high' : 'score-med'}">
                    ${matchData.totalScore}
                  </span>
                  <div class="score-label">
                    <strong>${scoreLabel}</strong>
                    <small>${transparentLabel}</small>
                  </div>
                </div>
              </div>

              <p class="listing-desc">${d.foodDescription}</p>

              ${Array.isArray(d.foodBreakdown) && d.foodBreakdown.length > 0 ? `
                <div class="itemized-food-box">
                  <strong>${isTa ? "📋 வகைப்படுத்தப்பட்ட உணவுப் பட்டியல்:" : "📋 Itemized Food Breakdown:"}</strong>
                  <ul>
                    ${d.foodBreakdown.map(b => `<li>${b.item}: <strong>${b.qty}</strong></li>`).join("")}
                  </ul>
                </div>
              ` : ''}

              ${d.contactPhone ? `
                <div class="donor-contact-row">
                  <span class="text-muted small">${isTa ? "தொடர்பு எண்:" : "Donor Contact:"}</span>
                  <a href="tel:${d.contactPhone}" class="contact-phone-btn">
                    📞 ${d.contactPhone}
                  </a>
                </div>
              ` : ''}

              <div class="listing-specs">
                <span>🍽️ <strong>${d.quantity} ${unitLabel}</strong> (~${d.estimatedKg} kg)</span>
                <span>📦 ${d.storageCondition.replace('_', ' ')}</span>
                <span>⏰ ${deadlineLabel} <strong>${new Date(d.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong></span>
              </div>

              <p class="listing-address">📍 <strong>${pickupLabel}</strong> ${d.location}</p>
            </div>

            <div class="listing-footer">
              ${d.status === "available" ? `
                <div class="request-dual-actions">
                  <button class="btn btn-primary btn-sm" onclick="NgoModule.claimDonation('${d.id}')">
                    ✓ ${isTa ? "சேகரிப்பை ஏற்கவும்" : "Accept pickup"}
                  </button>
                  <button class="btn btn-outline btn-sm" onclick="NgoModule.declineDonation('${d.id}')">
                    ✕ ${isTa ? "நிராகரிக்க" : "Decline"}
                  </button>
                </div>
              ` : ''}

              ${isClaimedByMe && d.status === "accepted" ? `
                <div class="claimed-actions-row">
                  <button class="btn btn-secondary btn-sm" onclick="NgoModule.openDriverModal('${d.id}')">
                    ${assignBtnText}
                  </button>
                  <button class="btn btn-outline-danger btn-sm" onclick="NgoModule.releaseDonation('${d.id}')">
                    ${releaseBtnText}
                  </button>
                  <button class="btn btn-outline btn-sm" onclick="App.navigateTo('tracker'); TrackingModule.selectDonation('${d.id}');">
                    ${trackPickupBtnText}
                  </button>
                </div>
              ` : ''}

              ${isClaimedByMe && (d.status === "assigned" || d.status === "collected") ? `
                <div class="claimed-assigned-bar">
                  <span>${isTa ? 'ஒதுக்கப்பட்டது:' : 'Assigned to:'} <strong>${d.driverName || (isTa ? 'வாகனம் கிளம்பியது' : 'Driver Dispatched')}</strong></span>
                  <button class="btn btn-secondary btn-sm" onclick="App.navigateTo('tracker'); TrackingModule.selectDonation('${d.id}');">
                    ${viewInTrackerBtnText}
                  </button>
                </div>
              ` : ''}

              ${isClaimedByOther ? `
                <div class="claimed-by-other-tag">
                  🔒 ${isTa ? `ஏற்கப்பட்டது: ${d.assignedNgoName} (இருமுறை ஏற்பது தடுக்கப்பட்டுள்ளது)` : `Locked: Claimed by ${d.assignedNgoName} (Duplicate acceptance prevented)`}
                </div>
              ` : ''}
            </div>
          </div>
        `;
      })
      .join("");
  },

  resetFilters() {
    const s = document.getElementById("ngoSearchInput");
    const c = document.getElementById("ngoCategoryFilter");
    const d = document.getElementById("ngoDietaryFilter");
    const u = document.getElementById("ngoUrgencyFilter");
    if (s) s.value = "";
    if (c) c.value = "all";
    if (d) d.value = "all";
    if (u) u.value = "all";
    this.activeChip = "all";
    document.querySelectorAll(".quick-filter-chip").forEach((chip) => {
      chip.classList.toggle("active", chip.getAttribute("data-chip") === "all");
    });
    this.renderFeed();
  },

  claimDonation(donationId) {
    const currentNgo = this.getCurrentNgo();
    const d = window.HopeStore.getDonationById(donationId);

    if (!d || d.status !== "available") {
      window.App && window.App.showToast("This donation is no longer available.", "warning");
      this.renderFeed();
      return;
    }

    if (d.dietary === "nonveg" && !currentNgo.acceptsNonVeg) {
      alert(`Cannot Claim: ${currentNgo.name} is strictly Pure Vegetarian and cannot accept non-veg items.`);
      return;
    }

    window.HopeStore.updateDonation(donationId, {
      status: "accepted",
      assignedNgoId: currentNgo.id,
      assignedNgoName: currentNgo.name,
      claimedAt: new Date().toISOString()
    });

    window.HopeStore.addNotification(
      "Donation Accepted",
      `${currentNgo.name} accepted donation #${donationId} (${d.foodName}).`,
      "success"
    );

    window.App && window.App.showToast(window.i18n.t("toast_claimed"), "success");
    this.renderFeed();
    if (window.App) window.App.renderHomeFeatured();
    if (window.DonorModule) window.DonorModule.renderMyDonations();
    if (window.ImpactModule) window.ImpactModule.updateMetrics();
  },

  releaseDonation(donationId) {
    if (confirm("Release this donation back to the open pool for other NGOs to claim?")) {
      window.HopeStore.updateDonation(donationId, {
        status: "available",
        assignedNgoId: null,
        assignedNgoName: null,
        driverName: null,
        driverPhone: null,
        claimedAt: null
      });

      window.App && window.App.showToast(window.i18n.t("toast_released"), "info");
      this.renderFeed();
      if (window.App) window.App.renderHomeFeatured();
      if (window.DonorModule) window.DonorModule.renderMyDonations();
    }
  },

  openDriverModal(donationId) {
    const modal = document.getElementById("driverAssignModal");
    if (!modal) return;

    const currentNgo = this.getCurrentNgo();
    document.getElementById("assignDonationId").value = donationId;
    document.getElementById("driverNameInput").value = currentNgo.activeDriver || "Karthik R. (Van)";
    document.getElementById("driverPhoneInput").value = "+91 98401 23456";

    modal.removeAttribute("hidden");
    setTimeout(() => modal.classList.add("active"), 10);
  },

  confirmDriverAssignment() {
    const donationId = document.getElementById("assignDonationId").value;
    const driverName = document.getElementById("driverNameInput").value.trim();
    const driverPhone = document.getElementById("driverPhoneInput").value.trim();

    if (!driverName) {
      window.App && window.App.showToast("Please enter driver name.", "warning");
      return;
    }

    window.HopeStore.updateDonation(donationId, {
      status: "assigned",
      driverName,
      driverPhone
    });

    window.HopeStore.addNotification(
      "Driver Assigned",
      `Driver ${driverName} assigned to pickup donation #${donationId}.`,
      "info"
    );

    const modal = document.getElementById("driverAssignModal");
    if (modal) {
      modal.classList.remove("active");
      setTimeout(() => modal.setAttribute("hidden", ""), 200);
    }

    window.App && window.App.showToast(window.i18n.t("toast_assigned"), "success");
    this.renderFeed();
    if (window.TrackingModule) window.TrackingModule.renderTracker();
  },

  showScoreModal(donationId) {
    const d = window.HopeStore.getDonationById(donationId);
    const currentNgo = this.getCurrentNgo();
    if (!d || !currentNgo) return;

    const matchData = window.MatchingEngine.calculateMatch(d, currentNgo);
    const modal = document.getElementById("matchScoreBreakdownModal");
    if (!modal) return;

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    const unitLabel = window.i18n ? (window.i18n.t("unit_" + d.unit) || d.unit) : d.unit;
    const ptsWord = isTa ? "புள்ளிகள்" : "pts";

    document.getElementById("modalScoreTotal").textContent = `${matchData.totalScore}/100`;
    document.getElementById("modalScoreNgo").textContent = isTa && currentNgo.name_ta ? currentNgo.name_ta : currentNgo.name;
    document.getElementById("modalScoreFood").textContent = `${d.foodName} (${d.quantity} ${unitLabel})`;

    document.getElementById("modalDistScore").textContent = `+${matchData.breakdown.distancePts} ${ptsWord} (~${currentNgo.distanceKm} km)`;
    document.getElementById("modalUrgScore").textContent = `+${matchData.breakdown.urgencyPts} ${ptsWord}`;
    document.getElementById("modalSuitScore").textContent = `+${matchData.breakdown.suitabilityPts} ${ptsWord}`;
    document.getElementById("modalCapScore").textContent = `+${matchData.breakdown.capacityPts} ${ptsWord}`;

    if (isTa) {
      document.getElementById("modalScoreExpl").textContent = matchData.isHardMismatch
        ? "இந்த தொண்டு நிறுவனம் முற்றிலும் சைவ உணவு மட்டுமே ஏற்கக்கூடியது; அசைவ உணவை ஏற்க இயலாது."
        : `மதிப்பெண்: ${matchData.totalScore}/100 [தூரம்: +${matchData.breakdown.distancePts}, அவசரம்: +${matchData.breakdown.urgencyPts}, பொருத்தம்: +${matchData.breakdown.suitabilityPts}, கொள்ளளவு: +${matchData.breakdown.capacityPts}]. வெளிப்படையான விதிமுறைப்படி கணக்கிடப்பட்டது.`;
    } else {
      document.getElementById("modalScoreExpl").textContent = matchData.explanation;
    }

    modal.removeAttribute("hidden");
    setTimeout(() => modal.classList.add("active"), 10);
  }
};

window.NgoModule = NgoModule;
