/**
 * HopeLink - Recurring Donation Schedules (schedules.js)
 * 
 * Manages:
 * - Recurring schedules for hotels, banquet halls, canteens
 * - Daily, weekly, or specific days scheduling
 * - Pause, resume, delete actions
 * - One-click "Post Today's Listing" generator
 */

const SchedulesModule = {
  init() {
    this.bindFormEvents();
    this.renderSchedules();
  },

  bindFormEvents() {
    const form = document.getElementById("recurringScheduleForm");
    if (!form) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.handleFormSubmit();
    });
  },

  handleFormSubmit() {
    const donorName = document.getElementById("schedDonorName")?.value.trim();
    const donorType = document.getElementById("schedDonorType")?.value;
    const foodType = document.getElementById("schedFoodType")?.value.trim();
    const frequency = document.getElementById("schedFrequency")?.value;
    const estimatedPortions = parseInt(document.getElementById("schedPortions")?.value, 10);
    const preferredTime = document.getElementById("schedTime")?.value;
    const pickupLocation = document.getElementById("schedLocation")?.value.trim();
    const contactPhone = document.getElementById("schedPhone")?.value.trim();

    if (!donorName || !foodType || !estimatedPortions || !pickupLocation || !contactPhone) {
      window.App && window.App.showToast("Please fill in all schedule fields.", "warning");
      return;
    }

    const newSchedule = {
      donorName,
      donorType,
      foodType,
      frequency,
      customDays: frequency === "daily" ? ["Every Day"] : ["Weekends"],
      estimatedPortions,
      preferredTime: preferredTime || "14:00",
      pickupLocation,
      contactPhone,
      status: "active"
    };

    window.HopeStore.saveSchedule(newSchedule);
    document.getElementById("recurringScheduleForm").reset();
    window.App && window.App.showToast("Recurring schedule saved successfully!", "success");
    this.renderSchedules();
  },

  renderSchedules() {
    const container = document.getElementById("schedulesListContainer");
    if (!container) return;

    const schedules = window.HopeStore.getSchedules();
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (schedules.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">📅</span>
          <h4>${isTa ? "தொடர் அட்டவணைகள் இல்லை" : "No Recurring Schedules"}</h4>
          <p>${isTa ? "சிற்றுண்டிச்சாலைகள் அல்லது மண்டபங்களின் வழக்கமான உபரி உணவுக்கு ஒரு அட்டவணையை உருவாக்கவும்." : "Create a recurring schedule for regular surplus from cafeterias or banquet halls."}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = schedules
      .map(
        (s) => {
          let freqLabel = s.frequency.toUpperCase();
          if (isTa) {
            if (s.frequency === "daily") freqLabel = "தினமும்";
            else if (s.frequency === "weekdays") freqLabel = "வார நாட்கள்";
            else if (s.frequency === "weekly") freqLabel = "வார இறுதி";
          }
          const fromLabel = isTa ? "வழங்குபவர்:" : "From:";
          const donorTypeLabel = window.i18n ? (window.i18n.t("donor_" + s.donorType) || s.donorType) : s.donorType;
          const portionsLabel = isTa ? `~${s.estimatedPortions} உணவுகள்` : `~${s.estimatedPortions} Portions`;
          const timeLabel = isTa ? "எதிர்பார்க்கப்படும் நேரம்:" : "Expected Time:";
          const postBtnText = isTa ? "⚡ இன்றைய உணவாகப் பதிவிடு" : "⚡ Post Today's Listing";
          const toggleBtnText = isTa ? (s.status === "active" ? "நிறுத்திவைக்க" : "தொடர") : (s.status === "active" ? "Pause" : "Resume");
          const deleteBtnText = isTa ? "நீக்க" : "Delete";

          return `
            <div class="card schedule-card ${s.status === 'paused' ? 'schedule-paused' : ''}">
              <div class="card-header">
                <span class="badge ${s.status === 'active' ? 'badge-success' : 'badge-neutral'}">
                  ${s.status.toUpperCase()}
                </span>
                <span class="frequency-tag">🔁 ${freqLabel}</span>
              </div>

              <div class="card-body">
                <h3>${s.foodType}</h3>
                <p>${fromLabel} <strong>${s.donorName}</strong> (${donorTypeLabel})</p>
                <div class="sched-meta-row">
                  <span>🍽️ ${portionsLabel}</span>
                  <span>⏰ ${timeLabel} <strong>${s.preferredTime}</strong></span>
                  <span>📍 ${s.pickupLocation}</span>
                </div>
              </div>

              <div class="card-actions">
                <button class="btn btn-primary btn-sm" onclick="SchedulesModule.triggerTodayListing('${s.id}')">
                  ${postBtnText}
                </button>
                <button class="btn btn-outline btn-sm" onclick="SchedulesModule.toggleStatus('${s.id}')">
                  ${toggleBtnText}
                </button>
                <button class="btn btn-outline-danger btn-sm" onclick="SchedulesModule.deleteSchedule('${s.id}')">
                  ${deleteBtnText}
                </button>
              </div>
            </div>
          `;
        }
      )
      .join("");
  },

  toggleStatus(id) {
    const s = window.HopeStore.getSchedules().find((item) => item.id === id);
    if (!s) return;
    const newStatus = s.status === "active" ? "paused" : "active";
    window.HopeStore.updateSchedule(id, { status: newStatus });
    this.renderSchedules();
    window.App && window.App.showToast(`Schedule is now ${newStatus}.`, "info");
  },

  deleteSchedule(id) {
    if (confirm("Delete this recurring schedule?")) {
      window.HopeStore.deleteSchedule(id);
      this.renderSchedules();
      window.App && window.App.showToast("Schedule removed.", "info");
    }
  },

  triggerTodayListing(id) {
    const s = window.HopeStore.getSchedules().find((item) => item.id === id);
    if (!s) return;

    const now = new Date();
    const deadline = new Date(now.getTime() + 4 * 60 * 60 * 1000); // 4 hours from now

    const donationData = {
      donorName: s.donorName,
      donorType: s.donorType,
      foodName: s.foodType,
      foodDescription: `Scheduled recurring batch for today. Freshly packed.`,
      category: "cooked",
      dietary: "veg",
      quantity: s.estimatedPortions,
      unit: "portions",
      estimatedKg: Math.round(s.estimatedPortions * 0.35),
      prepTime: now.toISOString(),
      deadline: deadline.toISOString(),
      storageCondition: "hot_insulated",
      allergens: [],
      location: s.pickupLocation,
      pickupInstructions: "Regular recurring collection. Contact security or kitchen supervisor.",
      contactPhone: s.contactPhone,
      hidePhone: false,
      status: "available",
      assignedNgoId: null,
      assignedNgoName: null,
      driverName: null,
      driverPhone: null,
      claimedAt: null,
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true
    };

    const saved = window.HopeStore.saveDonation(donationData);
    window.App && window.App.showToast(`⚡ Today's listing #${saved.id} created and dispatched to NGO feed!`, "success");

    if (window.DonorModule) window.DonorModule.renderMyDonations();
    if (window.NgoModule) window.NgoModule.renderFeed();
    if (window.ImpactModule) window.ImpactModule.updateMetrics();
  }
};

window.SchedulesModule = SchedulesModule;
