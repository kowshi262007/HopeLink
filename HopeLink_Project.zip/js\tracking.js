/**
 * HopeLink - Live Pickup & Lifecycle Tracking (tracking.js)
 * 
 * Features:
 * - Waze-Themed Live Navigation Map with Esri World Street Map (Zero watermark!)
 * - Waze Top Maneuver Navigation Banner & Compact Bottom Telemetry Pill
 * - Glowing Waze-style Cyan/Blue Route Polyline with Direction Chevrons
 * - Waze 3D Delivery Vehicle Avatar with glowing headlight illumination cone
 * - Dynamic Chennai metro route coordinates for all orders
 * - Robust Tamil and English Speech Synthesis
 * - 5-Stage visual progress stepper
 * - Backup NGO recommendation engine
 */

const TrackingModule = {
  selectedDonationId: "HL-2026-106", // Default to active tracked donation
  activeMapInstance: null,
  currentTileLayer: null,
  activeLayerType: "waze",
  liveSimInterval: null,
  isSimulating: false,
  simProgress: 0.15,
  simVehicleMarker: null,
  simRouteCoords: [],
  currentRouteData: null,

  // Realistic Metro Route Data for Demo Orders with Real City Separation
  TRACKING_ROUTES: {
    "HL-2026-100": {
      donor: { name: "Shree Krishna Caterers", address: "TechPark Tower 3, OMR IT Corridor", coords: [12.9750, 80.2500] },
      shelter: { name: "Seva Open Kitchen Trust", address: "T. Nagar, Central Zone", coords: [13.0418, 80.2341] },
      driver: { name: "Suresh M.", vehicle: "Auto-Rickshaw TN-09-AX-4412", phone: "+91 98402 34567" },
      totalDistKm: 8.4,
      roadName: "Rajiv Gandhi IT Expressway (OMR) → Anna Salai",
      waypoints: [
        [12.9750, 80.2500],
        [12.9920, 80.2450],
        [13.0100, 80.2380],
        [13.0260, 80.2350],
        [13.0418, 80.2341]
      ]
    },
    "HL-2026-101": {
      donor: { name: "Sunrise Grand Buffet & Banquet", address: "Anna Nagar West", coords: [13.0850, 80.2000] },
      shelter: { name: "Karuna Shelter & Elderly Care", address: "Anna Nagar East", coords: [13.0780, 80.2450] },
      driver: { name: "Karthik R.", vehicle: "Volunteer Delivery Van TN-02-B-9988", phone: "+91 98401 23456" },
      totalDistKm: 4.8,
      roadName: "2nd Avenue → Kilpauk Garden Road",
      waypoints: [
        [13.0850, 80.2000],
        [13.0830, 80.2150],
        [13.0810, 80.2300],
        [13.0780, 80.2450]
      ]
    },
    "HL-2026-102": {
      donor: { name: "Green Leaf Organic Bistro", address: "42 Green Avenue, Central Zone", coords: [13.0600, 80.2600] },
      shelter: { name: "Akshaya Community Food Bank", address: "MG Road, Central Zone", coords: [13.0380, 80.2200] },
      driver: { name: "Priya V.", vehicle: "E-Cargo Bike TN-01-EV-102", phone: "+91 98403 45678" },
      totalDistKm: 3.8,
      roadName: "Cathedral Road → Mount Road Flyover",
      waypoints: [
        [13.0600, 80.2600],
        [13.0530, 80.2460],
        [13.0460, 80.2320],
        [13.0380, 80.2200]
      ]
    },
    "HL-2026-103": {
      donor: { name: "Taj Connemara Events", address: "Binny Road, Triplicane", coords: [13.0620, 80.2650] },
      shelter: { name: "Annam Hunger Relief Foundation", address: "South Zone, Guindy", coords: [13.0080, 80.2050] },
      driver: { name: "Arun K.", vehicle: "Tata Ace Delivery Truck TN-09-5678", phone: "+91 98404 56789" },
      totalDistKm: 7.6,
      roadName: "Anna Salai Arterial Corridor → Guindy Estate",
      waypoints: [
        [13.0620, 80.2650],
        [13.0480, 80.2480],
        [13.0320, 80.2320],
        [13.0180, 80.2160],
        [13.0080, 80.2050]
      ]
    },
    "HL-2026-106": {
      donor: { name: "TechPark Corporate Cafeteria", address: "TechPark Tower 3, OMR IT Corridor", coords: [12.9800, 80.2520] },
      shelter: { name: "Seva Open Kitchen Trust", address: "T. Nagar Relief Center", coords: [13.0420, 80.2340] },
      driver: { name: "Priya V.", vehicle: "Food Rescue Van DL-04", phone: "+91 98403 45678" },
      totalDistKm: 8.1,
      roadName: "Rajiv Gandhi IT Expressway → T. Nagar Flyover",
      waypoints: [
        [12.9800, 80.2520],
        [12.9950, 80.2460],
        [13.0120, 80.2400],
        [13.0280, 80.2360],
        [13.0420, 80.2340]
      ]
    }
  },

  getRouteForDonation(donation) {
    if (this.TRACKING_ROUTES[donation.id]) {
      return this.TRACKING_ROUTES[donation.id];
    }
    // Dynamic fallback route based on donation metadata with realistic distance
    const donorCoords = [12.9850 + (Math.sin(donation.id.length) * 0.03), 80.2550 + (Math.cos(donation.id.length) * 0.02)];
    const shelterCoords = [13.0450, 80.2300];
    const mid1 = [(donorCoords[0] * 2 + shelterCoords[0]) / 3, (donorCoords[1] * 2 + shelterCoords[1]) / 3 + 0.006];
    const mid2 = [(donorCoords[0] + shelterCoords[0] * 2) / 3, (donorCoords[1] + shelterCoords[1] * 2) / 3 - 0.005];

    return {
      donor: { name: donation.donorName, address: donation.location || "Pickup Kitchen", coords: donorCoords },
      shelter: { name: donation.assignedNgoName || "Verified Partner Shelter", address: "Designated Relief Center", coords: shelterCoords },
      driver: { name: donation.driverName || "Karthik R. (Volunteer Driver)", vehicle: "Food Rescue Van DL-04", phone: "+91 98401 23456" },
      totalDistKm: 5.6,
      roadName: "Metro Arterial Green Corridor",
      waypoints: [donorCoords, mid1, mid2, shelterCoords]
    };
  },

  getInitialProgressForStatus(status) {
    switch (status) {
      case "available": return 0.0;
      case "accepted": return 0.15;
      case "assigned": return 0.45;
      case "collected": return 0.75;
      case "distributed": return 1.0;
      default: return 0.15;
    }
  },

  init() {
    const donation = window.HopeStore.getDonationById(this.selectedDonationId);
    this.simProgress = this.getInitialProgressForStatus(donation ? donation.status : "accepted");
    this.renderTracker();
  },

  selectDonation(donationId) {
    this.selectedDonationId = donationId;
    if (this.liveSimInterval) {
      clearInterval(this.liveSimInterval);
      this.liveSimInterval = null;
    }
    this.isSimulating = false;
    const donation = window.HopeStore.getDonationById(donationId);
    this.simProgress = this.getInitialProgressForStatus(donation ? donation.status : "accepted");
    this.renderTracker();
  },

  renderTracker() {
    const container = document.getElementById("trackerMainContainer");
    const selectEl = document.getElementById("trackerDonationSelect");
    if (!container) return;

    const donations = window.HopeStore.getDonations();

    // Populate dropdown
    if (selectEl) {
      selectEl.innerHTML = donations
        .map(
          (d) => `
          <option value="${d.id}" ${d.id === this.selectedDonationId ? "selected" : ""}>
            #${d.id} - ${d.foodName} [${d.status.toUpperCase()}]
          </option>
        `
        )
        .join("");

      selectEl.onchange = (e) => this.selectDonation(e.target.value);
    }

    const donation = window.HopeStore.getDonationById(this.selectedDonationId) || donations[0];
    if (!donation) {
      container.innerHTML = `
        <div class="empty-state">
          <h4>No Active Tracking Data</h4>
        </div>
      `;
      return;
    }

    // Determine stepper progress index (0 to 4)
    const stages = ["available", "accepted", "assigned", "collected", "distributed"];
    let currentStageIndex = stages.indexOf(donation.status);
    if (currentStageIndex === -1) currentStageIndex = 0;

    const hoursLeft = (new Date(donation.deadline).getTime() - Date.now()) / (1000 * 60 * 60);
    const isOverdue = hoursLeft <= 0 && (donation.status === "available" || donation.status === "accepted");

    // Backup NGO Suggestions
    const ngos = window.HopeStore.getNGOs();
    const rankedNgos = window.MatchingEngine.rankNgosForDonation(donation, ngos);
    const backupNgos = rankedNgos.filter((item) => item.ngo.id !== donation.assignedNgoId).slice(0, 2);

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    const overdueTitle = isTa ? "பாதுகாப்பான சேகரிப்பு நேரம் கடந்துவிட்டது!" : "Safe Collection Window Overdue!";
    const overdueDesc = isTa ? "கடைசி நேரம் கடந்துவிட்டது. விநியோகத்திற்கு முன் வாசனை மற்றும் வெப்ப பரிசோதனை கட்டாயமாகும்." : "The safe collection deadline passed. Physical sensory inspection (aroma/temperature) is mandatory before distribution.";

    const statusLabel = window.i18n ? window.i18n.t("badge_" + donation.status) : donation.status.toUpperCase();
    const trackCodeLabel = isTa ? "கண்காணிப்புக் குறியீடு:" : "Tracking Code:";
    const postedByLabel = isTa ? "வழங்குபவர்:" : "Posted by:";
    const readAloudLabel = isTa ? "🔊 வாசித்துக்கேட்க" : "🔊 Read Aloud";

    const qtyMeta = isTa ? "அளவு:" : "Quantity:";
    const catMeta = isTa ? "வகை:" : "Category:";
    const storageMeta = isTa ? "சேமிப்பு:" : "Storage:";
    const deadlineMeta = isTa ? "காலக்கெடு:" : "Safe Deadline:";

    const timelineTitle = isTa ? "உணவு மீட்புப் பயணப் பாதை" : "Rescue Journey Timeline";

    const step1Title = isTa ? "1. கிடைக்கும்" : "Available";
    const step1Sub = isTa ? "உணவு பதிவு செய்யப்பட்டது" : "Food listed";

    const step2Title = isTa ? "2. ஏற்கப்பட்டது" : "Accepted";
    const step2Sub = donation.assignedNgoName
      ? donation.assignedNgoName
      : (isTa ? "காப்பகத்தின் ஏற்புக்காக காத்திருக்கிறது" : "Waiting for claim");

    const step3Title = isTa ? "3. ஓட்டுநர் நியமனம்" : "Driver Dispatched";
    const step3Sub = donation.driverName || (isTa ? "ஓட்டுநர் நியமிக்கப்படவில்லை" : "Awaiting assignment");

    const step4Title = isTa ? "4. பெறப்பட்டது" : "Collected";
    const step4Sub = isTa ? "காப்பகத்திற்கு கொண்டு செல்லப்படுகிறது" : "In transit to shelter";

    const step5Title = isTa ? "5. பகிரப்பட்டது" : "Distributed";
    const step5Sub = isTa ? "மக்களுக்கு வழங்கப்பட்டது" : "Served to people";

    const controlsTag = isTa ? "மாதிரி செயல்பாடுகள்:" : "Interactive Lifecycle Controls:";
    const confirmCollectedBtn = isTa ? "✓ உணவு சேகரிக்கப்பட்டது என உறுதிசெய்" : "✓ Confirm Driver Picked Up Food";
    const confirmDistributedBtn = isTa ? "✓ மக்களுக்கு வழங்கப்பட்டது என உறுதிசெய்" : "✓ Confirm Distributed to Beneficiaries";
    const missionCompleteText = isTa ? "✓ பணி நிறைவடைந்தது! உணவு வழங்கப்பட்டது." : "✓ Mission Complete! Meals safely served.";

    // Micro Step Labels for Top Milestone Progress Bar (Clean & concise, zero overflow)
    const microStep1 = isTa ? "பதிவு" : "Listed";
    const microStep2 = isTa ? "ஏற்பு" : "Claimed";
    const microStep3 = isTa ? "பயணம்" : "En Route";
    const microStep4 = isTa ? "சேகரிப்பு" : "Picked Up";
    const microStep5 = isTa ? "வழங்கல்" : "Delivered";

    const activeStageName = currentStageIndex === 0 ? step1Title :
      currentStageIndex === 1 ? step2Title :
      currentStageIndex === 2 ? step3Title :
      currentStageIndex === 3 ? step4Title : step5Title;

    const activeStageDetail = currentStageIndex === 0 ? step1Sub :
      currentStageIndex === 1 ? step2Sub :
      currentStageIndex === 2 ? step3Sub :
      currentStageIndex === 3 ? step4Sub : step5Sub;

    const activeStageBadge = isTa 
      ? `⚡ தற்போதைய நிலை: படி ${currentStageIndex + 1} / 5` 
      : `⚡ Active Milestone: Stage ${currentStageIndex + 1} of 5`;

    // Route Metadata
    const routeData = this.getRouteForDonation(donation);
    this.currentRouteData = routeData;

    const mapTitle = isTa ? "🗺️ நேரலை வழிசெலுத்தல் வரைபடம் (Waze தீம்)" : "🗺️ Live Navigation Map (Waze Theme)";
    const liveGpsTag = isTa ? "நேரடி வழிசெலுத்தல்" : "LIVE NAVIGATION";
    const callDriverText = isTa ? "அழைக்க" : "Call Driver";
    const pickupHead = isTa ? "எடுக்கும் இடம் (வழங்குபவர்)" : "Pickup Location (Kitchen)";
    const dropoffHead = isTa ? "சேர்க்கும் இடம் (காப்பகம்)" : "Dropoff Location (Shelter)";

    container.innerHTML = `
      <!-- Overdue Banner -->
      ${isOverdue ? `
        <div class="alert-banner alert-danger">
          <span class="alert-icon">⚠️</span>
          <div>
            <strong>${overdueTitle}</strong>
            <p>${overdueDesc}</p>
          </div>
        </div>
      ` : ''}

      <!-- Donation Info Card -->
      <div class="card tracking-summary-card">
        <div class="tracking-summary-header">
          <div>
            <span class="badge status-${donation.status}">${statusLabel}</span>
            <h2>${donation.foodName}</h2>
            <p class="text-muted">${trackCodeLabel} <strong>#${donation.id}</strong> • ${postedByLabel} <strong>${donation.donorName}</strong></p>
          </div>
          <button class="btn btn-outline btn-sm" onclick="TrackingModule.speakStatus('${donation.id}')">
            ${readAloudLabel}
          </button>
        </div>

        <div class="tracking-meta-grid">
          <div><span class="meta-label">${qtyMeta}</span> <strong>${donation.quantity} ${donation.unit}</strong> (~${donation.estimatedKg} kg)</div>
          <div><span class="meta-label">${catMeta}</span> ${donation.category} (${donation.dietary === 'veg' ? (isTa ? 'சைவம்' : 'Pure Veg') : (isTa ? 'அசைவம்' : 'Non-Veg')})</div>
          <div><span class="meta-label">${storageMeta}</span> ${donation.storageCondition.replace('_', ' ')}</div>
          <div><span class="meta-label">${deadlineMeta}</span> <strong>${new Date(donation.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong></div>
        </div>
      </div>

      <!-- WAZE THEMED LIVE NAVIGATION MAP (Real Streets, Zero Watermark!) -->
      <div class="card tracking-map-card">
        <div class="map-header-row">
          <div class="map-header-left">
            <h3 class="map-card-title">${mapTitle}</h3>
            <span class="map-sub-road">${routeData.roadName}</span>
          </div>
          <div class="map-header-actions">
            <!-- Waze Layer Switcher -->
            <div class="map-layer-switch-pill">
              <button class="layer-pill-btn active" id="btnLayerWaze" onclick="TrackingModule.switchMapLayer('waze')">🗺️ Waze Streets</button>
              <button class="layer-pill-btn" id="btnLayerSat" onclick="TrackingModule.switchMapLayer('satellite')">🛰️ Satellite</button>
              <button class="layer-pill-btn" id="btnLayerTopo" onclick="TrackingModule.switchMapLayer('topo')">🧭 Topo</button>
            </div>
            <span class="badge-live-pulse">
              <span class="radar-dot"></span>
              ${liveGpsTag}
            </span>
          </div>
        </div>

        <div class="live-map-wrapper">
          <div id="liveRescueMap"></div>

          <!-- Waze Sleek Top Maneuver Banner -->
          <div class="waze-nav-banner-top">
            <div class="waze-maneuver-left">
              <span class="waze-turn-arrow">↱</span>
              <div class="waze-instruction-text">
                <strong id="wazeManeuverText">${isTa ? 'இன்னும் 350 மீட்டரில் வலதுபுறம் திரும்பவும்' : 'In 350m • Keep right on'} ${routeData.roadName.split('→')[0]}</strong>
                <small>${routeData.driver.name} • ${routeData.driver.vehicle}</small>
              </div>
            </div>
            <span class="waze-speed-pill" id="hudSpeedDisplay">⚡ 34 km/h</span>
          </div>

          <!-- Waze Sleek Bottom Navigation Pill (Responsive 2-Tier Alignment) -->
          <div class="waze-bottom-nav-bar">
            <!-- Row 1: Telemetry (ETA, Distance, Cold-Chain Temperature) -->
            <div class="waze-hud-telemetry-row">
              <div class="waze-eta-group">
                <span class="waze-eta-highlight" id="hudEtaDisplay">${isTa ? '⏱️ இன்னும் ~9 நிமி' : '⏱️ ETA ~9 mins'}</span>
                <span class="waze-dist-sub" id="hudDistDisplay">• ${routeData.distanceKm} km</span>
              </div>
              <div class="waze-temp-badge">
                <span class="temp-icon">❄️</span>
                <span class="temp-text">${isTa ? '4.2°C குளிர்சங்கிலி' : '4.2°C Cold Chain'}</span>
              </div>
            </div>

            <!-- Row 2: Action Controls (Call Driver, Recenter, Play/Pause Simulation) -->
            <div class="waze-hud-controls-row">
              <a href="tel:${routeData.driver.phone}" class="waze-call-driver-btn">
                <span class="call-icon">📞</span>
                <span class="call-label">${isTa ? 'ஓட்டுநரை அழைக்க' : 'Call Driver'} (${routeData.driver.name.split(' ')[0]})</span>
              </a>
              <div class="waze-tool-buttons-group">
                <button class="waze-icon-tool-btn" id="btnToggleSim" onclick="TrackingModule.toggleSimulation()" title="${isTa ? 'வாகன இயக்கம் / நிறுத்து' : 'Play / Pause Simulation'}">
                  ▶️
                </button>
                <button class="waze-icon-tool-btn" onclick="TrackingModule.recenterMap()" title="${isTa ? 'வரைபட மையம்' : 'Recenter Route'}">
                  🎯
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Route Legs Overview -->
        <div class="map-route-legs-info">
          <div class="leg-card pickup">
            <div class="leg-card-header">
              <span class="leg-dot-pin green"></span>
              <small>${pickupHead}</small>
            </div>
            <strong>${routeData.donor.name}</strong>
            <span>${routeData.donor.address}</span>
          </div>
          <div class="leg-card dropoff">
            <div class="leg-card-header">
              <span class="leg-dot-pin red"></span>
              <small>${dropoffHead}</small>
            </div>
            <strong>${routeData.shelter.name}</strong>
            <span>${routeData.shelter.address}</span>
          </div>
        </div>
      </div>

      <!-- 5-Stage Stepper (Ultra-Realistic 3D Delivery Journey Tracking) -->
      <div class="card stepper-card">
        <div class="stepper-header-row">
          <div class="stepper-title-group">
            <h3 class="stepper-title">${timelineTitle}</h3>
            <p class="stepper-subtitle text-muted small">${isTa ? 'நேரலை விநியோக செயல்முறை கண்காணிப்பு' : 'Live end-to-end food rescue lifecycle'}</p>
          </div>
          <span class="stepper-badge-counter">${isTa ? `படி ${currentStageIndex + 1} / 5` : `Step ${currentStageIndex + 1} of 5`}</span>
        </div>
        
        <!-- Tier 1: 3D Spherical Milestone Progress Bar -->
        <div class="stepper-progress-track">
          <!-- Step 1 -->
          <div class="stepper-track-node ${currentStageIndex >= 0 ? 'completed' : ''} ${currentStageIndex === 0 ? 'active' : ''}">
            <div class="node-circle-3d ${currentStageIndex > 0 ? 'done' : (currentStageIndex === 0 ? 'active' : 'pending')}">
              ${currentStageIndex > 0 ? '✓' : '1'}
            </div>
            <span class="node-label">${microStep1}</span>
          </div>
          <div class="node-track-pipe ${currentStageIndex >= 1 ? 'done' : ''}"></div>

          <!-- Step 2 -->
          <div class="stepper-track-node ${currentStageIndex >= 1 ? 'completed' : ''} ${currentStageIndex === 1 ? 'active' : ''}">
            <div class="node-circle-3d ${currentStageIndex > 1 ? 'done' : (currentStageIndex === 1 ? 'active' : 'pending')}">
              ${currentStageIndex > 1 ? '✓' : '2'}
            </div>
            <span class="node-label">${microStep2}</span>
          </div>
          <div class="node-track-pipe ${currentStageIndex >= 2 ? 'done' : ''}"></div>

          <!-- Step 3 -->
          <div class="stepper-track-node ${currentStageIndex >= 2 ? 'completed' : ''} ${currentStageIndex === 2 ? 'active' : ''}">
            <div class="node-circle-3d ${currentStageIndex > 2 ? 'done' : (currentStageIndex === 2 ? 'active' : 'pending')}">
              ${currentStageIndex > 2 ? '✓' : '3'}
            </div>
            <span class="node-label">${microStep3}</span>
          </div>
          <div class="node-track-pipe ${currentStageIndex >= 3 ? 'done' : ''}"></div>

          <!-- Step 4 -->
          <div class="stepper-track-node ${currentStageIndex >= 3 ? 'completed' : ''} ${currentStageIndex === 3 ? 'active' : ''}">
            <div class="node-circle-3d ${currentStageIndex > 3 ? 'done' : (currentStageIndex === 3 ? 'active' : 'pending')}">
              ${currentStageIndex > 3 ? '✓' : '4'}
            </div>
            <span class="node-label">${microStep4}</span>
          </div>
          <div class="node-track-pipe ${currentStageIndex >= 4 ? 'done' : ''}"></div>

          <!-- Step 5 (Classy Delivered Seal) -->
          <div class="stepper-track-node ${currentStageIndex >= 4 ? 'completed' : ''} ${currentStageIndex === 4 ? 'active' : ''}">
            <div class="node-circle-3d ${currentStageIndex >= 4 ? 'done' : 'pending'}">
              ${currentStageIndex >= 4 ? '✓' : '5'}
            </div>
            <span class="node-label">${microStep5}</span>
          </div>
        </div>

        <!-- Tier 2: Premium Live Mission Control Active Milestone Spotlight Card -->
        <div class="stepper-active-spotlight-card">
          <div class="spotlight-glass-header">
            <div class="spotlight-live-tag">
              <span class="live-dot-pulse"></span>
              <span>${isTa ? 'நேரடி மீட்பு நிலை' : 'LIVE RESCUE IN PROGRESS'}</span>
            </div>
            <span class="spotlight-stage-badge">${activeStageBadge}</span>
          </div>

          <div class="spotlight-main-content">
            <div class="spotlight-3d-badge-orb">
              ${currentStageIndex === 0 ? '📝' : (currentStageIndex === 1 ? '🏢' : (currentStageIndex === 2 ? '🚚' : (currentStageIndex === 3 ? '📦' : '🍲')))}
            </div>
            <div class="spotlight-text-block">
              <h4 class="spotlight-title-text">${activeStageName}</h4>
              <p class="spotlight-desc-text">${activeStageDetail}</p>
            </div>
          </div>

          <div class="spotlight-partner-strip">
            <div class="partner-meta-row">
              <span class="partner-chip-icon">🏢</span>
              <div class="partner-chip-text">
                <span class="partner-chip-role">${isTa ? 'காப்பகப் பங்காளர்' : 'Relief Partner'}</span>
                <strong>${donation.assignedNgoName || (isTa ? 'கிரேஸ் சேவா அறக்கட்டளை' : 'Grace Seva Foundation')}</strong>
              </div>
            </div>
            <div class="partner-meta-row">
              <span class="driver-chip-icon">🚗</span>
              <div class="driver-chip-text">
                <span class="partner-chip-role">${isTa ? 'மீட்பு வாகனம் / ஓட்டுநர்' : 'Assigned Courier / Driver'}</span>
                <strong>${donation.driverName || 'John D. (Volunteer Van)'}</strong>
              </div>
            </div>
          </div>
        </div>

        <!-- Tier 3: Realistic Vertical Courier Milestone Cards -->
        <div class="stepper-vertical-timeline">
          <!-- Step 1 Milestone -->
          <div class="v-milestone-card ${currentStageIndex >= 0 ? 'is-done' : ''} ${currentStageIndex === 0 ? 'is-current' : 'is-pending'}">
            <div class="v-card-bullet-pillar">
              <div class="v-bullet-orb ${currentStageIndex > 0 ? 'done' : (currentStageIndex === 0 ? 'active' : 'pending')}">
                ${currentStageIndex > 0 ? '✓' : '1'}
              </div>
              <div class="v-connector-pipe ${currentStageIndex >= 1 ? 'done' : ''}"></div>
            </div>
            <div class="v-card-surface">
              <div class="v-card-top-row">
                <div class="v-card-title-group">
                  <span class="v-milestone-icon">📝</span>
                  <strong>${step1Title}</strong>
                </div>
                <span class="v-milestone-status-badge ${currentStageIndex > 0 ? 'badge-done' : (currentStageIndex === 0 ? 'badge-current' : 'badge-pending')}">
                  ${currentStageIndex > 0 ? (isTa ? '✓ முடிந்தது' : '✓ Completed') : (currentStageIndex === 0 ? (isTa ? '⚡ தற்போதைய நிலை' : '⚡ In Progress') : (isTa ? '⏳ காத்திருக்கிறது' : '⏳ Pending'))}
                </span>
              </div>
              <p class="v-card-desc">${step1Sub}</p>
              <div class="v-card-micro-tags">
                <span class="v-micro-tag">🍽️ ${donation.quantity} ${donation.unit} (~${donation.estimatedKg} kg)</span>
                <span class="v-micro-tag">📍 ${donation.donorName}</span>
                <span class="v-micro-tag">❄️ ${donation.storageCondition.replace('_', ' ')}</span>
              </div>
            </div>
          </div>

          <!-- Step 2 Milestone -->
          <div class="v-milestone-card ${currentStageIndex >= 1 ? 'is-done' : ''} ${currentStageIndex === 1 ? 'is-current' : 'is-pending'}">
            <div class="v-card-bullet-pillar">
              <div class="v-bullet-orb ${currentStageIndex > 1 ? 'done' : (currentStageIndex === 1 ? 'active' : 'pending')}">
                ${currentStageIndex > 1 ? '✓' : '2'}
              </div>
              <div class="v-connector-pipe ${currentStageIndex >= 2 ? 'done' : ''}"></div>
            </div>
            <div class="v-card-surface">
              <div class="v-card-top-row">
                <div class="v-card-title-group">
                  <span class="v-milestone-icon">🏢</span>
                  <strong>${step2Title}</strong>
                </div>
                <span class="v-milestone-status-badge ${currentStageIndex > 1 ? 'badge-done' : (currentStageIndex === 1 ? 'badge-current' : 'badge-pending')}">
                  ${currentStageIndex > 1 ? (isTa ? '✓ ஏற்கப்பட்டது' : '✓ Claimed') : (currentStageIndex === 1 ? (isTa ? '⚡ தற்போதைய நிலை' : '⚡ In Progress') : (isTa ? '⏳ காத்திருக்கிறது' : '⏳ Pending'))}
                </span>
              </div>
              <p class="v-card-desc">${step2Sub}</p>
              <div class="v-card-micro-tags">
                <span class="v-micro-tag">🤝 ${isTa ? 'சரிபார்க்கப்பட்ட அமைப்பு' : 'Verified Shelter'}</span>
                <span class="v-micro-tag">📦 ${isTa ? '300 உணவுகள் சேமிப்பு' : '300 Portions Storage'}</span>
              </div>
            </div>
          </div>

          <!-- Step 3 Milestone -->
          <div class="v-milestone-card ${currentStageIndex >= 2 ? 'is-done' : ''} ${currentStageIndex === 2 ? 'is-current' : 'is-pending'}">
            <div class="v-card-bullet-pillar">
              <div class="v-bullet-orb ${currentStageIndex > 2 ? 'done' : (currentStageIndex === 2 ? 'active' : 'pending')}">
                ${currentStageIndex > 2 ? '✓' : '3'}
              </div>
              <div class="v-connector-pipe ${currentStageIndex >= 3 ? 'done' : ''}"></div>
            </div>
            <div class="v-card-surface">
              <div class="v-card-top-row">
                <div class="v-card-title-group">
                  <span class="v-milestone-icon">🚚</span>
                  <strong>${step3Title}</strong>
                </div>
                <span class="v-milestone-status-badge ${currentStageIndex > 2 ? 'badge-done' : (currentStageIndex === 2 ? 'badge-current' : 'badge-pending')}">
                  ${currentStageIndex > 2 ? (isTa ? '✓ வாகனம் புறப்பட்டது' : '✓ Dispatched') : (currentStageIndex === 2 ? (isTa ? '⚡ பயணத்தில்' : '⚡ Active Trip') : (isTa ? '⏳ காத்திருக்கிறது' : '⏳ Pending'))}
                </span>
              </div>
              <p class="v-card-desc">${step3Sub}</p>
              <div class="v-card-micro-tags">
                <span class="v-micro-tag">🚗 ${isTa ? 'வாகன எண் TN-09-5678' : 'Vehicle Reg: TN-09-5678'}</span>
                <span class="v-micro-tag">⏱️ ${isTa ? 'சேகரிப்பு நேரம் ~20 நிமி' : 'Pickup in ~20 mins'}</span>
              </div>
            </div>
          </div>

          <!-- Step 4 Milestone -->
          <div class="v-milestone-card ${currentStageIndex >= 3 ? 'is-done' : ''} ${currentStageIndex === 3 ? 'is-current' : 'is-pending'}">
            <div class="v-card-bullet-pillar">
              <div class="v-bullet-orb ${currentStageIndex > 3 ? 'done' : (currentStageIndex === 3 ? 'active' : 'pending')}">
                ${currentStageIndex > 3 ? '✓' : '4'}
              </div>
              <div class="v-connector-pipe ${currentStageIndex >= 4 ? 'done' : ''}"></div>
            </div>
            <div class="v-card-surface">
              <div class="v-card-top-row">
                <div class="v-card-title-group">
                  <span class="v-milestone-icon">📦</span>
                  <strong>${step4Title}</strong>
                </div>
                <span class="v-milestone-status-badge ${currentStageIndex > 3 ? 'badge-done' : (currentStageIndex === 3 ? 'badge-current' : 'badge-pending')}">
                  ${currentStageIndex > 3 ? (isTa ? '✓ பெறப்பட்டது' : '✓ Picked Up') : (currentStageIndex === 3 ? (isTa ? '⚡ சேகரிக்கப்படுகிறது' : '⚡ In Transit') : (isTa ? '⏳ காத்திருக்கிறது' : '⏳ Scheduled'))}
                </span>
              </div>
              <p class="v-card-desc">${step4Sub}</p>
              <div class="v-card-micro-tags">
                <span class="v-micro-tag">❄️ 4.2°C Cold Chain Inspected</span>
                <span class="v-micro-tag">🛡️ Hygiene Packaging Verified</span>
              </div>
            </div>
          </div>

          <!-- Step 5 Milestone -->
          <div class="v-milestone-card ${currentStageIndex >= 4 ? 'is-done' : ''} ${currentStageIndex === 4 ? 'is-current' : 'is-pending'}">
            <div class="v-card-bullet-pillar">
              <div class="v-bullet-orb ${currentStageIndex >= 4 ? 'done' : 'pending'}">
                ${currentStageIndex >= 4 ? '✓' : '5'}
              </div>
            </div>
            <div class="v-card-surface">
              <div class="v-card-top-row">
                <div class="v-card-title-group">
                  <span class="v-milestone-icon">🍲</span>
                  <strong>${step5Title}</strong>
                </div>
                <span class="v-milestone-status-badge ${currentStageIndex >= 4 ? 'badge-done' : 'badge-pending'}">
                  ${currentStageIndex >= 4 ? (isTa ? '✓ வழங்கப்பட்டது' : '✓ Delivered') : (isTa ? '🎯 இறுதி நிலை' : '🎯 Final Step')}
                </span>
              </div>
              <p class="v-card-desc">${step5Sub}</p>
              <div class="v-card-micro-tags">
                <span class="v-micro-tag">❤️ ${isTa ? 'மக்களுக்கு பரிமாறப்பட்டது' : 'Served to Beneficiaries'}</span>
                <span class="v-micro-tag">🌱 Zero Waste Mission</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Tier 4: Interactive Lifecycle Action Bar -->
        <div class="stepper-actions-bar">
          <div class="stepper-actions-header">
            <span class="demo-tag">⚡ ${controlsTag}</span>
          </div>
          ${donation.status === "assigned" ? `
            <button class="btn btn-secondary btn-lifecycle-action" onclick="TrackingModule.markCollected('${donation.id}')">
              ${confirmCollectedBtn}
            </button>
          ` : ''}

          ${donation.status === "collected" ? `
            <button class="btn btn-primary btn-lifecycle-action" onclick="TrackingModule.markDistributed('${donation.id}')">
              ${confirmDistributedBtn}
            </button>
          ` : ''}

          ${donation.status === "distributed" ? `
            <div class="stepper-completed-banner">
              <span class="trophy-icon">🏆</span>
              <strong>${missionCompleteText}</strong>
            </div>
          ` : ''}
        </div>
      </div>

      <!-- Backup NGO Suggestions -->
      <div class="card backup-ngo-card">
        <div class="card-header">
          <h3>${isTa ? "மாற்று தொண்டு நிறுவனம்" : "Backup NGO Suggestions"}</h3>
          <p class="text-muted small">${isTa ? "45 நிமிடங்களுக்குள் வர இயலாவிட்டால், மாற்று காப்பகத்திற்கு மாற்றவும்:" : "If current NGO cannot dispatch within 45 minutes, transfer to highest matching backup shelter:"}</p>
        </div>
        <div class="backup-ngo-grid">
          ${backupNgos.map(item => `
            <div class="backup-item">
              <div>
                <strong>${isTa && item.ngo.name_ta ? item.ngo.name_ta : item.ngo.name}</strong>
                <p class="text-muted small">📍 ${item.ngo.zone} (${item.ngo.distanceKm} km) • Score: ${item.totalScore}%</p>
              </div>
              <button class="btn btn-outline btn-xs" onclick="TrackingModule.transferToBackup('${donation.id}', '${item.ngo.id}')">
                ${isTa ? "மாற்றுக →" : "Transfer →"}
              </button>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    // Initialize Map on next tick
    setTimeout(() => {
      this.initMap(donation, routeData, isTa);
    }, 60);
  },

  switchMapLayer(layerKey) {
    if (!this.activeMapInstance || typeof window.L === "undefined") return;

    if (this.currentTileLayer) {
      this.activeMapInstance.removeLayer(this.currentTileLayer);
    }

    document.querySelectorAll(".layer-pill-btn").forEach(btn => btn.classList.remove("active"));
    const activeBtn = document.getElementById(layerKey === "satellite" ? "btnLayerSat" : (layerKey === "topo" ? "btnLayerTopo" : "btnLayerWaze"));
    if (activeBtn) activeBtn.classList.add("active");

    if (layerKey === "satellite") {
      this.currentTileLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 19,
        attribution: "Satellite &copy; Esri"
      }).addTo(this.activeMapInstance);
      this.activeLayerType = "satellite";
      if (window.App) window.App.showToast("🛰️ Switched to Satellite Topo Layer", "info");
    } else if (layerKey === "topo") {
      this.currentTileLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 19,
        attribution: "Topo &copy; Esri"
      }).addTo(this.activeMapInstance);
      this.activeLayerType = "topo";
      if (window.App) window.App.showToast("🧭 Switched to Topographical Map Layer", "info");
    } else {
      // Esri World Street Map (Crisp streets, ZERO watermark!)
      this.currentTileLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 19,
        attribution: "&copy; Esri World Street Map"
      }).addTo(this.activeMapInstance);
      this.activeLayerType = "waze";
      if (window.App) window.App.showToast("🗺️ Switched to Real Waze Street Map (Zero Watermark)", "info");
    }
  },

  initMap(donation, routeData, isTa) {
    const mapContainer = document.getElementById("liveRescueMap");
    if (!mapContainer) return;

    // Teardown any existing map instance and timer
    if (this.activeMapInstance) {
      try {
        this.activeMapInstance.remove();
      } catch (e) {}
      this.activeMapInstance = null;
    }
    if (this.liveSimInterval) {
      clearInterval(this.liveSimInterval);
      this.liveSimInterval = null;
    }

    const waypoints = routeData.waypoints;
    this.simRouteCoords = waypoints;

    // Check if Leaflet is available
    if (typeof window.L !== "undefined") {
      try {
        const map = L.map("liveRescueMap", {
          zoomControl: false,
          attributionControl: false
        });
        this.activeMapInstance = map;

        // Esri World Street Map (Zero watermark, real streets, highways, buildings!)
        this.currentTileLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", {
          maxZoom: 19
        }).addTo(map);

        // Custom Waze Vector Markers
        const donorIcon = L.divIcon({
          className: "custom-leaflet-marker",
          html: `
            <div class="marker-pin-wrap">
              <div class="marker-donor-pin">
                <span>🍲</span>
              </div>
              <span class="marker-caption-tag donor">Pickup</span>
            </div>
          `,
          iconSize: [42, 54],
          iconAnchor: [21, 52]
        });

        const shelterIcon = L.divIcon({
          className: "custom-leaflet-marker",
          html: `
            <div class="marker-pin-wrap">
              <div class="marker-shelter-pin">
                <span>🏢</span>
              </div>
              <span class="marker-caption-tag shelter">Shelter</span>
            </div>
          `,
          iconSize: [42, 54],
          iconAnchor: [21, 52]
        });

        // Waze 3D Delivery Car/Van Avatar with Headlight Beam
        const vehicleIcon = L.divIcon({
          className: "custom-leaflet-marker",
          html: `
            <div class="waze-vehicle-wrap" id="wazeVehicleEl">
              <div class="waze-headlight-cone"></div>
              <div class="waze-vehicle-body">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="white">
                  <rect x="2" y="4" width="13" height="11" rx="1.5" />
                  <path d="M15 8h4l3 3.5v3.5h-7V8z" fill="#93C5FD" />
                  <circle cx="6" cy="18" r="2.5" fill="#1E293B" stroke="#FFFFFF" stroke-width="1.5" />
                  <circle cx="17" cy="18" r="2.5" fill="#1E293B" stroke="#FFFFFF" stroke-width="1.5" />
                </svg>
              </div>
              <span class="waze-radar-ping"></span>
            </div>
          `,
          iconSize: [46, 46],
          iconAnchor: [23, 23]
        });

        // 1. Donor Pickup Marker
        const donorMarker = L.marker(waypoints[0], { icon: donorIcon }).addTo(map);
        donorMarker.bindPopup(`<strong>${routeData.donor.name}</strong><br><small>Pickup Kitchen: ${routeData.donor.address}</small>`);

        // 2. Shelter Dropoff Marker
        const shelterMarker = L.marker(waypoints[waypoints.length - 1], { icon: shelterIcon }).addTo(map);
        shelterMarker.bindPopup(`<strong>${routeData.shelter.name}</strong><br><small>Destination Shelter: ${routeData.shelter.address}</small>`);

        // 3. Waze Signature Glowing Navigation Route Polyline
        // Outer Waze Cyan Glow
        L.polyline(waypoints, {
          color: "#00D4FF",
          weight: 12,
          opacity: 0.55,
          lineCap: "round"
        }).addTo(map);

        // Inner Waze Vivid Navigation Line
        const routeLine = L.polyline(waypoints, {
          color: "#0077FF",
          weight: 5.5,
          lineCap: "round"
        }).addTo(map);

        // 4. Fit Map with Comfortable Bounds Padding so markers never touch edges
        map.fitBounds(routeLine.getBounds(), { padding: [75, 75] });

        // 5. Initial Vehicle Position based on Donation Status
        this.simProgress = this.getInitialProgressForStatus(donation.status);
        const initialPos = this.interpolatePosition(waypoints, this.simProgress);
        this.simVehicleMarker = L.marker(initialPos, { icon: vehicleIcon }).addTo(map);

        // 6. Force Leaflet resize calculation after container render
        setTimeout(() => {
          map.invalidateSize();
          map.fitBounds(routeLine.getBounds(), { padding: [75, 75] });
        }, 250);

        // 7. Initial Status-Aware Telemetry (Vehicle stays steady at current milestone)
        const totalKm = routeData.totalDistKm || 5.6;
        const remainingKm = Math.max(0.0, (totalKm * (1 - this.simProgress)).toFixed(1));
        const etaMins = Math.max(0, Math.round(remainingKm * 2.4));
        const initialSpeed = (donation.status === "assigned" || donation.status === "collected") ? 34 : 0;
        this.updateHudTelemetry(remainingKm, etaMins, initialSpeed, routeData, donation, isTa);
        return;
      } catch (err) {
        console.warn("Leaflet map initialization fallback triggered:", err);
      }
    }

    // High-Fidelity Vector Canvas Fallback (if CDN is unavailable)
    this.renderVectorFallbackMap(mapContainer, routeData, isTa);
  },

  interpolatePosition(points, t) {
    if (!points || points.length === 0) return [13.0450, 80.2400];
    if (points.length === 1) return points[0];
    if (t <= 0) return points[0];
    if (t >= 1) return points[points.length - 1];

    const totalSegments = points.length - 1;
    const scaled = t * totalSegments;
    const index = Math.floor(scaled);
    const frac = scaled - index;

    const p1 = points[index];
    const p2 = points[Math.min(index + 1, points.length - 1)];

    return [
      p1[0] + (p2[0] - p1[0]) * frac,
      p1[1] + (p2[1] - p1[1]) * frac
    ];
  },

  calculateHeading(p1, p2) {
    if (!p1 || !p2) return 0;
    const dy = p2[0] - p1[0];
    const dx = Math.cos(Math.PI / 180 * p1[0]) * (p2[1] - p1[1]);
    let angle = Math.atan2(dx, dy) * 180 / Math.PI;
    return Math.round(angle);
  },

  toggleSimulation() {
    this.isSimulating = !this.isSimulating;
    const btn = document.getElementById("btnToggleSim");
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    if (this.isSimulating) {
      if (btn) btn.innerHTML = "⏸️";
      if (window.App) window.App.showToast(isTa ? "▶️ நேரடி வழிசெலுத்தல் பயணம் தொடங்கியது" : "▶️ Live navigation trip started", "info");
      this.runSimulationLoop();
    } else {
      if (this.liveSimInterval) {
        clearInterval(this.liveSimInterval);
        this.liveSimInterval = null;
      }
      if (btn) btn.innerHTML = "▶️";
      if (window.App) window.App.showToast(isTa ? "⏸️ வாகனம் நிறுத்தப்பட்டது (நிலையான நிலை)" : "⏸️ Vehicle simulation paused.", "info");
    }
  },

  runSimulationLoop() {
    if (this.liveSimInterval) clearInterval(this.liveSimInterval);
    const donation = window.HopeStore.getDonationById(this.selectedDonationId);
    const routeData = this.currentRouteData || this.getRouteForDonation(donation || {});
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    this.liveSimInterval = setInterval(() => {
      if (!this.isSimulating) return;

      this.simProgress += 0.005; // Ultra-smooth micro progression
      if (this.simProgress >= 1.0) {
        this.simProgress = 1.0;
        this.isSimulating = false;
        clearInterval(this.liveSimInterval);
        const btn = document.getElementById("btnToggleSim");
        if (btn) btn.innerHTML = "🏁";
        if (window.App) window.App.showToast(isTa ? "🏁 வாகனம் காப்பகத்தை பாதுகாப்பாக அடைந்தது!" : "🏁 Vehicle reached shelter destination safely!", "success");
      }

      const newPos = this.interpolatePosition(routeData.waypoints, this.simProgress);
      const nextPos = this.interpolatePosition(routeData.waypoints, Math.min(1.0, this.simProgress + 0.015));

      if (this.simVehicleMarker) {
        this.simVehicleMarker.setLatLng(newPos);
      }

      // Smooth heading rotation
      const heading = this.calculateHeading(newPos, nextPos);
      const vehicleEl = document.getElementById("wazeVehicleEl");
      if (vehicleEl) {
        vehicleEl.style.transform = `rotate(${heading}deg)`;
      }

      // Dynamic telemetry
      const totalKm = routeData.totalDistKm || 5.6;
      const remainingKm = Math.max(0.0, (totalKm * (1 - this.simProgress)).toFixed(1));
      const etaMins = Math.max(0, Math.round(remainingKm * 2.4));
      const liveSpeed = this.simProgress >= 1.0 ? 0 : 32 + Math.floor(Math.abs(Math.sin(Date.now() / 1500) * 6));

      this.updateHudTelemetry(remainingKm, etaMins, liveSpeed, routeData, donation, isTa);
    }, 250);
  },

  updateHudTelemetry(remainingKm, etaMins, speed, routeData, donation, isTa) {
    const etaEl = document.getElementById("hudEtaDisplay");
    const distEl = document.getElementById("hudDistDisplay");
    const speedEl = document.getElementById("hudSpeedDisplay");
    const maneuverEl = document.getElementById("wazeManeuverText");

    if (etaEl) {
      if (donation.status === "distributed") {
        etaEl.innerHTML = isTa ? "🏁 சென்றடைந்தது" : "🏁 Arrived at Shelter";
      } else {
        etaEl.innerHTML = isTa ? `⏱️ இன்னும் ~${etaMins} நிமி` : `⏱️ ETA ~${etaMins} mins`;
      }
    }

    if (distEl) {
      distEl.innerHTML = donation.status === "distributed" ? "" : `• ${remainingKm} km`;
    }

    if (speedEl) {
      if (donation.status === "distributed") {
        speedEl.innerHTML = isTa ? "🅿️ நிறுத்தப்பட்டது" : "🅿️ Parked";
      } else {
        speedEl.innerHTML = `⚡ ${speed} km/h`;
      }
    }

    if (maneuverEl) {
      if (donation.status === "distributed") {
        maneuverEl.innerHTML = isTa 
          ? "உணவு காப்பகத்தில் ஒப்படைக்கப்பட்டது!" 
          : "Mission Completed! Food delivered to shelter.";
      } else if (this.simProgress > 0.88) {
        maneuverEl.innerHTML = isTa 
          ? `இன்னும் 200 மீட்டரில் காப்பகத்தை அடைகிறது!` 
          : `Approaching destination shelter within 200m!`;
      } else {
        maneuverEl.innerHTML = isTa
          ? `இன்னும் 350 மீட்டரில் வலதுபுறம் திரும்பவும்`
          : `In 350m • Keep right towards ${routeData.shelter.name.split(' ')[0]}`;
      }
    }
  },

  stepSimulation() {
    this.simProgress += 0.2;
    if (this.simProgress > 1.0) this.simProgress = 0.1;
    if (this.activeMapInstance && this.simVehicleMarker && this.simRouteCoords.length > 0) {
      const newPos = this.interpolatePosition(this.simRouteCoords, this.simProgress);
      this.simVehicleMarker.setLatLng(newPos);
      if (window.App) window.App.showToast("⚡ Advanced live dispatch vehicle step", "info");
    }
  },

  recenterMap() {
    if (this.activeMapInstance && this.simRouteCoords.length > 0) {
      const bounds = L.latLngBounds(this.simRouteCoords);
      this.activeMapInstance.fitBounds(bounds, { padding: [75, 75], animate: true });
      if (window.App) window.App.showToast("🎯 Map recentered to live dispatch route", "info");
    }
  },

  renderVectorFallbackMap(container, routeData, isTa) {
    container.innerHTML = `
      <div style="width: 100%; height: 100%; background: #0B192C; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
        <svg viewBox="0 0 400 240" style="width: 100%; height: 100%;">
          <defs>
            <linearGradient id="wazeRoute" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#00D4FF" />
              <stop offset="100%" stop-color="#0077FF" />
            </linearGradient>
          </defs>
          <!-- Grid Lines -->
          <line x1="20" y1="60" x2="380" y2="60" stroke="#1E293B" stroke-width="2" />
          <line x1="20" y1="120" x2="380" y2="120" stroke="#1E293B" stroke-width="2" />
          <line x1="20" y1="180" x2="380" y2="180" stroke="#1E293B" stroke-width="2" />

          <!-- Route Path -->
          <path d="M 60 180 Q 140 80 200 130 T 340 70" fill="none" stroke="#00D4FF" stroke-width="12" stroke-linecap="round" opacity="0.6" />
          <path d="M 60 180 Q 140 80 200 130 T 340 70" fill="none" stroke="url(#wazeRoute)" stroke-width="6" stroke-linecap="round" />

          <!-- Donor Pin -->
          <circle cx="60" cy="180" r="16" fill="#10B981" stroke="#FFFFFF" stroke-width="3" />
          <text x="60" y="185" font-size="12" text-anchor="middle" fill="#FFFFFF">🍲</text>

          <!-- Shelter Pin -->
          <circle cx="340" cy="70" r="16" fill="#E53935" stroke="#FFFFFF" stroke-width="3" />
          <text x="340" y="75" font-size="12" text-anchor="middle" fill="#FFFFFF">🏢</text>

          <!-- Moving Vehicle -->
          <circle cx="190" cy="120" r="18" fill="#0077FF" stroke="#FFFFFF" stroke-width="3" />
          <text x="190" y="125" font-size="14" text-anchor="middle" fill="#FFFFFF">🚚</text>
        </svg>
      </div>
    `;
  },

  markCollected(donationId) {
    window.HopeStore.updateDonation(donationId, {
      status: "collected",
      collectedAt: new Date().toISOString()
    });

    window.HopeStore.addNotification(
      "Food Collected",
      `Donation #${donationId} has been collected and is in transit to the shelter.`,
      "info"
    );

    window.App && window.App.showToast(window.i18n ? window.i18n.t("toast_collected") : "Food Collected", "success");
    this.renderTracker();
    if (window.DonorModule) window.DonorModule.renderMyDonations();
    if (window.ImpactModule) window.ImpactModule.updateMetrics();
  },

  markDistributed(donationId) {
    window.HopeStore.updateDonation(donationId, {
      status: "distributed",
      distributedAt: new Date().toISOString()
    });

    window.HopeStore.addNotification(
      "Mission Completed",
      `Donation #${donationId} successfully distributed to shelter residents!`,
      "success"
    );

    window.App && window.App.showToast(window.i18n ? window.i18n.t("toast_distributed") : "Food Distributed", "success");
    this.renderTracker();
    if (window.DonorModule) window.DonorModule.renderMyDonations();
    if (window.ImpactModule) window.ImpactModule.updateMetrics();
  },

  transferToBackup(donationId, newNgoId) {
    const newNgo = window.HopeStore.getNgoById(newNgoId);
    if (!newNgo) return;

    if (confirm(`Transfer donation #${donationId} to backup organization ${newNgo.name}?`)) {
      window.HopeStore.updateDonation(donationId, {
        assignedNgoId: newNgo.id,
        assignedNgoName: newNgo.name,
        status: "accepted",
        driverName: newNgo.activeDriver || "Assigned Driver"
      });

      window.App && window.App.showToast(`Transferred to ${newNgo.name}`, "info");
      this.renderTracker();
      if (window.NgoModule) window.NgoModule.renderFeed();
    }
  },

  speakStatus(donationId) {
    const d = window.HopeStore.getDonationById(donationId);
    if (!d || !window.i18n) return;

    const isTa = window.i18n.getLanguage() === "ta";
    const statusLabel = window.i18n.t("badge_" + d.status);
    const text = isTa
      ? `உணவுப் பதிவு எண் ${d.id}. ${d.foodName}. தற்போதைய நிலை: ${statusLabel}. எடுக்கும் இடம்: ${d.location}. காலக்கெடு: ${new Date(d.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`
      : `Donation ${d.id}. ${d.foodName}. Current status: ${d.status}. Pickup location: ${d.location}. Safe collection deadline: ${new Date(d.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`;
    window.i18n.speak(text);
  }
};

window.TrackingModule = TrackingModule;
