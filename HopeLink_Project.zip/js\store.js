/**
 * HopeLink - Central Data Store (store.js)
 * 
 * Manages localStorage persistence for:
 * - Current User Session (Login / Logout)
 * - Pre-configured Personas (Donor, NGO, Driver, Admin)
 * - Food Donations (with high quality food category imagery)
 * - Partner NGOs (fictional verified organizations)
 * - Recurring Schedules
 * - In-App Notifications
 * - Community Issue Reports
 * - App State (language, active role, current view, view mode)
 */

const STORAGE_KEYS = {
  DONATIONS: "hopelink_donations_v3",
  NGOS: "hopelink_ngos_v3",
  SCHEDULES: "hopelink_schedules_v3",
  NOTIFICATIONS: "hopelink_notifications_v3",
  REPORTS: "hopelink_reports_v3",
  APP_STATE: "hopelink_state_v3",
  AUTH_USER: "hopelink_user_v3"
};

// Curated high-quality food imagery URLs
const FOOD_IMAGES = {
  cooked: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=700&q=80",
  bakery: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=700&q=80",
  produce: "https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=700&q=80",
  dairy: "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=700&q=80",
  packaged: "https://images.unsplash.com/photo-1584473457406-6240486418e9?auto=format&fit=crop&w=700&q=80"
};

// Pre-configured Demo Accounts / Personas
const DEMO_PERSONAS = {
  donor: {
    id: "user-donor-1",
    name: "Green Leaf Organic Bistro",
    role: "donor",
    email: "donor@greenleaf.org",
    avatar: "🍽️",
    badgeLabel: "Food Donor"
  },
  ngo: {
    id: "user-ngo-1",
    name: "Akshaya Food Bank",
    role: "ngo",
    email: "coordinator@akshayafood.org",
    avatar: "🏢",
    badgeLabel: "NGO Coordinator",
    ngoId: "ngo-1"
  },
  driver: {
    id: "user-driver-1",
    name: "Karthik R. (Volunteer)",
    role: "driver",
    email: "karthik@hopelink.org",
    avatar: "🛵",
    badgeLabel: "Volunteer Driver"
  },
  admin: {
    id: "user-admin-1",
    name: "HopeLink Administrator",
    role: "admin",
    email: "admin@hopelink.org",
    avatar: "👑",
    badgeLabel: "Platform Admin"
  }
};

// Initial fictional partner NGOs (each with a realistic, unique, high-quality charity photo)
const INITIAL_NGOS = [
  {
    id: "ngo-grace",
    name: "Grace Seva Foundation",
    name_ta: "கிரேஸ் சேவா அறக்கட்டளை",
    category: "Non-profit organization",
    zone: "184 Main Rd, Central Zone",
    distanceKm: 2.1,
    rating: "4.9",
    reviewsCount: 15,
    capacityPortions: 300,
    acceptsCooked: true,
    acceptsNonVeg: true,
    operatingHours: "07:00 AM - 10:00 PM",
    verified: true,
    phone: "+91 99483 95832",
    activeDriver: "John D. (Volunteer Van)",
    imageUrl: "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "ngo-karunai",
    name: "Karunai Children's Shelter",
    name_ta: "கருணை குழந்தைகள் காப்பகம்",
    category: "Child Welfare & Food Relief",
    zone: "North Avenue, Kilpauk",
    distanceKm: 4.0,
    rating: "4.8",
    reviewsCount: 22,
    capacityPortions: 120,
    acceptsCooked: true,
    acceptsNonVeg: false,
    operatingHours: "08:00 AM - 08:00 PM",
    verified: true,
    phone: "+91 98402 34567",
    activeDriver: "Suresh M. (Auto-Rickshaw)",
    imageUrl: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "ngo-1",
    name: "Akshaya Community Food Bank",
    name_ta: "அக்ஷயா உணவு வங்கி",
    category: "Community Food Bank",
    zone: "Central Zone (MG Road)",
    distanceKm: 2.1,
    rating: "4.9",
    reviewsCount: 38,
    capacityPortions: 250,
    acceptsCooked: true,
    acceptsNonVeg: true,
    operatingHours: "07:00 AM - 10:00 PM",
    verified: true,
    phone: "+91 98401 23456",
    activeDriver: "Karthik R. (Van DL-04-1234)",
    imageUrl: "https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "ngo-2",
    name: "Karuna Shelter & Elderly Care Home",
    name_ta: "கருணா முதியோர் & குழந்தைகள் இல்லம்",
    category: "Shelter & Nutrition",
    zone: "North Zone (Anna Nagar)",
    distanceKm: 4.8,
    rating: "4.7",
    reviewsCount: 19,
    capacityPortions: 90,
    acceptsCooked: true,
    acceptsNonVeg: false,
    operatingHours: "08:00 AM - 08:00 PM",
    verified: true,
    phone: "+91 98402 34567",
    activeDriver: "Suresh M. (Auto-Rickshaw)",
    imageUrl: "https://images.unsplash.com/photo-1578357078586-491adf1aa5ba?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "ngo-3",
    name: "Seva Open Kitchen Trust",
    name_ta: "சேவா சமுதாய சமையலறை",
    category: "Community Kitchen",
    zone: "East Zone (T. Nagar)",
    distanceKm: 6.2,
    rating: "4.6",
    reviewsCount: 14,
    capacityPortions: 180,
    acceptsCooked: true,
    acceptsNonVeg: true,
    operatingHours: "06:00 AM - 11:00 PM",
    verified: true,
    phone: "+91 98403 45678",
    activeDriver: "Priya V. (Electric Cargo Bike)",
    imageUrl: "https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "ngo-4",
    name: "Annam Hunger Relief Foundation",
    name_ta: "அன்னம் பசி போக்கும் அறக்கட்டளை",
    category: "Emergency Relief",
    zone: "South Zone (Guindy)",
    distanceKm: 8.5,
    rating: "4.9",
    reviewsCount: 41,
    capacityPortions: 400,
    acceptsCooked: true,
    acceptsNonVeg: true,
    operatingHours: "24 Hours (Emergency Dispatch)",
    verified: true,
    phone: "+91 98404 56789",
    activeDriver: "Arun K. (Mini Truck TN-09-5678)",
    imageUrl: "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=600&q=80"
  }
];

function getInitialDonations() {
  const now = new Date();
  const hoursOffset = (h) => new Date(now.getTime() + h * 60 * 60 * 1000).toISOString();
  const hoursAgo = (h) => new Date(now.getTime() - h * 60 * 60 * 1000).toISOString();

  return [
    {
      id: "HL-2026-100",
      donorName: "Shree Krishna Caterers",
      donorType: "event",
      foodName: "Surplus Food Feast (Dal, Rice, Roti, Paneer Sabzi, Poha)",
      foodDescription: "Itemized fresh surplus catering meals: Dal (12 kg), Rice (8 kg), Roti (42 pcs), Paneer Sabzi (6 kg), Poha (4 kg). Freshly prepared, hygienically packed.",
      foodBreakdown: [
        { item: "Dal", qty: "12 kg" },
        { item: "Rice", qty: "8 kg" },
        { item: "Roti", qty: "42 pcs" },
        { item: "Paneer Sabzi", qty: "6 kg" },
        { item: "Poha", qty: "4 kg" }
      ],
      category: "cooked",
      imageUrl: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80",
      dietary: "veg",
      quantity: 120,
      unit: "portions",
      estimatedKg: 38,
      prepTime: hoursAgo(1),
      deadline: hoursOffset(2.5),
      storageCondition: "hot_insulated",
      allergens: ["dairy"],
      location: "Urban Kitchen, Shop No. 7, Silver Arch Bldg, Opp Fun Republic",
      pickupInstructions: "Pickup time: 19:30 - 21:00. Service entrance gate 2. Call catering desk.",
      contactPhone: "+91 99483 95832",
      hidePhone: false,
      status: "available",
      assignedNgoId: null,
      assignedNgoName: null,
      driverName: null,
      driverPhone: null,
      claimedAt: null,
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true,
      createdAt: hoursAgo(0.5)
    },
    {
      id: "HL-2026-101",
      donorName: "Sunrise Grand Buffet & Banquet",
      donorType: "marriage_hall",
      foodName: "Vegetable Biryani, Paneer Curry & Rotis",
      foodDescription: "Surplus wedding lunch buffet. Kept hot in commercial insulated stainless steel containers.",
      category: "cooked",
      imageUrl: FOOD_IMAGES.cooked,
      dietary: "veg",
      quantity: 85,
      unit: "portions",
      estimatedKg: 28,
      prepTime: hoursAgo(2),
      deadline: hoursOffset(3.5),
      storageCondition: "hot_insulated",
      allergens: ["dairy", "gluten"],
      location: "Grand Palace Hall, 45 Arcot Road, Kodambakkam",
      pickupInstructions: "Enter through Service Gate 2 at rear. Ask for Catering Manager Murugan.",
      contactPhone: "+91 98765 43210",
      hidePhone: true,
      status: "available",
      assignedNgoId: null,
      assignedNgoName: null,
      driverName: null,
      driverPhone: null,
      claimedAt: null,
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true,
      createdAt: hoursAgo(1)
    },
    {
      id: "HL-2026-102",
      donorName: "Green Leaf Organic Cafe",
      donorType: "restaurant",
      foodName: "Artisan Multigrain Bread Loaves & Vegetable Quiche",
      foodDescription: "Freshly baked morning goods, perfectly packaged in sealed paper bags.",
      category: "bakery",
      imageUrl: FOOD_IMAGES.bakery,
      dietary: "veg",
      quantity: 35,
      unit: "portions",
      estimatedKg: 12,
      prepTime: hoursAgo(3),
      deadline: hoursOffset(5),
      storageCondition: "room_temp",
      allergens: ["gluten"],
      location: "Green Leaf Cafe, 12 Cathedral Road",
      pickupInstructions: "Front counter staff is briefed. Easy curbside parking outside.",
      contactPhone: "+91 98400 11223",
      hidePhone: false,
      status: "accepted",
      assignedNgoId: "ngo-1",
      assignedNgoName: "Akshaya Community Food Bank",
      driverName: "Pending Assignment",
      driverPhone: null,
      claimedAt: hoursAgo(0.5),
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true,
      createdAt: hoursAgo(2)
    },
    {
      id: "HL-2026-103",
      donorName: "Royal Heritage Hotel",
      donorType: "hotel",
      foodName: "Chicken Curry, Jeera Rice & Dal Tadka",
      foodDescription: "Executive dinner buffet surplus. Properly stored under hygienic temperature supervision.",
      category: "cooked",
      imageUrl: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=700&q=80",
      dietary: "nonveg",
      quantity: 120,
      unit: "portions",
      estimatedKg: 45,
      prepTime: hoursAgo(3),
      deadline: hoursOffset(2),
      storageCondition: "refrigerated",
      allergens: ["dairy"],
      location: "Royal Heritage Hotel, Loading Bay C, Mount Road",
      pickupInstructions: "Report to Security Cabin 1, mention HopeLink Food Rescue voucher.",
      contactPhone: "+91 99620 99887",
      hidePhone: true,
      status: "assigned",
      assignedNgoId: "ngo-4",
      assignedNgoName: "Annam Hunger Relief Foundation",
      driverName: "Arun K. (Mini Truck TN-09-5678)",
      driverPhone: "+91 97910 54321",
      claimedAt: hoursAgo(1),
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true,
      createdAt: hoursAgo(3)
    },
    {
      id: "HL-2026-104",
      donorName: "City Supermarket Wholesale",
      donorType: "individual",
      foodName: "Assorted Fresh Fruits (Apples, Bananas, Oranges)",
      foodDescription: "Edible surplus crates, clean and unbruised ripe produce.",
      category: "produce",
      imageUrl: FOOD_IMAGES.produce,
      dietary: "veg",
      quantity: 50,
      unit: "kg",
      estimatedKg: 50,
      prepTime: hoursAgo(1),
      deadline: hoursOffset(1.2),
      storageCondition: "room_temp",
      allergens: [],
      location: "City Supermarket Stall 14, Koyambedu Market",
      pickupInstructions: "Direct truck access at gate 4.",
      contactPhone: "+91 94440 12345",
      hidePhone: false,
      status: "available",
      assignedNgoId: null,
      assignedNgoName: null,
      driverName: null,
      driverPhone: null,
      claimedAt: null,
      collectedAt: null,
      distributedAt: null,
      safetyChecklistPassed: true,
      createdAt: hoursAgo(1)
    },
    {
      id: "HL-2026-105",
      donorName: "Dr. Sundaram Family",
      donorType: "family",
      foodName: "Home Cooked Sambar Rice, Curd Rice & Poriyal",
      foodDescription: "Prepared for family prayer gathering. Cleanly packed in disposable meal trays.",
      category: "cooked",
      imageUrl: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80",
      dietary: "veg",
      quantity: 25,
      unit: "portions",
      estimatedKg: 8,
      prepTime: hoursAgo(5),
      deadline: hoursAgo(0.5),
      storageCondition: "room_temp",
      allergens: ["dairy"],
      location: "Flat 4B, Shanthi Apts, Kilpauk",
      pickupInstructions: "Call before arrival, lift available.",
      contactPhone: "+91 98840 77665",
      hidePhone: true,
      status: "collected",
      assignedNgoId: "ngo-2",
      assignedNgoName: "Karuna Shelter & Children's Home",
      driverName: "Suresh M. (Auto-Rickshaw)",
      driverPhone: "+91 98402 34567",
      claimedAt: hoursAgo(2),
      collectedAt: hoursAgo(0.5),
      distributedAt: null,
      safetyChecklistPassed: true,
      createdAt: hoursAgo(5)
    },
    {
      id: "HL-2026-106",
      donorName: "TechPark Corporate Cafeteria",
      donorType: "cafeteria",
      foodName: "Steamed Idli, Vada, Chutney & Sambar",
      foodDescription: "Breakfast cafeteria excess. High standard commercial hygiene maintained.",
      category: "cooked",
      imageUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=700&q=80",
      dietary: "veg",
      quantity: 160,
      unit: "portions",
      estimatedKg: 40,
      prepTime: hoursAgo(8),
      deadline: hoursAgo(4),
      storageCondition: "hot_insulated",
      allergens: [],
      location: "TechPark Tower 3, OMR IT Corridor",
      pickupInstructions: "Deliveries dock behind Tower 3 cafeteria.",
      contactPhone: "+91 98409 88776",
      hidePhone: false,
      status: "distributed",
      assignedNgoId: "ngo-3",
      assignedNgoName: "Seva Open Kitchen Trust",
      driverName: "Priya V.",
      driverPhone: "+91 98403 45678",
      claimedAt: hoursAgo(7),
      collectedAt: hoursAgo(5),
      distributedAt: hoursAgo(3.5),
      safetyChecklistPassed: true,
      createdAt: hoursAgo(8)
    }
  ];
}

const INITIAL_SCHEDULES = [
  {
    id: "sched-1",
    donorName: "TechPark Corporate Cafeteria",
    donorType: "cafeteria",
    foodType: "Lunch Surplus (Rice, Dal, Veggies)",
    frequency: "daily",
    customDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    estimatedPortions: 70,
    preferredTime: "14:30",
    pickupLocation: "TechPark Tower 3 Loading Dock",
    contactPhone: "+91 98409 88776",
    status: "active",
    preferredNgoId: "ngo-3",
    createdAt: new Date().toISOString()
  },
  {
    id: "sched-2",
    donorName: "Ananda Wedding Hall",
    donorType: "marriage_hall",
    foodType: "Weekend Reception Surplus",
    frequency: "weekly",
    customDays: ["Sat", "Sun"],
    estimatedPortions: 150,
    preferredTime: "15:00",
    pickupLocation: "Ananda Hall, 10 GST Road",
    contactPhone: "+91 98401 55443",
    status: "active",
    preferredNgoId: "ngo-4",
    createdAt: new Date().toISOString()
  }
];

const INITIAL_NOTIFICATIONS = [
  {
    id: "notif-1",
    title: "Donation Match Confirmed",
    message: "Annam Foundation claimed 120 portions from Royal Heritage Hotel.",
    timestamp: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    type: "success",
    read: false
  },
  {
    id: "notif-2",
    title: "Driver Assigned",
    message: "Driver Arun K. has been dispatched for donation HL-2026-103.",
    timestamp: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
    type: "info",
    read: false
  },
  {
    id: "notif-3",
    title: "Urgent Collection Window",
    message: "Donation HL-2026-104 (Fresh Fruits) expires in ~1 hour! Action recommended.",
    timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    type: "warning",
    read: false
  }
];

const DEFAULT_STATE = {
  lang: "en",
  activeRole: "donor",
  selectedNgoId: "ngo-grace",
  activeView: "home",
  viewMode: "fullscreen"
};

const HopeStore = {
  FOOD_IMAGES,
  DEMO_PERSONAS,

  init() {
    const SCHEMA_VERSION_KEY = "hopelink_schema_ver";
    const CURRENT_SCHEMA_VER = "v4";
    if (localStorage.getItem(SCHEMA_VERSION_KEY) !== CURRENT_SCHEMA_VER) {
      localStorage.setItem(STORAGE_KEYS.NGOS, JSON.stringify(INITIAL_NGOS));
      localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(getInitialDonations()));
      localStorage.setItem(SCHEMA_VERSION_KEY, CURRENT_SCHEMA_VER);
    }

    if (!localStorage.getItem(STORAGE_KEYS.DONATIONS)) {
      this.resetDemoData();
    }
    if (!localStorage.getItem(STORAGE_KEYS.APP_STATE)) {
      localStorage.setItem(STORAGE_KEYS.APP_STATE, JSON.stringify(DEFAULT_STATE));
    }
    if (!localStorage.getItem(STORAGE_KEYS.AUTH_USER)) {
      // Default to logged-in as sample donor
      localStorage.setItem(STORAGE_KEYS.AUTH_USER, JSON.stringify(DEMO_PERSONAS.donor));
    }
  },

  resetDemoData() {
    localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(getInitialDonations()));
    localStorage.setItem(STORAGE_KEYS.NGOS, JSON.stringify(INITIAL_NGOS));
    localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(INITIAL_SCHEDULES));
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.APP_STATE, JSON.stringify(DEFAULT_STATE));
    localStorage.setItem(STORAGE_KEYS.AUTH_USER, JSON.stringify(DEMO_PERSONAS.donor));
    console.log("HopeLink demo data reset successfully.");
  },

  // =========================================================================
  // Auth & Session Management
  // =========================================================================
  getCurrentUser() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUTH_USER);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },

  login(userProfile) {
    localStorage.setItem(STORAGE_KEYS.AUTH_USER, JSON.stringify(userProfile));
    // Synchronize active role in app state
    this.updateState({ activeRole: userProfile.role });
    if (userProfile.ngoId) {
      this.updateState({ selectedNgoId: userProfile.ngoId });
    }
    this.addNotification(
      "User Logged In",
      `Welcome, ${userProfile.name}! Logged in as ${userProfile.role.toUpperCase()}.`,
      "info"
    );
    return userProfile;
  },

  logout() {
    localStorage.removeItem(STORAGE_KEYS.AUTH_USER);
    this.addNotification(
      "Logged Out",
      "You have logged out from your account.",
      "info"
    );
  },

  // =========================================================================
  // App State & Data
  // =========================================================================
  getState() {
    try {
      const state = JSON.parse(localStorage.getItem(STORAGE_KEYS.APP_STATE));
      return { ...DEFAULT_STATE, ...(state || {}) };
    } catch (e) {
      return DEFAULT_STATE;
    }
  },

  updateState(updates) {
    const current = this.getState();
    const next = { ...current, ...updates };
    localStorage.setItem(STORAGE_KEYS.APP_STATE, JSON.stringify(next));
    return next;
  },

  getDonations() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DONATIONS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  getDonationById(id) {
    return this.getDonations().find((d) => d.id === id);
  },

  saveDonation(donation) {
    const donations = this.getDonations();
    if (!donation.id) {
      const seq = 100 + donations.length + 1;
      donation.id = `HL-2026-${seq}`;
    }
    if (!donation.createdAt) {
      donation.createdAt = new Date().toISOString();
    }
    if (!donation.imageUrl) {
      donation.imageUrl = FOOD_IMAGES[donation.category] || FOOD_IMAGES.cooked;
    }

    donations.unshift(donation);
    localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(donations));

    this.addNotification(
      "New Donation Listed",
      `${donation.donorName} listed ${donation.quantity} ${donation.unit} of ${donation.foodName}.`,
      "info"
    );

    return donation;
  },

  updateDonation(id, updates) {
    const donations = this.getDonations();
    const index = donations.findIndex((d) => d.id === id);
    if (index !== -1) {
      donations[index] = { ...donations[index], ...updates };
      localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(donations));
      return donations[index];
    }
    return null;
  },

  deleteDonation(id) {
    const donations = this.getDonations().filter((d) => d.id !== id);
    localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(donations));
  },

  getNGOs() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NGOS);
      const stored = data ? JSON.parse(data) : [];
      // Always guarantee that each NGO receives its dedicated, distinct, realistic photo from INITIAL_NGOS
      return INITIAL_NGOS.map((initNgo) => {
        const found = Array.isArray(stored) ? stored.find((n) => n.id === initNgo.id) : null;
        return {
          ...initNgo,
          ...(found || {}),
          imageUrl: initNgo.imageUrl // Guarantees distinct realistic photo for each charity
        };
      });
    } catch (e) {
      return INITIAL_NGOS;
    }
  },

  getNgoById(id) {
    return this.getNGOs().find((n) => n.id === id);
  },

  getSchedules() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SCHEDULES);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  saveSchedule(schedule) {
    const schedules = this.getSchedules();
    if (!schedule.id) {
      schedule.id = `sched-${Date.now()}`;
    }
    schedule.createdAt = new Date().toISOString();
    schedule.status = schedule.status || "active";
    schedules.unshift(schedule);
    localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));

    this.addNotification(
      "Recurring Schedule Added",
      `Schedule registered for ${schedule.donorName} (${schedule.frequency}).`,
      "success"
    );

    return schedule;
  },

  updateSchedule(id, updates) {
    const schedules = this.getSchedules();
    const index = schedules.findIndex((s) => s.id === id);
    if (index !== -1) {
      schedules[index] = { ...schedules[index], ...updates };
      localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
      return schedules[index];
    }
    return null;
  },

  deleteSchedule(id) {
    const schedules = this.getSchedules().filter((s) => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
  },

  getNotifications() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  addNotification(title, message, type = "info") {
    const notifs = this.getNotifications();
    const item = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title,
      message,
      type,
      timestamp: new Date().toISOString(),
      read: false
    };
    notifs.unshift(item);
    const trimmed = notifs.slice(0, 30);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(trimmed));
    return item;
  },

  markNotificationsAsRead() {
    const notifs = this.getNotifications().map((n) => ({ ...n, read: true }));
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
  },

  clearNotifications() {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
  },

  getReports() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.REPORTS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  saveReport(report) {
    const reports = this.getReports();
    report.id = `rep-${Date.now()}`;
    report.createdAt = new Date().toISOString();
    report.status = "under_review";
    reports.unshift(report);
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));

    this.addNotification(
      "Issue Report Received",
      `Report #${report.id} (${report.category}) logged for review.`,
      "warning"
    );

    return report;
  },

  injectScenario(type) {
    const now = new Date();
    const hoursOffset = (h) => new Date(now.getTime() + h * 60 * 60 * 1000).toISOString();

    let scenarioData = null;

    if (type === "wedding_urgent") {
      scenarioData = {
        donorName: "Vasantham Marriage Palace",
        donorType: "marriage_hall",
        foodName: "Grand Reception Vegetable Biryani & Kurma",
        foodDescription: "Surplus banquet buffet for 100 guests. Stored hot in commercial insulated thermowares.",
        category: "cooked",
        imageUrl: FOOD_IMAGES.cooked,
        dietary: "veg",
        quantity: 100,
        unit: "portions",
        estimatedKg: 35,
        prepTime: now.toISOString(),
        deadline: hoursOffset(2),
        storageCondition: "hot_insulated",
        allergens: ["dairy"],
        location: "Vasantham Hall, 100 Feet Road, Vadapalani",
        pickupInstructions: "Kitchen dispatch gate #3. Contact supervisor.",
        contactPhone: "+91 98405 88990",
        hidePhone: true,
        status: "available",
        assignedNgoId: null,
        assignedNgoName: null,
        driverName: null,
        driverPhone: null,
        claimedAt: null,
        collectedAt: null,
        distributedAt: null,
        safetyChecklistPassed: true
      };
    } else if (type === "bakery_veg") {
      scenarioData = {
        donorName: "Crown French Patisserie",
        donorType: "restaurant",
        foodName: "Fresh Baguettes, Croissants & Herb Loaves",
        foodDescription: "End-of-day bakery surplus in clean sealed food-grade paper packaging.",
        category: "bakery",
        imageUrl: FOOD_IMAGES.bakery,
        dietary: "veg",
        quantity: 45,
        unit: "portions",
        estimatedKg: 15,
        prepTime: now.toISOString(),
        deadline: hoursOffset(6),
        storageCondition: "room_temp",
        allergens: ["gluten"],
        location: "Crown Bakery, 88 Nungambakkam High Road",
        pickupInstructions: "Curbside pickup at storefront.",
        contactPhone: "+91 98406 11223",
        hidePhone: false,
        status: "available",
        assignedNgoId: null,
        assignedNgoName: null,
        driverName: null,
        driverPhone: null,
        claimedAt: null,
        collectedAt: null,
        distributedAt: null,
        safetyChecklistPassed: true
      };
    } else if (type === "produce_market") {
      scenarioData = {
        donorName: "Koyambedu Wholesale Agro Hub",
        donorType: "individual",
        foodName: "Organic Bananas, Papayas & Seasonal Melons",
        foodDescription: "Ripe, sweet nutritious fruit crates ready for immediate shelter distribution.",
        category: "produce",
        imageUrl: FOOD_IMAGES.produce,
        dietary: "veg",
        quantity: 75,
        unit: "kg",
        estimatedKg: 75,
        prepTime: now.toISOString(),
        deadline: hoursOffset(8),
        storageCondition: "room_temp",
        allergens: [],
        location: "Market Stall B-12, Agro Market Yard",
        pickupInstructions: "Loading dock open for vans and cargo bikes.",
        contactPhone: "+91 98407 33445",
        hidePhone: false,
        status: "available",
        assignedNgoId: null,
        assignedNgoName: null,
        driverName: null,
        driverPhone: null,
        claimedAt: null,
        collectedAt: null,
        distributedAt: null,
        safetyChecklistPassed: true
      };
    }

    if (scenarioData) {
      return this.saveDonation(scenarioData);
    }
    return null;
  }
};

HopeStore.init();
window.HopeStore = HopeStore;
