/**
 * HopeLink - Master Single-Page App Coordinator (app.js)
 * 
 * Handles:
 * - User Authentication (Login Modal, Personas, Logout)
 * - View routing & active view management
 * - Home page Featured Live Donations grid
 * - 1-Click Hackathon Demo Scenario injectors
 * - Phone-Like Model vs Full Screen view toggle
 * - Role Switcher synchronization
 * - Language selector (EN / தமிழ்)
 * - Notification center drawer & badge count
 * - Live status bar clock
 * - Global toast alert system
 * - Demo data reset handler
 */

const App = {
  activeView: "home",
  viewMode: "fullscreen",
  activeRole: "donor",

  init() {
    const savedState = window.HopeStore.getState();
    this.activeView = savedState.activeView || "home";
    this.viewMode = savedState.viewMode || "fullscreen";
    this.activeRole = savedState.activeRole || "donor";

    this.setupViewMode();
    this.setupRoleSwitcher();
    this.setupLanguageSwitcher();
    this.setupNavigation();
    this.setupNotificationCenter();
    this.setupScenarioInjectors();
    this.setupAuth();
    this.startPhoneClock();

    // Initialize feature modules
    if (window.DonorModule) window.DonorModule.init();
    if (window.NgoModule) window.NgoModule.init();
    if (window.TrackingModule) window.TrackingModule.init();
    if (window.SchedulesModule) window.SchedulesModule.init();
    if (window.ImpactModule) window.ImpactModule.init();
    if (window.CommunityModule) window.CommunityModule.init();

    // Render Home Page Components (Featured + Nearby Charities)
    this.renderHomeFeatured();
    this.renderNearbyCharities();

    // Initial view navigation
    this.navigateTo(this.activeView);

    // Synchronize authentication UI
    this.updateAuthUI();

    // Apply translations
    if (window.i18n) window.i18n.applyTranslations();

    console.log("HopeLink Hackathon-Grade Platform ready.");
  },

  // =========================================================================
  // 1. Authentication & Session Management (Login / Logout)
  // =========================================================================
  setupAuth() {
    // Header Login and Logout buttons
    const loginBtn = document.getElementById("headerLoginBtn");
    const logoutBtn = document.getElementById("headerLogoutBtn");
    const mobileLoginBtn = document.getElementById("mobileLoginBtn");
    const mobileLogoutBtn = document.getElementById("mobileLogoutBtn");

    if (loginBtn) loginBtn.addEventListener("click", () => this.openLoginModal());
    if (mobileLoginBtn) mobileLoginBtn.addEventListener("click", () => this.openLoginModal());

    if (logoutBtn) logoutBtn.addEventListener("click", () => this.logout());
    if (mobileLogoutBtn) mobileLogoutBtn.addEventListener("click", () => this.logout());

    // Login modal close button
    const closeLoginBtn = document.getElementById("closeLoginModalBtn");
    if (closeLoginBtn) closeLoginBtn.addEventListener("click", () => this.closeLoginModal());

    // 1-Click Persona Login buttons
    document.querySelectorAll("[data-login-persona]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const personaKey = btn.getAttribute("data-login-persona");
        this.loginAs(personaKey);
      });
    });

    // Custom sign-in form
    const customForm = document.getElementById("customLoginForm");
    if (customForm) {
      customForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const name = document.getElementById("loginCustomName")?.value.trim();
        const email = document.getElementById("loginCustomEmail")?.value.trim();
        const role = document.getElementById("loginCustomRole")?.value || "donor";

        if (!name) {
          this.showToast("Please enter your name.", "warning");
          return;
        }

        const avatars = { donor: "🍽️", ngo: "🏢", driver: "🛵", admin: "👑" };
        const userProfile = {
          id: `user-${Date.now()}`,
          name,
          email: email || `${name.toLowerCase().replace(/\s+/g, '')}@hopelink.org`,
          role,
          avatar: avatars[role] || "👤",
          badgeLabel: role.toUpperCase()
        };

        window.HopeStore.login(userProfile);
        this.closeLoginModal();
        this.updateAuthUI();
        this.showToast(`Welcome, ${name}! Logged in as ${role.toUpperCase()}.`, "success");

        if (role === "ngo") this.navigateTo("ngo");
        else if (role === "donor") this.navigateTo("donate");
        else if (role === "driver") this.navigateTo("tracker");
      });
    }
  },

  openLoginModal() {
    const modal = document.getElementById("loginModal");
    if (!modal) return;
    modal.removeAttribute("hidden");
    setTimeout(() => modal.classList.add("active"), 10);
  },

  closeLoginModal() {
    const modal = document.getElementById("loginModal");
    if (!modal) return;
    modal.classList.remove("active");
    setTimeout(() => modal.setAttribute("hidden", ""), 200);
  },

  loginAs(personaKey) {
    const persona = window.HopeStore.DEMO_PERSONAS[personaKey];
    if (!persona) return;

    window.HopeStore.login(persona);
    this.closeLoginModal();
    this.updateAuthUI();

    this.showToast(`Logged in as ${persona.name} (${persona.badgeLabel})`, "success");

    // Automatically navigate to the most relevant view for that persona
    if (persona.role === "ngo") {
      if (window.NgoModule) window.NgoModule.setActiveNgo(persona.ngoId || "ngo-1");
      this.navigateTo("ngo");
    } else if (persona.role === "donor") {
      this.navigateTo("donate");
    } else if (persona.role === "driver") {
      this.navigateTo("tracker");
    } else if (persona.role === "admin") {
      this.navigateTo("impact");
    }
  },

  logout() {
    const user = window.HopeStore.getCurrentUser();
    const userName = user ? user.name : "User";

    window.HopeStore.logout();
    this.updateAuthUI();
    this.navigateTo("home");
    this.showToast(`Goodbye ${userName}. You are now logged out.`, "info");
  },

  updateAuthUI() {
    const user = window.HopeStore.getCurrentUser();
    const authContainer = document.getElementById("headerAuthContainer");
    const mobileAuthContainer = document.getElementById("mobileAuthContainer");
    const currentLang = window.i18n ? window.i18n.getLanguage() : "en";

    const updateDom = (container) => {
      if (!container) return;
      if (user) {
        const roleLabel = window.i18n ? (window.i18n.t(`role_${user.role}`) || user.badgeLabel || user.role) : (user.badgeLabel || user.role);
        const logoutText = window.i18n ? window.i18n.t("btn_logout") : "Log Out";
        container.innerHTML = `
          <div class="user-profile-chip" title="Logged in as ${user.name} (${roleLabel})">
            <span class="user-avatar">${user.avatar || '👤'}</span>
            <div class="user-chip-text">
              <span class="user-chip-name">${user.name}</span>
              <span class="user-chip-role">${roleLabel}</span>
            </div>
          </div>
          <button class="btn btn-outline-danger btn-sm" id="headerLogoutBtn" type="button" onclick="App.logout()">
            🚪 <span>${logoutText}</span>
          </button>
        `;
      } else {
        const loginText = window.i18n ? window.i18n.t("btn_login") : "Log In";
        container.innerHTML = `
          <button class="btn btn-secondary btn-sm" id="headerLoginBtn" type="button" onclick="App.openLoginModal()">
            🔑 <span>${loginText}</span>
          </button>
        `;
      }
    };

    updateDom(authContainer);
    updateDom(mobileAuthContainer);

    // Sync banner and role selector if user is logged in
    const roleSelect = document.getElementById("demoRoleSelect");
    const roleBadge = document.getElementById("currentRoleIndicatorBadge");
    if (user) {
      if (roleSelect) roleSelect.value = user.role;
      const roleLabel = window.i18n ? (window.i18n.t(`role_${user.role}`) || user.badgeLabel || user.role) : (user.badgeLabel || user.role);
      if (roleBadge) roleBadge.textContent = `${user.avatar} ${user.name} (${roleLabel})`;
    } else {
      if (roleBadge) roleBadge.textContent = currentLang === "ta" ? "👤 விருந்தினர் (வெளியேறியுள்ளார்)" : `👤 Guest (Logged Out)`;
    }

    if (window.i18n) window.i18n.applyTranslations();
  },

  // =========================================================================
  // 2. View Navigation Router
  // =========================================================================
  navigateTo(viewId) {
    this.activeView = viewId;
    window.HopeStore.updateState({ activeView: viewId });

    document.querySelectorAll(".app-view").forEach((section) => {
      section.classList.remove("view-active");
    });

    const target = document.getElementById(`view-${viewId}`);
    if (target) {
      target.classList.add("view-active");
      const phoneScreen = document.querySelector(".phone-screen");
      if (this.viewMode === "phone" && phoneScreen) {
        phoneScreen.scrollTop = 0;
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }

    document.querySelectorAll(".nav-item").forEach((item) => {
      item.classList.toggle("active", item.getAttribute("data-view") === viewId);
    });

    document.querySelectorAll(".bottom-tab-item").forEach((tab) => {
      tab.classList.toggle("active", tab.getAttribute("data-view") === viewId);
    });

    const drawer = document.getElementById("mobileDrawer");
    const toggle = document.getElementById("menuToggle");
    if (drawer) drawer.classList.remove("open");
    if (toggle) toggle.classList.remove("active");

    // Refresh view data on navigate
    if (viewId === "home") this.renderHomeFeatured();
    if (viewId === "ngo" && window.NgoModule) window.NgoModule.renderFeed();
    if (viewId === "donate" && window.DonorModule) window.DonorModule.renderMyDonations();
    if (viewId === "tracker" && window.TrackingModule) window.TrackingModule.renderTracker();
    if (viewId === "impact" && window.ImpactModule) window.ImpactModule.updateMetrics();
  },

  setupNavigation() {
    document.querySelectorAll("[data-nav-view]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        const view = el.getAttribute("data-nav-view");
        this.navigateTo(view);
      });
    });

    document.querySelectorAll(".bottom-tab-item").forEach((tab) => {
      tab.addEventListener("click", () => {
        const view = tab.getAttribute("data-view");
        this.navigateTo(view);
      });
    });

    const menuToggle = document.getElementById("menuToggle");
    const mobileDrawer = document.getElementById("mobileDrawer");
    if (menuToggle && mobileDrawer) {
      menuToggle.addEventListener("click", () => {
        const isExp = menuToggle.getAttribute("aria-expanded") === "true";
        menuToggle.setAttribute("aria-expanded", !isExp);
        menuToggle.classList.toggle("active");
        mobileDrawer.classList.toggle("open");
      });
    }
  },

  // =========================================================================
  // 3. Featured Live Donations on Home Page
  // =========================================================================
  renderHomeFeatured() {
    const container = document.getElementById("homeFeaturedDonationsGrid");
    if (!container) return;

    const donations = window.HopeStore.getDonations();
    const available = donations.filter((d) => d.status === "available").slice(0, 3);
    const displayList = available.length > 0 ? available : donations.slice(0, 3);
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (displayList.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>${isTa ? "நேரடி உணவுப் பட்டியல்கள் எதுவும் இல்லை." : "No active food rescue listings right now."}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = displayList
      .map((d) => {
        const hoursLeft = ((new Date(d.deadline).getTime() - Date.now()) / (1000 * 60 * 60)).toFixed(1);
        const isVeg = d.dietary === "veg";
        const dietLabel = isVeg
          ? (isTa ? "🟢 சைவம்" : "🟢 Pure Veg")
          : (isTa ? "🔴 அசைவம்" : "🔴 Non-Veg");
        const dietBadge = `<span class="tag-dietary ${isVeg ? 'diet-veg' : 'diet-nonveg'}">${dietLabel}</span>`;

        const statusLabel = window.i18n ? window.i18n.t("badge_" + d.status) : d.status.toUpperCase();
        const timerText = hoursLeft > 0
          ? (isTa ? `⏱️ ${hoursLeft} மணி மீதம்` : `⏱️ ${hoursLeft}h left`)
          : (isTa ? "⚠️ நேரம் கடந்தது" : "⚠️ Overdue");
        const byText = isTa ? "வழங்குபவர்:" : "By:";
        const donorTypeLabel = window.i18n ? (window.i18n.t("donor_" + d.donorType) || d.donorType) : d.donorType;
        const unitLabel = window.i18n ? (window.i18n.t("unit_" + d.unit) || d.unit) : d.unit;
        const claimText = window.i18n ? window.i18n.t("btn_claim_shelter") : "Claim for Shelter →";
        const trackText = window.i18n ? window.i18n.t("btn_track_journey") : "Track Journey ↗";

        return `
          <div class="card home-featured-card">
            <div class="featured-card-img-wrap">
              <img src="${d.imageUrl || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80'}" alt="${d.foodName}" class="featured-card-img" loading="lazy">
              <div class="featured-card-badges">
                ${dietBadge}
                <span class="badge status-${d.status}">${statusLabel}</span>
              </div>
              <span class="featured-timer-badge">${timerText}</span>
            </div>

            <div class="featured-card-content">
              <h3 class="featured-card-title">${d.foodName}</h3>
              <p class="featured-card-donor">${byText} <strong>${d.donorName}</strong> (${donorTypeLabel})</p>

              <div class="featured-specs-row">
                <span>🍽️ <strong>${d.quantity} ${unitLabel}</strong></span>
                <span>📦 ${d.storageCondition.replace('_', ' ')}</span>
              </div>

              <p class="featured-location">📍 ${d.location}</p>

              <div class="featured-card-actions">
                ${d.status === "available" ? `
                  <button class="btn btn-primary btn-sm full-width" onclick="App.navigateTo('ngo'); NgoModule.claimDonation('${d.id}');">
                    ${claimText}
                  </button>
                ` : `
                  <button class="btn btn-outline btn-sm full-width" onclick="App.navigateTo('tracker'); TrackingModule.selectDonation('${d.id}');">
                    ${trackText}
                  </button>
                `}
              </div>
            </div>
          </div>
        `;
      })
      .join("");
  },

  // =========================================================================
  // 3b. Nearby Charities (Inspired by User Reference Image 1)
  // =========================================================================
  renderNearbyCharities(filterText = "") {
    const container = document.getElementById("nearbyCharitiesList");
    if (!container) return;

    let ngos = window.HopeStore.getNGOs();
    if (filterText && filterText.trim() !== "") {
      const q = filterText.toLowerCase().trim();
      ngos = ngos.filter(
        (n) =>
          n.name.toLowerCase().includes(q) ||
          (n.name_ta && n.name_ta.toLowerCase().includes(q)) ||
          (n.zone && n.zone.toLowerCase().includes(q))
      );
    }

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (ngos.length === 0) {
      container.innerHTML = `
        <div class="empty-state-sm py-2">
          <p class="text-muted small">${isTa ? "பொருத்தமான அமைப்புகள் எதுவும் இல்லை." : "No matching charities found."}</p>
        </div>
      `;
      return;
    }

    const distinctFallbacks = [
      "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1578357078586-491adf1aa5ba?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=600&q=80"
    ];

    container.innerHTML = ngos
      .map((n, idx) => {
        const name = isTa && n.name_ta ? n.name_ta : n.name;
        const cat = n.category || (isTa ? "அறக்கட்டளை அமைப்பு" : "Non-profit organization");
        const dist = `${n.distanceKm || "2.1"} km ${isTa ? "தொலைவில்" : "away"}`;
        const reviews = `${n.reviewsCount || 15} ${isTa ? "மதிப்புரைகள்" : "reviews"}`;
        const selectBtn = isTa ? "தேர்வு செய்" : "Select";
        const dirBtn = isTa ? "வழிகாட்டி" : "Direction";
        const imgUrl = n.imageUrl || distinctFallbacks[idx % distinctFallbacks.length];

        return `
          <div class="nearby-charity-card">
            <div class="charity-card-thumb">
              <img src="${imgUrl}" alt="${name}" loading="lazy">
            </div>
            <div class="charity-card-info">
              <h4 class="charity-title">${name}</h4>
              <p class="charity-category text-muted small">${cat}</p>
              <p class="charity-address text-muted small">📍 ${n.zone || "Central Area"}</p>
              <div class="charity-rating-row">
                <span class="stars">★★★★★</span>
                <span class="rating-val">(${n.rating || "4.9"})</span>
                <span class="dist-pill">${dist}</span>
              </div>
              <div class="charity-actions-row">
                <button class="btn btn-outline btn-xs" type="button" onclick="App.showCharityDirection('${n.id}')">
                  🧭 ${dirBtn}
                </button>
                <button class="btn btn-primary btn-xs" type="button" onclick="App.selectCharityForDonation('${n.id}')">
                  ${selectBtn}
                </button>
              </div>
            </div>
          </div>
        `;
      })
      .join("");
  },

  selectCharityForDonation(ngoId) {
    window.HopeStore.updateState({ selectedNgoId: ngoId });
    this.navigateTo("donate");
    const targetSelect = document.getElementById("donorType");
    const ngo = window.HopeStore.getNgoById(ngoId);
    const ngoName = ngo ? ngo.name : "Selected Charity";
    this.showToast(`🎯 Selected "${ngoName}" for immediate donation dispatch!`, "success");
  },

  showCharityDirection(ngoId) {
    const ngo = window.HopeStore.getNgoById(ngoId);
    if (!ngo) return;
    this.navigateTo("tracker");
    this.showToast(`🧭 Route direction mapped to ${ngo.name} (${ngo.distanceKm || "2.1"} km away)`, "info");
  },

  filterCharities(query) {
    this.renderNearbyCharities(query);
  },

  // =========================================================================
  // 4. 1-Click Hackathon Demo Scenario Injectors
  // =========================================================================
  setupScenarioInjectors() {
    document.querySelectorAll("[data-inject-scenario]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const scenario = btn.getAttribute("data-inject-scenario");
        const created = window.HopeStore.injectScenario(scenario);
        if (created) {
          this.showToast(`⚡ Injected: ${created.quantity} ${created.unit} from ${created.donorName}!`, "success");
          this.renderHomeFeatured();
          if (window.NgoModule) window.NgoModule.renderFeed();
          if (window.DonorModule) window.DonorModule.renderMyDonations();
          if (window.ImpactModule) window.ImpactModule.updateMetrics();
        }
      });
    });
  },

  // =========================================================================
  // 5. View Mode Switcher (Phone Mockup vs Full Screen)
  // =========================================================================
  setupViewMode() {
    const toggleBtn = document.getElementById("viewModeToggleBtn");
    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => this.toggleViewMode());
    }
    this.applyViewMode(this.viewMode);
  },

  toggleViewMode() {
    const nextMode = this.viewMode === "phone" ? "fullscreen" : "phone";
    this.viewMode = nextMode;
    window.HopeStore.updateState({ viewMode: nextMode });
    this.applyViewMode(nextMode);

    const msg = nextMode === "phone"
      ? "Switched to 📱 Phone Mockup Model"
      : "Switched to 🖥️ Full Screen Responsive View";
    this.showToast(msg, "info");
  },

  applyViewMode(mode) {
    const body = document.body;
    const toggleBtn = document.getElementById("viewModeToggleBtn");
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;

    if (mode === "phone") {
      body.classList.add("phone-mode-active");
      if (toggleBtn) {
        const text = isTa ? "🖥️ முழுத்திரை" : "🖥️ Full Screen";
        toggleBtn.innerHTML = `<span>${text}</span>`;
        toggleBtn.setAttribute("title", isTa ? "முழுத்திரை தோற்றத்திற்கு மாற்றவும்" : "Switch to Full Screen Responsive View");
      }
    } else {
      body.classList.remove("phone-mode-active");
      if (toggleBtn) {
        const text = isTa ? "📱 மொபைல் தோற்றம்" : "📱 Phone Mockup";
        toggleBtn.innerHTML = `<span>${text}</span>`;
        toggleBtn.setAttribute("title", isTa ? "மொபைல் மாதிரி தோற்றத்திற்கு மாற்றவும்" : "Switch to Phone Mockup Model View");
      }
    }
  },

  startPhoneClock() {
    const clockEl = document.getElementById("phoneClockDisplay");
    if (!clockEl) return;

    const updateClock = () => {
      const d = new Date();
      clockEl.textContent = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    };
    updateClock();
    setInterval(updateClock, 30000);
  },

  // =========================================================================
  // 6. Demo Role Switcher Synchronization
  // =========================================================================
  setupRoleSwitcher() {
    const select = document.getElementById("demoRoleSelect");
    if (!select) return;

    select.value = this.activeRole;
    select.addEventListener("change", (e) => {
      const newRole = e.target.value;
      this.loginAs(newRole);
    });
  },

  // =========================================================================
  // 7. Language Switcher
  // =========================================================================
  setupLanguageSwitcher() {
    document.querySelectorAll(".lang-switch-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const lang = btn.getAttribute("data-lang");
        if (window.i18n) {
          window.i18n.setLanguage(lang);
          this.showToast(lang === "ta" ? "மொழி: தமிழ் செயல்படுத்தப்பட்டது" : "Language set to English", "info");
        }
      });
    });
  },

  onLanguageChange(lang) {
    this.applyViewMode(this.viewMode);
    this.updateAuthUI();
    this.renderHomeFeatured();
    this.renderNearbyCharities();
    if (window.NgoModule) {
      window.NgoModule.renderNgoSelector();
      window.NgoModule.renderFeed();
    }
    if (window.DonorModule) {
      window.DonorModule.renderMyDonations();
      window.DonorModule.updateLivePreview();
    }
    if (window.TrackingModule) {
      window.TrackingModule.renderTracker();
    }
    if (window.SchedulesModule) {
      window.SchedulesModule.renderSchedules();
    }
    if (window.ImpactModule) {
      window.ImpactModule.updateMetrics();
    }
    if (window.CommunityModule && typeof window.CommunityModule.renderReportsList === "function") {
      window.CommunityModule.renderReportsList();
    }
  },

  // =========================================================================
  // 8. Notification Center Drawer
  // =========================================================================
  setupNotificationCenter() {
    const bellBtn = document.getElementById("notifBellBtn");
    const drawer = document.getElementById("notificationsDrawer");
    const closeBtn = document.getElementById("closeNotifDrawerBtn");
    const clearBtn = document.getElementById("clearNotifsBtn");

    if (bellBtn && drawer) {
      bellBtn.addEventListener("click", () => {
        drawer.classList.toggle("open");
        if (drawer.classList.contains("open")) {
          window.HopeStore.markNotificationsAsRead();
          this.updateNotificationBadge();
        }
      });
    }

    if (closeBtn && drawer) {
      closeBtn.addEventListener("click", () => drawer.classList.remove("open"));
    }

    if (clearBtn) {
      clearBtn.addEventListener("click", () => {
        window.HopeStore.clearNotifications();
        this.renderNotifications();
        this.updateNotificationBadge();
      });
    }

    this.renderNotifications();
    this.updateNotificationBadge();
  },

  renderNotifications() {
    const listEl = document.getElementById("notificationsList");
    if (!listEl) return;

    const notifs = window.HopeStore.getNotifications();
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    if (notifs.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <p class="text-muted">${isTa ? "செயலில் அறிவிப்புகள் எதுவும் இல்லை" : "No active notifications"}</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = notifs
      .map(
        (n) => `
        <div class="notif-item ${n.read ? 'read' : 'unread'} notif-${n.type}">
          <div class="notif-header">
            <strong>${n.title}</strong>
            <small>${new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>
          </div>
          <p class="notif-msg">${n.message}</p>
        </div>
      `
      )
      .join("");
  },

  updateNotificationBadge() {
    const badge = document.getElementById("notifCountBadge");
    if (!badge) return;

    const notifs = window.HopeStore.getNotifications();
    const unreadCount = notifs.filter((n) => !n.read).length;

    if (unreadCount > 0) {
      badge.textContent = unreadCount;
      badge.style.display = "inline-flex";
    } else {
      badge.style.display = "none";
    }
    this.renderNotifications();
  },

  // =========================================================================
  // 9. Toast Alert System
  // =========================================================================
  showToast(message, type = "info", duration = 4000) {
    const toast = document.getElementById("toastNotification");
    if (!toast) return;

    toast.textContent = message;
    toast.className = `toast-notification show toast-${type}`;

    if (this._toastTimer) clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => {
      toast.classList.remove("show");
    }, duration);
  },

  // =========================================================================
  // 10. Reset Demo Data
  // =========================================================================
  confirmResetDemo() {
    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    const confirmMsg = isTa
      ? "ஹோப்லிங்க் டெமோ தரவை ஆரம்ப மாதிரி நிலைக்கு மீட்டமைக்கவா? இது மாதிரி உணவுகள், காப்பகங்கள் மற்றும் அட்டவணைகளை மீண்டும் ஏற்றும்."
      : "Reset HopeLink demo data to its initial sample state? This will reload sample donations, NGOs, and schedules.";
    if (confirm(confirmMsg)) {
      window.HopeStore.resetDemoData();
      this.showToast(window.i18n ? window.i18n.t("toast_reset_done") : "Demo data reset successfully.", "success");
      
      this.renderHomeFeatured();
      if (window.DonorModule) window.DonorModule.renderMyDonations();
      if (window.NgoModule) {
        window.NgoModule.renderNgoSelector();
        window.NgoModule.renderFeed();
      }
      if (window.TrackingModule) window.TrackingModule.renderTracker();
      if (window.SchedulesModule) window.SchedulesModule.renderSchedules();
      if (window.ImpactModule) window.ImpactModule.updateMetrics();
      if (window.CommunityModule) window.CommunityModule.renderReportsList();
      this.updateAuthUI();
      this.updateNotificationBadge();
    }
  }
};

document.addEventListener("DOMContentLoaded", () => {
  App.init();
});

window.App = App;
