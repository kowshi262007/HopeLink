/**
 * HopeLink - Comprehensive Internationalization & Speech Helpers (i18n.js)
 * 
 * Provides:
 * 1. English (en) and Tamil (ta) comprehensive translations for all UI elements
 * 2. Dynamic DOM translation helper supporting text, placeholders, and titles
 * 3. Browser Speech Recognition (Voice Typing) with fallback
 * 4. Text-to-Speech (Audio Readout) with animated soundwave support
 */

const DICTIONARY = {
  en: {
    // Demo Bar & Navigation
    app_title: "HopeLink",
    app_tagline: "Bridging Surplus Food to Empty Plates",
    platform_pill: "🌱 HopeLink Demo Platform",
    view_phone_mode: "📱 Phone Mockup",
    view_full_mode: "🖥️ Full Screen",
    btn_reset_demo: "↺ Reset Demo",
    nav_home: "Home",
    nav_donate: "Donate Food",
    nav_ngo: "NGO Portal",
    nav_tracker: "Tracker",
    nav_schedules: "Recurring",
    nav_impact: "Impact",
    nav_safety: "Safety",
    nav_community: "Community",

    // New Reference Greetings, Roles & Nearby Charities (Image 1 & 3)
    greeting_hello: "Hello, Good People! 👋",
    greeting_title: "Support Local Food Rescue",
    search_charity_ph: "Search Charity(s) or food rescues...",
    banner_waste_tag: "⚠️ Don't Waste Food",
    banner_waste_heading: "Someone is dying for the food you trash.",
    banner_waste_sub: "Don't throw away, instead give away! Every meal saved feeds a hungry child or family.",
    btn_donate_now_orange: "🍲 Donate Food Now",
    role_action_title: "Can you donate or share a food?",
    role_action_sub: "Choose your role to get started:",
    role_donor_card_title: "Donor",
    role_donor_card_sub: "Donate your food for needy",
    role_donor_card_cta: "Donate Now →",
    role_ngo_card_title: "NGO Shelter",
    role_ngo_card_sub: "Claim surplus food & feed people",
    role_ngo_card_cta: "View NGO Feed →",
    role_driver_card_title: "Volunteer",
    role_driver_card_sub: "Pickup & deliver live orders",
    role_driver_card_cta: "Track Live →",
    nearby_charities_title: "Near by Charity(s)",
    nearby_charities_sub: "Verified local shelters ready to receive meals",
    see_all: "See All >>",
    pill_pending: "Pending:",
    pill_accepted: "Accepted:",
    pill_declined: "Declined:",
    pill_picked: "In Transit / Picked:",

    // Auth & Personas
    btn_login: "Log In",
    btn_logout: "Log Out",
    modal_login_title: "Sign In to HopeLink",
    modal_login_subtitle: "Choose a demo persona or enter details to switch perspectives",
    quick_personas_title: "⚡ 1-Click Demo Accounts",
    custom_signin_title: "Or Custom Sign In",
    logged_in_as: "Logged in as",
    role_label: "Demo Role:",
    role_donor: "Donor View",
    role_ngo: "NGO View",
    role_driver: "Volunteer / Driver",
    role_admin: "Demo Admin",
    role_donor_opt: "👤 Donor View",
    role_ngo_opt: "🏢 NGO Manager View",
    role_driver_opt: "🛵 Volunteer / Driver View",
    role_admin_opt: "👑 Demo Admin View",
    demo_banner: "Demo Sandbox: localStorage mode. Simulated in-app actions. No real SMS or passwords needed.",
    donor_persona_name: "Green Leaf Bistro",
    donor_persona_desc: "List surplus food & track pickup status",
    ngo_persona_name: "Akshaya Food Bank",
    ngo_persona_desc: "Review matching donations & dispatch drivers",
    driver_persona_name: "Karthik R. (Volunteer)",
    driver_persona_desc: "Real-time GPS tracker & status progression",
    admin_persona_name: "HopeLink Administrator",
    admin_persona_desc: "Analytics dashboard & platform governance",
    btn_signin_donor: "Sign In as Donor →",
    btn_signin_ngo: "Sign In as NGO →",
    btn_signin_driver: "Sign In as Driver →",
    btn_signin_admin: "Sign In as Admin →",
    custom_name_label: "Full Name / Organization",
    custom_role_label: "Select Role",
    custom_email_label: "Email Address (Optional)",
    custom_signin_btn: "Sign In to HopeLink",

    // Hero Section
    hero_badge: "Zero Food Waste • Maximum Community Impact",
    hero_title_1: "Bridging Surplus Food to",
    hero_title_2: "Empty Plates",
    hero_desc: "HopeLink connects compassionate food donors—restaurants, supermarkets, marriage halls, caterers, and homes—with local verified NGOs in real-time. Together, we turn excess food into warm meals for those in need.",
    btn_donate_food: "Donate Food",
    btn_explore_donations: "Explore Donations",
    btn_ngo_dashboard: "NGO Dashboard",
    trust_free: "100% Free & Community Driven",
    trust_verified: "Verified NGO Network",
    trust_safe: "Instant Match & Safe Pickup",
    hero_active_rescue: "Active Food Rescue",
    hero_live_match: "Live Simulated Match",
    hero_card_snippet: "Surplus Catering • 85 Fresh Meals",
    hero_driver_dispatched: "Status: Driver Dispatched (15 mins)",
    hero_safe_remaining: "Safe window: 3.5 hours remaining",
    hero_inspected_safe: "Inspected & Safe",
    hero_dist_away: "2.1 km away",
    confirm_tracking_id_lbl: "Tracking ID:",
    notif_title: "In-App Notifications",
    notif_clear: "Clear All",
    notif_footnote: "Simulated in-app alerts. Production requires cloud messaging gateway.",
    donor_name_placeholder: "e.g. Green Leaf Bistro or Ramesh Kumar",
    food_name_placeholder: "e.g. Vegetable Pulav, Dal Tadka & Chapatis",
    food_desc_placeholder: "Describe the dishes, packaging containers (trays/boxes), and any handling notes...",
    pickup_addr_placeholder: "Street address, building name, area",
    pickup_instr_placeholder: "e.g. Service gate 2, call upon reaching",
    driver_name_placeholder: "e.g. Karthik R. (Van DL-04-1234)",
    driver_phone_placeholder: "+91 98401 23456",

    // 1-Click Hackathon Scenarios
    hackathon_scenarios_title: "⚡ 1-Click Hackathon Demo Scenarios:",
    scenario_biryani: "🍛 100 Biryani Meals (Wedding Hall • Urgent 2h)",
    scenario_bakery: "🥖 45 French Loaves (Bakery • Pure Veg)",
    scenario_fruits: "🍎 75 kg Fresh Fruits (Agro Wholesale)",

    // Home Featured Section
    home_featured_title: "Featured Available Food Rescues",
    home_featured_subtitle: "Real-time surplus food available right now in your local neighborhood radius.",
    btn_view_all_feed: "View Complete NGO Feed →",
    badge_available_live: "Live Feed",

    // How It Works
    how_tag: "Simple & Transparent",
    how_title: "How HopeLink Works",
    how_subtitle: "A seamless 3-step connection from kitchen to community.",
    how_step1_title: "1. Donors List Surplus",
    how_step1_desc: "Enter meal portions, food category, preparation time, and safe collection window in under 2 minutes.",
    how_step1_btn: "Try Donation Form →",
    how_step2_title: "2. Rule-Based Match",
    how_step2_desc: "Transparent algorithm scores distance, urgency, food category, and shelter capacity to alert nearby NGOs.",
    how_step2_btn: "View NGO Feed →",
    how_step3_title: "3. Safe Pickup & Feed",
    how_step3_desc: "Volunteer drivers inspect packaging, collect the donation, and deliver nutritious meals to shelters.",
    how_step3_btn: "Open Live Tracker →",

    // Demo Statistics Banner
    stats_tag: "Verified Local Demo Statistics",
    stats_title: "Community Food Rescue In Action",
    stats_desc: "Aggregated automatically from active and fulfilled records in this demo session.",
    stats_meals_served: "Meals Served",
    stats_partner_ngos: "Partner NGOs",
    stats_waste_diverted: "Food Waste Diverted",
    stats_success_rate: "Rescue Success Rate",

    // Donor Form
    donor_form_title: "Donate Surplus Food",
    donor_form_subtitle: "List edible surplus food in under 2 minutes for nearby shelter collection.",
    lbl_donor_name: "Donor / Organization Name *",
    lbl_donor_type: "Donor Category *",
    lbl_food_name: "Food Item Name *",
    lbl_food_desc: "Food Description & Packaging Notes",
    lbl_food_cat: "Category *",
    lbl_dietary: "Dietary *",
    lbl_quantity: "Quantity *",
    lbl_prep_time: "Preparation Time *",
    lbl_deadline: "Safe Collection Deadline *",
    lbl_storage: "Storage Condition *",
    lbl_allergens: "Allergen Declarations",
    lbl_location: "Pickup Address & Landmark *",
    lbl_instructions: "Pickup Instructions",
    lbl_phone: "Contact Phone *",
    lbl_hide_phone: "Mask phone number on public list (Protect Privacy)",
    btn_submit_donation: "Submit Donation Listing",
    btn_voice_input: "Voice Dictate",
    btn_listening: "Listening...",
    live_card_preview_title: "Live Preview (How NGOs see your listing)",
    quick_presets: "Quick Expiry Presets:",
    safety_ack_bold: "Food Safety Acknowledgment:",
    safety_ack_text: "I confirm this food is fresh, prepared under clean hygienic conditions, and kept within safe temperature guidelines.",
    preview_mock_hint: "NGO Claim Button Enabled on Submission",
    my_donations_heading: "My Active Donation Listings",
    my_donations_sub: "Manage your current listings, edit details, or track dispatch status.",
    no_donations_yet: "No Donations Yet",
    no_donations_desc: "Submit your first surplus food listing above to help local shelters.",

    // Donor Types
    donor_individual: "Individual",
    donor_family: "Household / Family",
    donor_restaurant: "Restaurant / Cafe",
    donor_hotel: "Hotel / Buffet",
    donor_marriage_hall: "Marriage / Banquet Hall",
    donor_event: "Event Caterer",
    donor_cafeteria: "College / Corporate Cafeteria",

    // Categories & Conditions
    cat_cooked: "Cooked Meals",
    cat_bakery: "Bakery & Breads",
    cat_produce: "Fresh Produce / Fruits",
    cat_dairy: "Dairy & Milk Products",
    cat_packaged: "Packaged / Canned",
    diet_veg: "🟢 Pure Veg",
    diet_nonveg: "🔴 Non-Veg",
    cond_hot: "Hot Insulated (> 60°C)",
    cond_cold: "Refrigerated (< 5°C)",
    cond_room: "Room Temp (< 4 Hours)",

    // Units & Allergens
    unit_portions: "Servings",
    unit_kg: "kg",
    unit_boxes: "Boxes",
    unit_trays: "Trays",
    allergen_dairy: "Dairy",
    allergen_gluten: "Gluten",
    allergen_nuts: "Nuts",
    allergen_soy: "Soy",

    // NGO Dashboard
    ngo_dash_title: "Verified NGO Feed & Dispatch",
    ngo_dash_subtitle: "Browse available surplus food listings, inspect match scores, and claim for your shelter.",
    ngo_viewing_as: "Viewing as Partner NGO:",
    filter_category: "Category",
    filter_dietary: "Dietary",
    filter_urgency: "Urgency",
    chip_all: "All Listings",
    chip_cooked: "🍲 Cooked Meals",
    chip_bakery: "🥖 Bakery Breads",
    chip_produce: "🍎 Fruits & Veggies",
    chip_veg: "🟢 Pure Veg Only",
    chip_urgent: "⚡ Urgent (< 2.5h)",
    search_listings_lbl: "Search Listings",
    search_placeholder: "Search food, donor, or area...",
    opt_all_categories: "All Categories",
    opt_all_diets: "All Diets",
    opt_all_timelines: "All Timelines",
    opt_urgent_2h: "⚡ Expiring in < 2 Hours",
    opt_urgent_4h: "⏳ Expiring in < 4 Hours",
    btn_claim_shelter: "Claim for Shelter →",
    btn_track_journey: "Track Journey ↗",
    btn_release_donation: "Release Listing",
    btn_assign_driver: "Assign Volunteer Driver",
    badge_available: "Available",
    badge_accepted: "Accepted",
    badge_assigned: "Driver Assigned",
    badge_collected: "Collected",
    badge_distributed: "Distributed",
    badge_overdue: "⚠️ Overdue",
    verified_nonprofit_partner: "✓ Verified Non-Profit Partner",
    max_batch_port: "Max Batch:",
    accepts_veg_nonveg: "Accepts Veg & Non-Veg",
    strictly_pure_veg: "Strictly Pure Veg Only",
    assigned_vehicle: "🚗 Assigned Vehicle:",
    match_score_label: "Match Score",

    // Matching Algorithm
    match_score_title: "Rule-Based Match Score",
    match_disclaimer: "Transparent heuristic algorithm (Distance, Urgency, NGO Capacity, Food Type). Not AI.",
    score_distance: "Distance Proximity:",
    score_urgency: "Expiry Urgency:",
    score_suitability: "Food Policy Match:",
    score_capacity: "Portion Capacity:",

    // Pickup Tracker
    tracker_title: "Live Pickup & Distribution Tracker",
    tracker_subtitle: "Follow the transparent journey of food rescue from donor kitchen to beneficiary plates.",
    tracker_select_order: "Select Active Food Rescue Order:",
    tracker_read_aloud: "🔊 Read Aloud",
    tracker_safe_overdue: "Safe Collection Window Overdue!",
    tracker_safe_overdue_desc: "The safe collection deadline passed. Physical sensory inspection (aroma/temperature) is mandatory before distribution.",
    tracker_posted_by: "Posted by:",
    tracker_tracking_code: "Tracking Code:",
    step_1: "1. Available",
    step_2: "2. Accepted",
    step_3: "3. Driver Assigned",
    step_4: "4. Collected",
    step_5: "5. Distributed",
    btn_mark_collected: "✓ Confirm Driver Picked Up Food",
    btn_mark_distributed: "✓ Confirm Distributed to Beneficiaries",
    backup_ngo_title: "Backup NGO Suggestions",
    backup_ngo_desc: "If the current NGO cannot dispatch within 45 minutes, transfer to highest matching backup shelter:",
    btn_transfer_backup: "Transfer to Backup NGO →",

    // Recurring Schedules
    sched_title: "Recurring Surplus Schedules",
    sched_subtitle: "Automate regular pickups for predictable surplus from corporate cafeterias, hotels, and banquet halls.",
    sched_reg_title: "Register a Recurring Schedule",
    sched_donor_org: "Organization / Donor Name *",
    sched_donor_type_lbl: "Donor Type *",
    sched_opt_cafeteria: "Cafeteria / Canteen",
    sched_opt_hall: "Marriage / Banquet Hall",
    sched_opt_hotel: "Hotel / Buffet",
    sched_opt_restaurant: "Restaurant",
    sched_food_item: "Typical Surplus Item *",
    sched_frequency_lbl: "Frequency *",
    sched_freq_daily: "Daily (Mon-Sun)",
    sched_freq_weekdays: "Weekdays Only (Mon-Fri)",
    sched_freq_weekends: "Weekends Only (Sat-Sun)",
    sched_est_portions: "Estimated Portions *",
    sched_pref_time: "Preferred Pickup Time *",
    sched_pickup_addr: "Pickup Address *",
    sched_coord_contact: "Coordinator Contact *",
    btn_save_schedule: "Save Recurring Schedule",
    sched_active_head: "Active Recurring Schedules",
    btn_post_today: "⚡ Post Today's Listing",
    no_schedules_yet: "No Recurring Schedules",
    no_schedules_desc: "Create a recurring schedule for regular surplus from cafeterias or banquet halls.",

    // Impact Dashboard
    impact_title: "Live Community Impact Dashboard",
    impact_subtitle: "Calculated automatically from active and fulfilled records in this demo session.",
    stat_meals: "Meals Rescued",
    stat_kg: "kg Food Saved",
    stat_co2: "kg CO₂ Prevented",
    stat_success: "Rescue Success Rate",
    impact_active_donors: "Active Community Donors",
    impact_partner_shelters: "Verified Partner Shelters",
    impact_rescued_by_cat: "Rescued Food by Category",

    // Safety Guidelines
    safety_title: "Food Safety & Handling Checklist",
    safety_guidelines_sub: "Guidelines and protocols ensuring food is handled safely from donor to recipient.",
    safety_disclaimer_title: "Important Compliance Notice",
    safety_disclaimer_body: "HopeLink provides coordination software. Form submission does NOT guarantee food safety. Consumable verification, physical hygiene check, and compliance with local municipal safety standards are required prior to consumption.",
    rule_1_badge: "Rule 1",
    rule_1_title: "Temperature Danger Zone",
    rule_1_desc: "Keep hot food above 60°C or chilled food below 5°C. Never leave cooked perishable meals at ambient room temperature for more than 4 hours.",
    rule_2_badge: "Rule 2",
    rule_2_title: "Clean Food Packaging",
    rule_2_desc: "All surplus donations must be held in clean, food-grade stainless steel vessels or sealed disposable food-grade containers to prevent contamination.",
    rule_3_badge: "Rule 3",
    rule_3_title: "Clear Allergen Notice",
    rule_3_desc: "Donors must explicitly declare common allergens such as dairy, gluten, nuts, and soy so shelters can safely feed children and vulnerable individuals.",
    rule_4_badge: "Rule 4",
    rule_4_title: "Mandatory Sensory Inspection",
    rule_4_desc: "Volunteer collectors must verify the freshness, aroma, appearance, and physical temperature before accepting and distributing any meal.",

    // Community Guidelines & Issue Reporting
    community_title: "Community Guidelines & Problem Reporting",
    community_sub: "A respectful, privacy-conscious community uniting donors, shelters, and volunteers.",
    privacy_card_title: "🔒 Privacy Safeguards",
    privacy_phone_bold: "Phone Number Masking:",
    privacy_phone_text: "Donors can mask their mobile numbers from public listings to avoid unwanted unsolicited calls.",
    privacy_loc_bold: "Protected Residential Locations:",
    privacy_loc_text: "Precise apartment numbers are shared only with verified assigned volunteer drivers upon dispatch.",
    privacy_dignity_bold: "Dignity of Beneficiaries:",
    privacy_dignity_text: "Photos and identities of vulnerable shelter recipients are never published or made public.",
    report_issue_title: "Report an Issue / Safety Concern",
    report_cat_lbl: "Issue Category *",
    report_cat_spoiled: "Spoiled / Unsafe Food Concern",
    report_cat_noshow: "Driver No-Show / Delay",
    report_cat_mismatch: "Inaccurate Portion Count",
    report_cat_location: "Incorrect Pickup Address",
    report_cat_other: "Other Community Feedback",
    report_donation_id_lbl: "Related Donation ID (Optional)",
    report_role_lbl: "Your Role",
    report_role_donor: "Food Donor",
    report_role_ngo: "NGO Representative",
    report_role_driver: "Volunteer Driver",
    report_role_community: "Community Member",
    report_contact_lbl: "Your Contact (Phone or Email)",
    report_desc_lbl: "Detailed Description *",
    report_desc_placeholder: "Please describe the issue in detail so coordinators can investigate...",
    report_btn_submit: "Submit Issue Report",
    report_recent_title: "Recent Reports (Demo Audit Trail)",
    no_reports_yet: "No safety or community issues logged in this demo session. All operations normal.",

    // Modals
    confirm_modal_title: "Donation Listing Live!",
    confirm_modal_view_feed: "View Listing in NGO Feed →",
    driver_modal_heading: "Assign Volunteer Driver",
    driver_modal_sub: "Dispatch collector for pickup",
    driver_input_name: "Driver / Volunteer Name",
    driver_input_phone: "Driver Contact Phone",
    btn_confirm_driver_dispatch: "Confirm Driver Dispatch",

    // Action Toast messages
    toast_claimed: "Listing claimed successfully by your NGO!",
    toast_released: "Listing released back to the community pool.",
    toast_assigned: "Volunteer driver assigned for pickup.",
    toast_collected: "Pickup verified! Food is now in transit.",
    toast_distributed: "Impact confirmed! Meals distributed to beneficiaries.",
    toast_reset_done: "Demo data has been restored to default state.",
    toast_scenario_injected: "⚡ Live Demo Scenario injected successfully!"
  },

  ta: {
    // Demo Bar & Navigation
    app_title: "ஹோப்லிங்க்",
    app_tagline: "உணவு வீணாவதைத் தடுத்து பசி போக்குவோம்",
    platform_pill: "🌱 ஹோப்லிங்க் மாதிரி தளம்",
    view_phone_mode: "📱 மொபைல் தோற்றம்",
    view_full_mode: "🖥️ முழுத்திரை",
    btn_reset_demo: "↺ மீட்டமைக்க",
    nav_home: "முகப்பு",
    nav_donate: "உணவு தானம்",
    nav_ngo: "என்.ஜி.ஓ தளம்",
    nav_tracker: "கண்காணிப்பு",
    nav_schedules: "தொடர் திட்டங்கள்",
    nav_impact: "தாக்கம்",
    nav_safety: "உணவு பாதுகாப்பு",
    nav_community: "சமூகம்",

    // New Reference Greetings, Roles & Nearby Charities (Tamil)
    greeting_hello: "வணக்கம் நல்ல உள்ளங்களே! 👋",
    greeting_title: "உள்ளூர் உணவு மீட்பிற்கு கைகோருங்கள்",
    search_charity_ph: "தன்னார்வ அமைப்புகள் அல்லது உணவுகளைத் தேடுங்கள்...",
    banner_waste_tag: "⚠️ உணவை வீணாக்காதீர்கள்",
    banner_waste_heading: "நீங்கள் தூக்கி எறியும் உணவிற்காக யாரோ ஒருவர் ஏங்குகிறார்.",
    banner_waste_sub: "வீணாக எறியாதீர்கள், பசி தீர்க்க வழங்குங்கள்! நீங்கள் மிச்சப்படுத்தும் ஒவ்வொரு உணவும் ஒரு குழந்தையின் பசியைப் போக்கும்.",
    btn_donate_now_orange: "🍲 இப்போது உணவு வழங்குக",
    role_action_title: "உங்களால் உணவு வழங்கி உதவ முடியுமா?",
    role_action_sub: "தொடங்க உங்கள் பொறுப்பைத் தேர்வு செய்யவும்:",
    role_donor_card_title: "நன்கொடையாளர்",
    role_donor_card_sub: "தேவைப்படுவோருக்கு உணவு வழங்குங்கள்",
    role_donor_card_cta: "இப்போது வழங்குக →",
    role_ngo_card_title: "அறக்கட்டளை இல்லம்",
    role_ngo_card_sub: "உபரி உணவை ஏற்றுப் பசி தீருங்கள்",
    role_ngo_card_cta: "அமைப்புகள் தளம் →",
    role_driver_card_title: "தன்னார்வலர்",
    role_driver_card_sub: "உணவைச் சேகரித்து விநியோகிக்கவும்",
    role_driver_card_cta: "நேரடிக் கண்காணிப்பு →",
    nearby_charities_title: "அருகிலுள்ள அறக்கட்டளைகள்",
    nearby_charities_sub: "உணவைப் பெறத் தயாராக உள்ள சரிபார்க்கப்பட்ட அமைப்புகள்",
    see_all: "அனைத்தையும் காண்க >>",
    pill_pending: "நிலுவையில்:",
    pill_accepted: "ஏற்கப்பட்டது:",
    pill_declined: "நிராகரிப்பு:",
    pill_picked: "வழியில் / சேர்ந்தவை:",

    // Auth & Personas
    btn_login: "உள்நுழை",
    btn_logout: "வெளியேறு",
    modal_login_title: "ஹோப்லிங்கில் உள்நுழைக",
    modal_login_subtitle: "மாதிரி கணக்கைத் தேர்வு செய்து பார்வையை உடனடியாக மாற்றவும்",
    quick_personas_title: "⚡ 1-கிளிக் மாதிரி கணக்குகள்",
    custom_signin_title: "அல்லது உங்கள் பெயரில் உள்நுழைய",
    logged_in_as: "உள்நுழைந்துள்ளவர்",
    role_label: "பார்வை முறை:",
    role_donor: "நன்கொடையாளர்",
    role_ngo: "அறக்கட்டளை",
    role_driver: "ஓட்டுநர் / தொண்டர்",
    role_admin: "நிர்வாகி",
    role_donor_opt: "👤 நன்கொடையாளர் பார்வை",
    role_ngo_opt: "🏢 தொண்டு நிறுவனம் பார்வை",
    role_driver_opt: "🛵 தன்னார்வல ஓட்டுநர் பார்வை",
    role_admin_opt: "👑 நிர்வாகி பார்வை",
    demo_banner: "டெமோ மாதிரி: உலாவி சேமிப்பு மட்டுமே. கடவுச்சொல் அல்லது வங்கி விவரங்கள் தேவையில்லை.",
    donor_persona_name: "கிரீன் லீஃப் பிஸ்ட்ரோ",
    donor_persona_desc: "உபரி உணவை பதிவிட்டு சேகரிப்பைக் கண்காணிக்கவும்",
    ngo_persona_name: "அக்ஷயா உணவு வங்கி",
    ngo_persona_desc: "பொருத்தமான உணவை ஏற்று ஓட்டுநரை அனுப்பவும்",
    driver_persona_name: "கார்த்திக் ஆர். (தொண்டர்)",
    driver_persona_desc: "நேரடி சேகரிப்பு மற்றும் விநியோகப் பதிவு",
    admin_persona_name: "ஹோப்லிங்க் தலைமை நிர்வாகி",
    admin_persona_desc: "முழு தளத்தின் புள்ளிவிவரங்கள் மற்றும் மேலாண்மை",
    btn_signin_donor: "வழங்குநராக நுழைக →",
    btn_signin_ngo: "காப்பகமாக நுழைக →",
    btn_signin_driver: "ஓட்டுநராக நுழைக →",
    btn_signin_admin: "நிர்வாகியாக நுழைக →",
    custom_name_label: "முழு பெயர் / அமைப்பு",
    custom_role_label: "பொறுப்பைத் தேர்வு செய்க",
    custom_email_label: "மின்னஞ்சல் முகவரி (விருப்பம்)",
    custom_signin_btn: "ஹோப்லிங்கில் நுழைக",

    // Hero Section
    hero_badge: "உணவு வீணடிப்பு பூஜ்ஜியம் • சமூக உதவி",
    hero_title_1: "உபரி உணவை மாற்றுகிறோம்",
    hero_title_2: "மகிழ்ச்சியான உணவாக",
    hero_desc: "ஹோப்லிங்க் உணவகங்கள், திருமண மண்டபங்கள், சமையல் கலைஞர்கள் மற்றும் வீடுகளில் உள்ள உபரி உணவை தகுதியான தொண்டு நிறுவனங்களுடன் உடனுக்குடன் இணைக்கிறது. பசியில்லாத சமூகத்தை ஒன்றிணைந்து உருவாக்குவோம்.",
    btn_donate_food: "உணவு தானம் செய்",
    btn_explore_donations: "உணவுப் பட்டியலை காண்க",
    btn_ngo_dashboard: "என்.ஜி.ஓ டாஷ்போர்டு",
    trust_free: "100% இலவச சேவை",
    trust_verified: "சரிபார்க்கப்பட்ட தொண்டு நிறுவனங்கள்",
    trust_safe: "விரைவான மற்றும் பாதுகாப்பான சேகரிப்பு",
    hero_active_rescue: "செயலில் உள்ள உணவு மீட்பு",
    hero_live_match: "நேரடி மாதிரிப் பொருத்தம்",
    hero_card_snippet: "உபரி சமையல் • 85 புதிய உணவுகள்",
    hero_driver_dispatched: "நிலை: ஓட்டுநர் கிளம்பினார் (15 நிமி)",
    hero_safe_remaining: "பாதுகாப்பான நேரம்: 3.5 மணி மீதம்",
    hero_inspected_safe: "சரிபார்க்கப்பட்டது • பாதுகாப்பு",
    hero_dist_away: "2.1 கி.மீ தொலைவு",
    confirm_tracking_id_lbl: "கண்காணிப்பு எண்:",
    notif_title: "உள்-செயலி அறிவிப்புகள்",
    notif_clear: "அனைத்தையும் நீக்கு",
    notif_footnote: "மாதிரி விழிப்பூட்டல்கள். நேரடி பயன்பாட்டிற்கு கிளவுட் மெசேஜிங் தேவை.",
    donor_name_placeholder: "எ.கா. கிரீன் லீஃப் உணவகம் அல்லது ரமேஷ் குமார்",
    food_name_placeholder: "எ.கா. வெஜிடபிள் புலாவ், தால் மற்றும் சப்பாத்தி",
    food_desc_placeholder: "உணவு விவரம், பேக்கிங் பெட்டிகள் மற்றும் பிற குறிப்புகளை எழுதவும்...",
    pickup_addr_placeholder: "தெரு முகவரி, கட்டிடப் பெயர், பகுதி",
    pickup_instr_placeholder: "எ.கா. நுழைவாயில் 2, வந்தவுடன் அழைக்கவும்",
    driver_name_placeholder: "எ.கா. கார்த்திக் ஆர். (வேன் TN-09-5678)",
    driver_phone_placeholder: "+91 98401 23456",

    // 1-Click Hackathon Scenarios
    hackathon_scenarios_title: "⚡ 1-கிளிக் நேரடி மாதிரி காட்சிகள்:",
    scenario_biryani: "🍛 100 பிரியாணி உணவுகள் (மண்டபம் • அவசரம் 2 மணி)",
    scenario_bakery: "🥖 45 பிரெஞ்சு ரொட்டிகள் (பேக்கரி • சைவம்)",
    scenario_fruits: "🍎 75 கிலோ பழங்கள் (மொத்த விற்பனை)",

    // Home Featured Section
    home_featured_title: "நேரடி உபரி உணவுப் பட்டியல்",
    home_featured_subtitle: "உங்கள் சுற்றுவட்டாரப் பகுதியில் உடனடியாகப் பெறக்கூடிய உபரி உணவுகள்.",
    btn_view_all_feed: "முழு என்.ஜி.ஓ தளத்திற்குச் செல்ல →",
    badge_available_live: "நேரடிப் பட்டியல்",

    // How It Works
    how_tag: "எளிய மற்றும் வெளிப்படையான",
    how_title: "ஹோப்லிங்க் எவ்வாறு செயல்படுகிறது",
    how_subtitle: "சமையலறையிலிருந்து சமூகத்திற்கு 3 எளிய படிகள்.",
    how_step1_title: "1. உபரி உணவை பதிவு செய்தல்",
    how_step1_desc: "உணவின் அளவு, வகை, சமைத்த நேரம் மற்றும் எடுக்கும் நேரத்தை 2 நிமிடங்களில் எளிதாகப் பதிவு செய்யவும்.",
    how_step1_btn: "தானப் படிவம் திறக்க →",
    how_step2_title: "2. விதிமுறைப் பொருத்தம்",
    how_step2_desc: "தூரம், அவசரக் காலம் மற்றும் கொள்ளளவைக் கணக்கிட்டு அருகிலுள்ள தகுதியான காப்பகத்திற்கு அறிவிக்கும்.",
    how_step2_btn: "என்.ஜி.ஓ தளம் காண்க →",
    how_step3_title: "3. பாதுகாப்பாக பெற்று வழங்குதல்",
    how_step3_desc: "தன்னார்வலர்கள் உணவின் சுகாதாரத்தை ஆய்வு செய்து பெற்று உரிய காப்பகங்களுக்கு வழங்குகின்றனர்.",
    how_step3_btn: "நேரடி கண்காணிப்பு →",

    // Demo Statistics Banner
    stats_tag: "சரிபார்க்கப்பட்ட மாதிரி புள்ளிவிவரங்கள்",
    stats_title: "உணவு மீட்பு கள நிலவரம்",
    stats_desc: "இந்த அமர்வில் பதிவுசெய்யப்பட்ட உணவுகளிலிருந்து தானாக தொகுக்கப்பட்டது.",
    stats_meals_served: "வழங்கப்பட்ட உணவுகள்",
    stats_partner_ngos: "இணைந்துள்ள தொண்டு நிறுவனங்கள்",
    stats_waste_diverted: "தவிர்க்கப்பட்ட உணவு வீணடிப்பு",
    stats_success_rate: "மீட்பு வெற்றி விகிதம்",

    // Donor Form
    donor_form_title: "உபரி உணவு தானப் பதிவு",
    donor_form_subtitle: "2 நிமிடங்களுக்குள் உணவு விவரங்களைப் பதிவிட்டு அருகிலுள்ள காப்பகத்திற்கு உதவவும்.",
    lbl_donor_name: "நன்கொடையாளர் / அமைப்பின் பெயர் *",
    lbl_donor_type: "நன்கொடையாளர் பிரிவு *",
    lbl_food_name: "உணவின் பெயர் *",
    lbl_food_desc: "உணவு விவரம் மற்றும் குறிப்புகள்",
    lbl_food_cat: "உணவு வகை *",
    lbl_dietary: "உணவு முறை *",
    lbl_quantity: "அளவு / எத்தனை பேருக்கு *",
    lbl_prep_time: "தயாரிக்கப்பட்ட நேரம் *",
    lbl_deadline: "பாதுகாப்பான கடைசி நேரம் *",
    lbl_storage: "தற்போதைய சேமிப்பு நிலை *",
    lbl_allergens: "ஒவ்வாமை எச்சரிக்கைகள்",
    lbl_location: "உணவு எடுக்கும் முகவரி & அடையாளம் *",
    lbl_instructions: "நுழைவு வாயில் வழிகாட்டல்",
    lbl_phone: "தொடர்பு தொலைபேசி எண் *",
    lbl_hide_phone: "பொதுப் பட்டியலில் எண்ணை மறைக்க (ரகசியம் காக்க)",
    btn_submit_donation: "உணவு பதிவைச் சமர்ப்பிக்க",
    btn_voice_input: "குரல் வழி பதிவு",
    btn_listening: "கேட்கிறது...",
    live_card_preview_title: "நேரடி அட்டை பார்வை (என்.ஜி.ஓக்கள் பார்க்கும் விதம்)",
    quick_presets: "விரைவு காலக்கெடு தேர்வுகள்:",
    safety_ack_bold: "உணவுப் பாதுகாப்பு உறுதிமொழி:",
    safety_ack_text: "இந்த உணவு புதியது, சுத்தமான சுகாதாரமான முறையில் தயாரிக்கப்பட்டு சரியான வெப்பநிலையில் வைக்கப்பட்டுள்ளது என்பதை உறுதிப்படுத்துகிறேன்.",
    preview_mock_hint: "படிவம் சமர்ப்பிக்கப்பட்டவுடன் என்.ஜி.ஓக்கள் ஏற்றுக்கொள்வர்",
    my_donations_heading: "எனது நேரடி உணவுப் பதிவுகள்",
    my_donations_sub: "உங்கள் பதிவுகளை நிர்வகிக்கவும், திருத்தவும் அல்லது கண்காணிக்கவும்.",
    no_donations_yet: "இன்னும் பதிவுகள் இல்லை",
    no_donations_desc: "உபரி உணவுப் பதிவைச் சமர்ப்பித்து அருகிலுள்ள காப்பகத்திற்கு உதவவும்.",

    // Donor Types
    donor_individual: "தனிநபர்",
    donor_family: "குடும்பம் / இல்லம்",
    donor_restaurant: "உணவகம் / கஃபே",
    donor_hotel: "ஹோட்டல் / பஃபே",
    donor_marriage_hall: "திருமண மண்டபம்",
    donor_event: "நிகழ்ச்சி ஏற்பாட்டாளர்",
    donor_cafeteria: "கல்லூரி / அலுவலக கேண்டீன்",

    // Categories & Conditions
    cat_cooked: "சமைத்த உணவு",
    cat_bakery: "ரொட்டி மற்றும் பேக்கரி",
    cat_produce: "புதிய காய்கறிகள் & பழங்கள்",
    cat_dairy: "பால் & பால் பொருட்கள்",
    cat_packaged: "பாக்கெட் செய்யப்பட்ட உணவு",
    diet_veg: "🟢 சைவம்",
    diet_nonveg: "🔴 அசைவம்",
    cond_hot: "சூடாக வைக்கப்பட்டது (> 60°C)",
    cond_cold: "குளிரூட்டப்பட்டது (< 5°C)",
    cond_room: "அறை வெப்பநிலையில் (< 4 மணிநேரம்)",

    // Units & Allergens
    unit_portions: "உணவுகள்",
    unit_kg: "கிலோ",
    unit_boxes: "பெட்டிகள்",
    unit_trays: "தட்டுகள்",
    allergen_dairy: "பால் பொருட்கள்",
    allergen_gluten: "குளுட்டன்",
    allergen_nuts: "கொட்டைகள்",
    allergen_soy: "சோயா",

    // NGO Dashboard
    ngo_dash_title: "தொண்டு நிறுவன டாஷ்போர்டு",
    ngo_dash_subtitle: "கிடைக்கும் உணவுப் பட்டியலைப் பார்த்து, பொருத்த மதிப்பீட்டை அறிந்து உங்கள் காப்பகத்திற்குப் பெறவும்.",
    ngo_viewing_as: "தேர்ந்தெடுக்கப்பட்ட தொண்டு நிறுவனம்:",
    filter_category: "வகை",
    filter_dietary: "உணவு முறை",
    filter_urgency: "அவசரம்",
    chip_all: "அனைத்துப் பதிவுகளும்",
    chip_cooked: "🍲 சமைத்த உணவு",
    chip_bakery: "🥖 பேக்கரி ரொட்டி",
    chip_produce: "🍎 பழங்கள் & காய்கறிகள்",
    chip_veg: "🟢 சைவம் மட்டுமே",
    chip_urgent: "⚡ அவசரம் (< 2.5 மணி)",
    search_listings_lbl: "உணவுப் பதிவுகளைத் தேடுக",
    search_placeholder: "உணவு, வழங்குநர் அல்லது இடம் தேட...",
    opt_all_categories: "அனைத்து வகைகள்",
    opt_all_diets: "அனைத்து முறைகள்",
    opt_all_timelines: "அனைத்து நேரங்களும்",
    opt_urgent_2h: "⚡ < 2 மணி நேரத்தில் முடியும்",
    opt_urgent_4h: "⏳ < 4 மணி நேரத்தில் முடியும்",
    btn_claim_shelter: "காப்பகத்திற்குப் பெறுக →",
    btn_track_journey: "பயணத்தைக் கண்காணிக்க ↗",
    btn_release_donation: "உணவை விடுவிக்க",
    btn_assign_driver: "ஓட்டுநரை நியமிக்க",
    badge_available: "கிடைக்கும்",
    badge_accepted: "ஏற்றுக்கொள்ளப்பட்டது",
    badge_assigned: "ஓட்டுநர் நியமனம்",
    badge_collected: "சேகரிக்கப்பட்டது",
    badge_distributed: "வழங்கப்பட்டது",
    badge_overdue: "⚠️ நேரம் கடந்தது",
    verified_nonprofit_partner: "✓ சரிபார்க்கப்பட்ட தொண்டு நிறுவனம்",
    max_batch_port: "அதிகபட்சக் கொள்ளளவு:",
    accepts_veg_nonveg: "சைவம் மற்றும் அசைவம் ஏற்கப்படும்",
    strictly_pure_veg: "முற்றிலும் சைவ உணவு மட்டுமே",
    assigned_vehicle: "🚗 ஒதுக்கப்பட்ட வாகனம்:",
    match_score_label: "பொருத்தப் புள்ளி",

    // Matching Algorithm
    match_score_title: "விதிமுறை சார்ந்த பொருத்தப் புள்ளி",
    match_disclaimer: "வெளிப்படையான கணித விதிமுறை (தூரம், அவசரம், கொள்ளளவு, உணவு வகை). ஏஐ (AI) அல்ல.",
    score_distance: "அருகாமைத் தூரம்:",
    score_urgency: "அவசரக் காலக்கெடு:",
    score_suitability: "உணவுக் கொள்கை பொருத்தம்:",
    score_capacity: "அளவு கொள்ளளவு:",

    // Pickup Tracker
    tracker_title: "நேரடி உணவு சேகரிப்புக் கண்காணிப்பு",
    tracker_subtitle: "சமையலறையிலிருந்து உணவை நாடும் மக்களின் தட்டுக்குச் செல்லும் முழுப் பயணம்.",
    tracker_select_order: "செயலில் உள்ள உணவு மீட்பைத் தேர்வு செய்க:",
    tracker_read_aloud: "🔊 வாசித்துக்கேட்க",
    tracker_safe_overdue: "பாதுகாப்பான சேகரிப்பு நேரம் கடந்துவிட்டது!",
    tracker_safe_overdue_desc: "கடைசி நேரம் கடந்துவிட்டது. விநியோகத்திற்கு முன் வாசனை மற்றும் வெப்ப பரிசோதனை கட்டாயமாகும்.",
    tracker_posted_by: "வழங்குபவர்:",
    tracker_tracking_code: "கண்காணிப்புக் குறியீடு:",
    step_1: "1. கிடைக்கும்",
    step_2: "2. ஏற்கப்பட்டது",
    step_3: "3. ஓட்டுநர் நியமனம்",
    step_4: "4. பெறப்பட்டது",
    step_5: "5. பகிரப்பட்டது",
    btn_mark_collected: "✓ உணவு சேகரிக்கப்பட்டது என உறுதிசெய்",
    btn_mark_distributed: "✓ மக்களுக்கு வழங்கப்பட்டது என உறுதிசெய்",
    backup_ngo_title: "மாற்று தொண்டு நிறுவனம்",
    backup_ngo_desc: "45 நிமிடங்களுக்குள் வர இயலாவிட்டால், மாற்று காப்பகத்திற்கு மாற்றவும்:",
    btn_transfer_backup: "மாற்று தொண்டு நிறுவனத்திற்கு மாற்றுக →",

    // Recurring Schedules
    sched_title: "தொடர் உபரி உணவு திட்டங்கள்",
    sched_subtitle: "மண்டபங்கள், சிற்றுண்டிச்சாலைகள் மற்றும் விடுதிகளின் வழக்கமான உணவை தானாக அட்டவணைப்படுத்தவும்.",
    sched_reg_title: "வழக்கமான தொடர் அட்டவணையை பதிவு செய்க",
    sched_donor_org: "நிறுவனம் / வழங்குநர் பெயர் *",
    sched_donor_type_lbl: "வழங்குநர் வகை *",
    sched_opt_cafeteria: "கேண்டீன் / உணவகம்",
    sched_opt_hall: "திருமண / வரவேற்பு மண்டபம்",
    sched_opt_hotel: "ஹோட்டல் / பஃபே",
    sched_opt_restaurant: "உணவகம்",
    sched_food_item: "வழக்கமான உபரி உணவு *",
    sched_frequency_lbl: "கால இடைவெளி *",
    sched_freq_daily: "தினமும் (திங்கள்-ஞாயிறு)",
    sched_freq_weekdays: "வார நாட்கள் (திங்கள்-வெள்ளி)",
    sched_freq_weekends: "வார இறுதி (சனி-ஞாயிறு)",
    sched_est_portions: "தோராயமான உணவுகள் *",
    sched_pref_time: "விருப்பமான எடுக்கும் நேரம் *",
    sched_pickup_addr: "எடுக்கும் முகவரி *",
    sched_coord_contact: "ஒருங்கிணைப்பாளர் தொலைபேசி *",
    btn_save_schedule: "தொடர் அட்டவணையைச் சேமிக்க",
    sched_active_head: "செயலில் உள்ள தொடர் அட்டவணைகள்",
    btn_post_today: "⚡ இன்றைய உணவாகப் பதிவிடு",
    no_schedules_yet: "தொடர் அட்டவணைகள் இல்லை",
    no_schedules_desc: "சிற்றுண்டிச்சாலைகள் அல்லது மண்டபங்களின் வழக்கமான உபரி உணவுக்கு ஒரு அட்டவணையை உருவாக்கவும்.",

    // Impact Dashboard
    impact_title: "நேரடி சமூகத் தாக்கப் பலகை",
    impact_subtitle: "இந்த டெமோ அமர்வில் பதிவுசெய்யப்பட்ட உணவுகளிலிருந்து தானாகக் கணக்கிடப்பட்டது.",
    stat_meals: "மீட்கப்பட்ட உணவுகள்",
    stat_kg: "கிலோ உணவு சேமிப்பு",
    stat_co2: "கிலோ CO₂ குறைப்பு",
    stat_success: "வெற்றி விகிதம்",
    impact_active_donors: "செயலில் உள்ள உணவு வழங்குநர்கள்",
    impact_partner_shelters: "சரிபார்க்கப்பட்ட காப்பகங்கள்",
    impact_rescued_by_cat: "வகை வாரியாக மீட்கப்பட்ட உணவு",

    // Safety Guidelines
    safety_title: "உணவுப் பாதுகாப்பு வழிகாட்டுதல்",
    safety_guidelines_sub: "உணவு வழங்குநரிடமிருந்து பயனாளிகளுக்கு பாதுகாப்பாகச் செல்வதை உறுதிசெய்யும் நெறிமுறைகள்.",
    safety_disclaimer_title: "முக்கிய பாதுகாப்பு அறிவிப்பு",
    safety_disclaimer_body: "ஹோப்லிங்க் ஒரு ஒருங்கிணைப்பு தளம் மட்டுமே. படிவ சமர்ப்பிப்பு உணவு பாதுகாப்பை முழுமையாக உறுதிப்படுத்தாது. நேரில் வாசனை மற்றும் சுகாதார ஆய்வு செய்த பின்னரே மக்களுக்குப் பகிரப்பட வேண்டும்.",
    rule_1_badge: "விதி 1",
    rule_1_title: "வெப்பநிலை ஆபத்து மண்டலம்",
    rule_1_desc: "சூடான உணவை 60°C-க்கு மேலும், குளிர்ந்த உணவை 5°C-க்கு கீழும் வைக்கவும். சமைத்த உணவை அறை வெப்பநிலையில் 4 மணி நேரத்திற்கு மேல் வைக்கக்கூடாது.",
    rule_2_badge: "விதி 2",
    rule_2_title: "சுத்தமான உணவுப் பேக்கிங்",
    rule_2_desc: "உணவுகள் மாசடைவதைத் தடுக்க சுத்தமான எவர்சில்வர் பாத்திரங்கள் அல்லது தரமான உணவுப் பெட்டிகளில் அடைத்து வைக்க வேண்டும்.",
    rule_3_badge: "விதி 3",
    rule_3_title: "தெளிவான ஒவ்வாமை அறிவிப்பு",
    rule_3_desc: "பால், கொட்டைகள் மற்றும் சோயா போன்ற ஒவ்வாமை பொருட்களை தெளிவாக அறிவிப்பது குழந்தைகள் மற்றும் முதியவர்களுக்கு உதவும்.",
    rule_4_badge: "விதி 4",
    rule_4_title: "கட்டாய வாசனை மற்றும் தரப் பரிசோதனை",
    rule_4_desc: "உணவை எடுக்கும் தொண்டர்கள் உணவின் மணம், தோற்றம் மற்றும் வெப்பநிலையை நேரில் ஆய்வு செய்ய வேண்டும்.",

    // Community Guidelines & Issue Reporting
    community_title: "சமூக வழிகாட்டுதல் மற்றும் புகார்",
    community_sub: "வழங்குநர்கள், காப்பகங்கள் மற்றும் தொண்டர்களை இணைக்கும் மரியாதையான தளம்.",
    privacy_card_title: "🔒 தனிநபர் ரகசியப் பாதுகாப்பு",
    privacy_phone_bold: "தொலைபேசி எண் மறைப்பு:",
    privacy_phone_text: "தேவையற்ற அழைப்புகளைத் தவிர்க்க பொதுப் பட்டியலில் எண்களை மறைக்கலாம்.",
    privacy_loc_bold: "பாதுகாக்கப்பட்ட குடியிருப்பு முகவரி:",
    privacy_loc_text: "வீட்டின் கதவு எண் நியமிக்கப்பட்ட தொண்டருக்கு மட்டுமே பகிரப்படும்.",
    privacy_dignity_bold: "பயனாளிகளின் கண்ணியம்:",
    privacy_dignity_text: "உணவு பெறும் ஏழை எளிய மக்களின் புகைப்படங்கள் அல்லது அடையாளங்கள் பொதுவெளியில் பகிரப்படாது.",
    report_issue_title: "சிக்கல் அல்லது பாதுகாப்புக் குறையைப் புகாரளிக்கவும்",
    report_cat_lbl: "புகார் பிரிவு *",
    report_cat_spoiled: "கெட்டுப்போன / பாதுகாப்பற்ற உணவு",
    report_cat_noshow: "ஓட்டுநர் வரவில்லை / தாமதம்",
    report_cat_mismatch: "உணவின் அளவில் தவறான எண்ணிக்கை",
    report_cat_location: "தவறான முகவரி",
    report_cat_other: "இதர கருத்துக்கள்",
    report_donation_id_lbl: "தொடர்புடைய உணவு எண் (விருப்பம்)",
    report_role_lbl: "உங்கள் பொறுப்பு",
    report_role_donor: "உணவு வழங்குநர்",
    report_role_ngo: "காப்பகப் பிரதிநிதி",
    report_role_driver: "தன்னார்வல ஓட்டுநர்",
    report_role_community: "சமூக ஆர்வலர்",
    report_contact_lbl: "தொடர்பு எண் அல்லது மின்னஞ்சல்",
    report_desc_lbl: "விரிவான விவரம் *",
    report_desc_placeholder: "ஆய்வு செய்ய ஏதுவாக பிரச்சனை குறித்து விரிவாக எழுதவும்...",
    report_btn_submit: "புகாரைச் சமர்ப்பிக்கவும்",
    report_recent_title: "சமீபத்திய புகார்கள் (ஆய்வுப் பதிவு)",
    no_reports_yet: "இந்த அமர்வில் எந்தவொரு புகாரும் இல்லை. அனைத்தும் பாதுகாப்பாக உள்ளது.",

    // Modals
    confirm_modal_title: "உணவுப் பதிவு வெளியிடப்பட்டது!",
    confirm_modal_view_feed: "என்.ஜி.ஓ தளத்தில் பதிவைக் காண்க →",
    driver_modal_heading: "தன்னார்வல ஓட்டுநரை நியமிக்கவும்",
    driver_modal_sub: "உணவை எடுக்க வாகனத்தை அனுப்பவும்",
    driver_input_name: "ஓட்டுநர் / தொண்டர் பெயர்",
    driver_input_phone: "ஓட்டுநர் தொலைபேசி எண்",
    btn_confirm_driver_dispatch: "வாகன அனுப்புகையை உறுதிசெய்",

    // Action Toast messages
    toast_claimed: "உணவு உங்கள் அமைப்பால் வெற்றிகரமாக ஏற்றுக்கொள்ளப்பட்டது!",
    toast_released: "உணவு பொதுப் பட்டியலுக்கு மீண்டும் மாற்றப்பட்டது.",
    toast_assigned: "உணவை எடுக்க தொண்டர் நியமிக்கப்பட்டார்.",
    toast_collected: "உணவு பெறப்பட்டு கொண்டு செல்லப்படுகிறது.",
    toast_distributed: "உணவு தேவைப்படுவோருக்கு வெற்றிகரமாகப் பகிரப்பட்டது!",
    toast_reset_done: "டெமோ தரவு மீட்டமைக்கப்பட்டது.",
    toast_scenario_injected: "⚡ மாதிரி உணவுப் பதிவு வெற்றிகரமாகச் சேர்க்கப்பட்டது!"
  }
};

const i18n = {
  getLanguage() {
    return window.HopeStore ? window.HopeStore.getState().lang || "en" : "en";
  },

  setLanguage(lang) {
    if (lang !== "en" && lang !== "ta") lang = "en";
    if (window.HopeStore) {
      window.HopeStore.updateState({ lang });
    }
    document.documentElement.lang = lang;
    this.applyTranslations();

    // Trigger re-render across all active modules
    if (window.App && typeof window.App.onLanguageChange === "function") {
      window.App.onLanguageChange(lang);
    }
    return lang;
  },

  t(key) {
    const lang = this.getLanguage();
    if (DICTIONARY[lang] && DICTIONARY[lang][key] !== undefined) {
      return DICTIONARY[lang][key];
    }
    if (DICTIONARY["en"] && DICTIONARY["en"][key] !== undefined) {
      return DICTIONARY["en"][key];
    }
    return key;
  },

  applyTranslations(root = document) {
    // 1. Text elements with data-i18n
    const elements = root.querySelectorAll("[data-i18n]");
    elements.forEach((el) => {
      const key = el.getAttribute("data-i18n");
      const translation = this.t(key);
      if (translation) {
        if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
          el.placeholder = translation;
        } else {
          el.textContent = translation;
        }
      }
    });

    // 2. Placeholder attributes
    const placeholderEls = root.querySelectorAll("[data-i18n-placeholder]");
    placeholderEls.forEach((el) => {
      const key = el.getAttribute("data-i18n-placeholder");
      const translation = this.t(key);
      if (translation) {
        el.placeholder = translation;
      }
    });

    // 3. Title / aria-label attributes
    const titleEls = root.querySelectorAll("[data-i18n-title]");
    titleEls.forEach((el) => {
      const key = el.getAttribute("data-i18n-title");
      const translation = this.t(key);
      if (translation) {
        el.title = translation;
        el.setAttribute("aria-label", translation);
      }
    });

    // 4. Update language switcher button states
    const currentLang = this.getLanguage();
    document.querySelectorAll(".lang-btn").forEach((btn) => {
      if (btn.getAttribute("data-lang") === currentLang) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });
  },

  playAudioChime() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = "sine";
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12); // A5
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      }
    } catch (e) {}
  },

  toPhoneticTamil(text) {
    // High-frequency Tamil keywords to phonetic Indian English
    return text
      .replace(/உணவுப் பதிவு எண்/g, "Unavu pathivu yenn")
      .replace(/தற்போதைய நிலை/g, "Tharpodhaiya nilai")
      .replace(/எடுக்கும் இடம்/g, "Yedukkum idam")
      .replace(/காலக்கெடு/g, "Kaalakkedu")
      .replace(/கிடைக்கும்/g, "Kidaikkum, Available")
      .replace(/ஏற்கப்பட்டது/g, "Yerkappattadhu, Accepted")
      .replace(/ஓட்டுநர் நியமனம்/g, "Ottunar niyamikkappattadhu, Driver Dispatched")
      .replace(/பெறப்பட்டது/g, "Unavu perappattadhu, Collected")
      .replace(/பகிரப்பட்டது/g, "Vazhangappattadhu, Distributed")
      .replace(/சைவம்/g, "Pure Veg")
      .replace(/அசைவம்/g, "Non Veg")
      .replace(/அளவு/g, "Alavu")
      .replace(/வகை/g, "Vagai")
      .replace(/நன்றி/g, "Nandri");
  },

  startVoiceInput(targetInputId, statusCallback) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    // Open Visual Listening Modal for Immediate User Feedback
    this.openVoiceModal(targetInputId, statusCallback);

    if (!SpeechRecognition) {
      if (typeof statusCallback === "function") {
        statusCallback("error", "Web Speech API is not supported in this browser. Please use the quick preset chips or type directly.");
      }
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      const currentLang = this.getLanguage();
      recognition.lang = currentLang === "ta" ? "ta-IN" : "en-US";
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      const modalStatus = document.getElementById("voiceModalStatus");
      const modalTranscript = document.getElementById("voiceModalTranscript");
      const modalMicIcon = document.getElementById("voiceModalMic");

      if (modalStatus) {
        modalStatus.textContent = currentLang === "ta" 
          ? "🎤 கேட்கிறது... தமிழில் அல்லது ஆங்கிலத்தில் பேசுங்கள்!" 
          : "🎤 Listening... Speak now in English or Tamil!";
      }
      if (modalMicIcon) modalMicIcon.classList.add("listening");

      recognition.onresult = (event) => {
        let interimTranscript = "";
        let finalTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const currentText = finalTranscript || interimTranscript;
        if (modalTranscript) {
          modalTranscript.textContent = currentText || "Listening...";
        }

        const targetInput = document.getElementById(targetInputId);
        if (targetInput && finalTranscript) {
          targetInput.value = (targetInput.value ? targetInput.value + " " : "") + finalTranscript;
          targetInput.dispatchEvent(new Event("input"));
        }
      };

      recognition.onerror = (event) => {
        console.warn("Speech recognition error:", event.error);
        if (modalStatus) {
          if (event.error === "not-allowed") {
            modalStatus.innerHTML = "⚠️ <strong>Microphone Blocked:</strong> Please tap the lock 🔒 icon in your browser address bar and enable Microphone.";
          } else if (event.error === "no-speech") {
            modalStatus.textContent = "⚠️ No voice detected. Tap mic again or choose a preset below.";
          } else {
            modalStatus.textContent = `Mic note (${event.error}). Try presets below or type directly.`;
          }
        }
        if (modalMicIcon) modalMicIcon.classList.remove("listening");
        if (typeof statusCallback === "function") {
          statusCallback("error", `Mic status: ${event.error}`);
        }
      };

      recognition.onend = () => {
        if (modalMicIcon) modalMicIcon.classList.remove("listening");
        if (typeof statusCallback === "function") {
          statusCallback("idle", this.t("btn_voice_input"));
        }
      };

      recognition.start();
      this.activeRecognition = recognition;
    } catch (e) {
      console.error("Speech recognition exception", e);
      if (typeof statusCallback === "function") {
        statusCallback("error", "Microphone access issue. Please use quick presets or type directly.");
      }
    }
  },

  openVoiceModal(targetInputId, statusCallback) {
    let modal = document.getElementById("voiceDictationModal");
    const isTa = this.getLanguage() === "ta";

    if (!modal) {
      modal = document.createElement("div");
      modal.id = "voiceDictationModal";
      modal.className = "voice-modal-backdrop";
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div class="voice-modal-card">
        <button class="voice-modal-close" onclick="i18n.closeVoiceModal()">&times;</button>
        <div class="voice-mic-wave-wrap">
          <div class="voice-mic-bubble" id="voiceModalMic">
            <svg viewBox="0 0 24 24" width="36" height="36" fill="white">
              <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/>
              <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>
            </svg>
          </div>
          <div class="sound-wave-bars">
            <span></span><span></span><span></span><span></span><span></span>
          </div>
        </div>

        <h4 id="voiceModalStatus" class="voice-status-title">
          ${isTa ? "🎤 குரல் பதிவு துவங்குகிறது..." : "🎤 Initializing Microphone..."}
        </h4>

        <div class="voice-transcript-box" id="voiceModalTranscript">
          <em>${isTa ? "உங்கள் உணவின் விவரங்களைப் பேசுங்கள்..." : "Speak details about your surplus food..."}</em>
        </div>

        <!-- Quick 1-Tap Preset Dictations (Guaranteed working fallback) -->
        <div class="voice-presets-group">
          <small class="presets-title">${isTa ? "அல்லது 1-கிளிக் மாதிரி உரை:" : "Or 1-Tap Sample Preset:"}</small>
          <div class="preset-chips-row">
            <button type="button" class="preset-chip" onclick="i18n.applyVoicePreset('${targetInputId}', '${isTa ? '50 நபர்களுக்கான சூடான வெஜ் பிரியாணி மற்றும் தயிர் பச்சடி' : '50 Servings Fresh Veg Biryani & Curd Rice'}')">
              🍲 ${isTa ? '50 வெஜ் பிரியாணி' : '50 Veg Biryani'}
            </button>
            <button type="button" class="preset-chip" onclick="i18n.applyVoicePreset('${targetInputId}', '${isTa ? '80 நபர்களுக்கான சப்பாத்தி மற்றும் தால் தட்கா' : '80 Portions Chapati & Dal Tadka'}')">
              🫓 ${isTa ? '80 சப்பாத்தி & தால்' : '80 Chapati & Dal'}
            </button>
            <button type="button" class="preset-chip" onclick="i18n.applyVoicePreset('${targetInputId}', '${isTa ? '40 நபர்களுக்கான சுடச்சுட இட்லி, வடை மற்றும் சாம்பார்' : '40 Servings Idli, Vada & Sambar'}')">
              ☕ ${isTa ? '40 இட்லி & சாம்பார்' : '40 Idli & Sambar'}
            </button>
          </div>
        </div>

        <div class="voice-modal-actions">
          <button type="button" class="btn btn-primary btn-sm full-width" onclick="i18n.closeVoiceModal()">
            ${isTa ? "✓ முடிந்தது / படிவத்தில் சேர்" : "✓ Done / Use This Text"}
          </button>
        </div>
      </div>
    `;

    modal.classList.add("active");
  },

  applyVoicePreset(targetInputId, text) {
    const input = document.getElementById(targetInputId);
    if (input) {
      input.value = text;
      input.dispatchEvent(new Event("input"));
    }
    const transcript = document.getElementById("voiceModalTranscript");
    if (transcript) transcript.textContent = text;
    if (window.App) window.App.showToast(`✓ Voice Dictation applied: "${text}"`, "success");
    setTimeout(() => this.closeVoiceModal(), 600);
  },

  closeVoiceModal() {
    if (this.activeRecognition) {
      try {
        this.activeRecognition.stop();
      } catch (e) {}
      this.activeRecognition = null;
    }
    const modal = document.getElementById("voiceDictationModal");
    if (modal) modal.classList.remove("active");
  },

  speak(text) {
    if (!("speechSynthesis" in window)) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }

    try {
      window.speechSynthesis.cancel();
      this.playAudioChime();

      const currentLang = this.getLanguage();
      const utterance = new SpeechSynthesisUtterance();

      // Get available voices
      const voices = window.speechSynthesis.getVoices() || [];

      if (currentLang === "ta") {
        // Look for native Tamil voice: ta-IN, ta_IN, Google தமிழ், etc.
        const tamilVoice = voices.find(
          (v) =>
            v.lang.toLowerCase().startsWith("ta") ||
            v.name.toLowerCase().includes("tamil") ||
            v.name.includes("தமிழ்")
        );

        if (tamilVoice) {
          utterance.voice = tamilVoice;
          utterance.lang = "ta-IN";
          utterance.text = text;
        } else {
          // Fallback: Use Indian English voice with transliterated phonetic Tamil words
          const indianVoice = voices.find(
            (v) => v.lang === "en-IN" || v.name.toLowerCase().includes("india")
          );
          if (indianVoice) utterance.voice = indianVoice;
          utterance.lang = "en-IN";
          utterance.text = this.toPhoneticTamil(text);
        }
      } else {
        const engVoice = voices.find((v) => v.lang.startsWith("en"));
        if (engVoice) utterance.voice = engVoice;
        utterance.lang = "en-US";
        utterance.text = text;
      }

      utterance.rate = 0.92;
      utterance.pitch = 1.0;

      const wave = document.getElementById("ttsWaveVisualizer");
      if (wave) wave.classList.add("playing");

      utterance.onend = () => {
        if (wave) wave.classList.remove("playing");
      };
      utterance.onerror = () => {
        if (wave) wave.classList.remove("playing");
      };

      if (window.App) {
        window.App.showToast(`🔊 ${currentLang === 'ta' ? 'வாசிக்கப்படுகிறது: ' : 'Speaking: '}"${text.substring(0, 45)}..."`, "info");
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error", e);
    }
  }
};

// Ensure voices are loaded when ready
if (typeof window !== "undefined" && "speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    window.speechSynthesis.getVoices();
  };
}

window.i18n = i18n;
