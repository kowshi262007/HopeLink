/**
 * HopeLink - Live Impact Analytics (impact.js)
 * 
 * Computes dynamic metrics directly from active and fulfilled records
 * stored in localStorage.
 */

const ImpactModule = {
  init() {
    this.updateMetrics();
  },

  updateMetrics() {
    const donations = window.HopeStore.getDonations();
    const ngos = window.HopeStore.getNGOs();

    // Aggregations
    let totalPortionsOffered = 0;
    let totalPortionsRescued = 0;
    let totalKgSaved = 0;

    const donorNames = new Set();
    const categoryTotals = {
      cooked: 0,
      bakery: 0,
      produce: 0,
      dairy: 0,
      packaged: 0
    };

    donations.forEach((d) => {
      const portions = d.quantity || 0;
      const kg = d.estimatedKg || Math.round(portions * 0.35);

      totalPortionsOffered += portions;
      donorNames.add(d.donorName);

      if (d.status === "collected" || d.status === "distributed") {
        totalPortionsRescued += portions;
        totalKgSaved += kg;
      }

      if (categoryTotals[d.category] !== undefined) {
        categoryTotals[d.category] += portions;
      }
    });

    // CO2 emission factor: ~2.5 kg CO2e per 1 kg food waste diverted from landfill
    const co2AvoidedKg = Math.round(totalKgSaved * 2.5);

    // Success rate
    const successRate = totalPortionsOffered > 0
      ? Math.round((totalPortionsRescued / totalPortionsOffered) * 100)
      : 0;

    // Update DOM
    const elMeals = document.getElementById("impactTotalMeals");
    const elKg = document.getElementById("impactTotalKg");
    const elCo2 = document.getElementById("impactTotalCo2");
    const elSuccess = document.getElementById("impactSuccessRate");
    const elDonors = document.getElementById("impactActiveDonors");
    const elNgos = document.getElementById("impactPartnerNgos");

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    const mealsSuffix = isTa ? " உணவுகள்" : " meals";
    const kgSuffix = isTa ? " கிலோ" : " kg";

    if (elMeals) elMeals.textContent = totalPortionsRescued.toLocaleString() + mealsSuffix;
    if (elKg) elKg.textContent = totalKgSaved.toLocaleString() + kgSuffix;
    if (elCo2) elCo2.textContent = co2AvoidedKg.toLocaleString() + kgSuffix;
    if (elSuccess) elSuccess.textContent = successRate + "%";
    if (elDonors) elDonors.textContent = donorNames.size;
    if (elNgos) elNgos.textContent = ngos.length;

    // Update category breakdown chart / bars
    this.renderCategoryBreakdown(categoryTotals, totalPortionsOffered);
  },

  renderCategoryBreakdown(categories, total) {
    const container = document.getElementById("categoryBreakdownContainer");
    if (!container) return;

    const isTa = window.i18n ? window.i18n.getLanguage() === "ta" : false;
    const labels = {
      cooked: isTa ? "🍲 சமைத்த உணவுகள்" : "🍲 Cooked Meals",
      bakery: isTa ? "🍞 ரொட்டி & பேக்கரி" : "🍞 Bakery & Breads",
      produce: isTa ? "🍎 பழங்கள் & காய்கறிகள்" : "🍎 Fruits & Veggies",
      dairy: isTa ? "🥛 பால் பொருட்கள்" : "🥛 Dairy Products",
      packaged: isTa ? "🥫 பாக்கெட் உணவுகள்" : "🥫 Packaged Foods"
    };
    const portionsWord = isTa ? "உணவுகள்" : "portions";

    container.innerHTML = Object.entries(categories)
      .map(([cat, amount]) => {
        const pct = total > 0 ? Math.round((amount / total) * 100) : 0;
        return `
          <div class="category-stat-row">
            <div class="cat-label-row">
              <span>${labels[cat] || cat}</span>
              <span><strong>${amount}</strong> ${portionsWord} (${pct}%)</span>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-bar-fill progress-${cat}" style="width: ${pct}%"></div>
            </div>
          </div>
        `;
      })
      .join("");
  }
};

window.ImpactModule = ImpactModule;
